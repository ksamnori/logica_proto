// src/app/clinic/viewer/components/ClinicCanvas.tsx
import React, { useRef, useEffect, useCallback } from 'react';
import { ERASER_WIDTH_MULTIPLIER } from '../utils';

interface ClinicCanvasProps {
  qIndex: number;
  currentPenWidth: number;
  currentPenColor: string;
  isEraserMode: boolean;
  studentDrawings: React.MutableRefObject<Record<number, string>>;
  studentAnswers: React.MutableRefObject<Record<number, string | null>>;
  forceUpdate: () => void;
  clearTrigger: number;
}

export const ClinicCanvas: React.FC<ClinicCanvasProps> = ({
  qIndex, currentPenWidth, currentPenColor, isEraserMode,
  studentDrawings, studentAnswers, forceUpdate, clearTrigger
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);
  
  const isDrawing = useRef(false);
  const activePointerId = useRef<number | null>(null);

  const lastPos = useRef<{x: number, y: number} | null>(null);
  const lastMid = useRef<{x: number, y: number} | null>(null);
  
  // 🌟 핵심 해결: 필기 렉(끊김) 방지용 지연 저장 타이머
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const drawWritableHint = (ctx: CanvasRenderingContext2D, w: number, h: number) => {
    ctx.save();
    ctx.fillStyle = 'rgba(28,37,48,0.08)';
    for (let x = 16; x < w; x += 32) {
      for (let y = 16; y < h; y += 32) {
        ctx.beginPath();
        ctx.arc(x, y, 1, 0, Math.PI * 2);
        ctx.fill();
      }
    }
    ctx.restore();
  };

  const initCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    
    if (rect.width === 0) { requestAnimationFrame(initCanvas); return; }

    canvas.width = Math.max(1, Math.round(rect.width * dpr));
    canvas.height = Math.max(1, Math.round(rect.height * dpr));
    
    const ctx = canvas.getContext('2d', { desynchronized: true });
    if (!ctx) return;
    
    ctxRef.current = ctx;
    ctx.scale(dpr, dpr);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = currentPenColor;
    ctx.fillStyle = currentPenColor;
    ctx.lineWidth = isEraserMode ? currentPenWidth * ERASER_WIDTH_MULTIPLIER : currentPenWidth;
    ctx.globalCompositeOperation = isEraserMode ? 'destination-out' : 'source-over';

    drawWritableHint(ctx, rect.width, rect.height);

    const saved = studentDrawings.current[qIndex];
    if (saved) {
      const img = new Image();
      img.onload = () => ctx.drawImage(img, 0, 0, rect.width, rect.height);
      img.src = saved;
    }
  };

  // 🌟 강제 저장 함수 (비동기 처리로 메인 스레드 블로킹 방지)
  const saveCanvasData = useCallback(() => {
    if (canvasRef.current) {
      canvasRef.current.toBlob((blob) => {
        if (!blob) return;
        const reader = new FileReader();
        reader.onloadend = () => {
          const dataUrl = reader.result as string;
          studentDrawings.current[qIndex] = dataUrl;
          studentAnswers.current[qIndex] = dataUrl;
          forceUpdate();
        };
        reader.readAsDataURL(blob);
      }, 'image/webp', 0.5);
    }
  }, [qIndex, studentDrawings, studentAnswers, forceUpdate]);

  useEffect(() => {
    const timer = setTimeout(() => initCanvas(), 50);
    return () => clearTimeout(timer);
  }, [qIndex, clearTrigger]);

  // 언마운트되거나 다음 문제로 넘어갈 때, 아직 저장 안 된 필기가 있다면 강제로 일괄 저장!
  useEffect(() => {
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current);
        saveTimeoutRef.current = null;
        saveCanvasData();
      }
    };
  }, [saveCanvasData]);

  useEffect(() => {
    if (ctxRef.current) {
      ctxRef.current.strokeStyle = currentPenColor;
      ctxRef.current.fillStyle = currentPenColor; 
      ctxRef.current.lineWidth = isEraserMode ? currentPenWidth * ERASER_WIDTH_MULTIPLIER : currentPenWidth;
      ctxRef.current.globalCompositeOperation = isEraserMode ? 'destination-out' : 'source-over';
    }
  }, [currentPenColor, currentPenWidth, isEraserMode]);

  const getPos = (e: any, canvas: HTMLCanvasElement) => {
    const r = canvas.getBoundingClientRect();
    return { 
      x: (e.clientX || e.touches?.[0]?.clientX) - r.left, 
      y: (e.clientY || e.touches?.[0]?.clientY) - r.top 
    };
  };

  const startDraw = (e: any) => {
    // 🌟 추가된 로직: 새 획을 긋기 시작하면 기존 저장 예약 취소
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
      saveTimeoutRef.current = null;
    }

    if (isDrawing.current) return;
    
    isDrawing.current = true;
    activePointerId.current = e.pointerId; 
    
    const canvas = canvasRef.current;
    if (!canvas || !ctxRef.current) return;
    try { canvas.setPointerCapture(e.pointerId); } catch (err) {}
    
    const p = getPos(e, canvas);
    lastPos.current = p;
    lastMid.current = p;

    ctxRef.current.beginPath();
    ctxRef.current.fillStyle = isEraserMode ? 'rgba(0,0,0,1)' : currentPenColor;
    ctxRef.current.arc(p.x, p.y, (isEraserMode ? currentPenWidth * ERASER_WIDTH_MULTIPLIER : currentPenWidth) / 2, 0, Math.PI * 2);
    ctxRef.current.fill();
    
    ctxRef.current.beginPath();
    ctxRef.current.moveTo(p.x, p.y);
  };

  const draw = (e: any) => {
    if (!isDrawing.current || e.pointerId !== activePointerId.current || !canvasRef.current || !ctxRef.current || !lastPos.current || !lastMid.current) return;
    
    const events = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    
    ctxRef.current.beginPath();
    ctxRef.current.moveTo(lastMid.current.x, lastMid.current.y);

    for (const ev of events) {
      const currentPos = getPos(ev, canvasRef.current);
      
      const midPos = {
        x: (lastPos.current.x + currentPos.x) / 2,
        y: (lastPos.current.y + currentPos.y) / 2
      };

      ctxRef.current.quadraticCurveTo(lastPos.current.x, lastPos.current.y, midPos.x, midPos.y);

      lastPos.current = currentPos;
      lastMid.current = midPos;
    }
    
    ctxRef.current.stroke();
  };

  const stopDraw = (e: any) => {
    if (!isDrawing.current || e.pointerId !== activePointerId.current || !canvasRef.current || !ctxRef.current) return;
    
    if (lastPos.current && lastMid.current) {
        ctxRef.current.beginPath();
        ctxRef.current.moveTo(lastMid.current.x, lastMid.current.y);
        ctxRef.current.lineTo(lastPos.current.x, lastPos.current.y);
        ctxRef.current.stroke();
    }

    isDrawing.current = false;
    activePointerId.current = null; 
    lastPos.current = null;
    lastMid.current = null;

    try { if (e?.pointerId != null) canvasRef.current.releasePointerCapture(e.pointerId); } catch (err) {}
    
    // 🌟 짧게 끊어 쓰는(빠른) 필기 대응: 펜을 뗄 때마다 무겁게 저장하지 않음!
    // 필기가 멈추고 0.4초(400ms)동안 새로운 획이 안 들어오면 그제야 일괄 저장
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current);
    }
    saveTimeoutRef.current = setTimeout(() => {
      saveCanvasData();
      saveTimeoutRef.current = null;
    }, 400); 
  };

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full cursor-crosshair touch-none"
      onPointerDown={startDraw}
      onPointerMove={draw}
      onPointerUp={stopDraw}
      onPointerCancel={stopDraw}
    />
  );
};