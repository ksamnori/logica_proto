// src/app/supervisor/useSupervisorData.tsx
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { supabaseClient, CLINIC_ROOM, getKSTDateString, DEFAULT_CLINIC_DURATION_MS, LOG_AUTO_EXPIRE_MS, PENDING_GUARD_MS, formatDuration } from './supervisorUtils';

export function useSupervisorData() {
    const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);
    const [authMessage, setAuthMessage] = useState<string>('권한을 확인하는 중입니다...');

    const [now, setNow] = useState(Date.now());
    const [startedAt] = useState(Date.now());
    const [connectionStatus, setConnectionStatus] = useState('connecting');
    const [activeStudents, setActiveStudents] = useState<Record<string, any>>({});
    const [activeTAs, setActiveTAs] = useState<Record<string, any>>({});
    const [taStats, setTaStats] = useState<Record<string, any>>({});
    const [logs, setLogs] = useState<any[]>([]);
    const [isMounted, setIsMounted] = useState(false);
    
    const [leftTab, setLeftTab] = useState<'ta' | 'students'>('ta');
    const [allStudents, setAllStudents] = useState<Record<string, any[]>>({});
    const [expandedClasses, setExpandedClasses] = useState<Record<string, boolean>>({});
    
    const [draggedSeat, setDraggedSeat] = useState<string | null>(null);
    const [draggedListStudent, setDraggedListStudent] = useState<any>(null);
    const [selectedSeatForMove, setSelectedSeatForMove] = useState<string | null>(null);
    
    const [forceCheckoutModal, setForceCheckoutModal] = useState<{ isOpen: boolean, seat: string | null }>({ isOpen: false, seat: null });
    const [recheckModal, setRecheckModal] = useState<{ isOpen: boolean, seat: string | null, uid: string | null }>({ isOpen: false, seat: null, uid: null });

    const studentsRef = useRef<Record<string, any>>({});
    const channelRef = useRef<any>(null);
    const logsRef = useRef<any[]>([]);
    
    const pendingMovesRef = useRef<Record<string, any>>({});
    const pendingDeletesRef = useRef<Record<string, number>>({});
    const pendingTimeAdjustRef = useRef<Record<string, any>>({});
    const syncPresenceRef = useRef<any>(null);

    useEffect(() => {
        setIsMounted(true);
        const verifyAdminAccess = () => {
            const instId = localStorage.getItem('logica_instructor_id');
            const role = localStorage.getItem('logica_instructor_role') || '';
            const position = localStorage.getItem('logica_instructor_position') || '';

            if (!instId) {
                setAuthMessage('로그인이 필요합니다. 먼저 시스템에 로그인해 주세요.');
                setIsAuthorized(false);
                return;
            }

            if (role === 'ADMIN' || role === 'MANAGER' || role === 'PRINCIPAL' || position.includes('원장') || position.includes('실장')) {
                setIsAuthorized(true);
            } else {
                setAuthMessage(`접근 불가: [${position || '미지정'}] 권한입니다. 원장 또는 실장만 접속 가능합니다.`);
                setIsAuthorized(false);
            }
        };
        verifyAdminAccess();
    }, []);

    const updateStudents = useCallback((newStudents: any) => {
        studentsRef.current = newStudents;
        setActiveStudents({ ...newStudents });
    }, []);

    const updateLogs = useCallback((newLogs: any[]) => {
        logsRef.current = newLogs;
        setLogs([...newLogs]);
    }, []);

    const appendLog = useCallback((borderClass: string, badgeBg: string, badgeText: string, title: string | React.ReactNode, subtitle: string | React.ReactNode, type?: string, data?: any) => {
        const logId = `log-${Date.now()}-${Math.random()}`;
        const newLog = {
            id: logId, timestamp: new Date().toLocaleTimeString('ko-KR', { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }),
            borderClass, badgeBg, badgeText, title, subtitle, type, data, expiresAt: Date.now() + LOG_AUTO_EXPIRE_MS
        };
        updateLogs([newLog, ...logsRef.current]);
        setTimeout(() => updateLogs(logsRef.current.filter(l => l.id !== logId)), LOG_AUTO_EXPIRE_MS);
        return logId;
    }, [updateLogs]);

    const removeLogsByTypeAndSeat = useCallback((type: string, seat: string, qNum?: number) => {
        updateLogs(logsRef.current.filter(l => !(l.data?.seat === seat && l.type === type && (!qNum || l.data?.qNum === qNum))));
    }, [updateLogs]);

    const sendToStudent = (seat: string, action: string, extra = {}) => {
        if (!channelRef.current) return;
        channelRef.current.send({ type: 'broadcast', event: 'ta_action', payload: { seat, action, ...extra, timestamp: Date.now() } });
    };

    useEffect(() => {
        if (!isAuthorized) return;
        
        const fetchAllStudents = async () => {
            const { data } = await supabaseClient.from('student').select('student_id, name, enrollment(class(name))');
            if (data) {
                const grouped: Record<string, any[]> = {};
                data.forEach((s: any) => {
                    const classes = s.enrollment?.map((e: any) => e.class?.name).filter(Boolean) || [];
                    const cName = classes.length > 0 ? classes[0] : '반 미배정';
                    if (!grouped[cName]) grouped[cName] = [];
                    grouped[cName].push({ id: s.student_id, name: s.name, classes });
                });
                const sortedGrouped: Record<string, any[]> = {};
                Object.keys(grouped).sort().forEach(k => { sortedGrouped[k] = grouped[k].sort((a, b) => a.name.localeCompare(b.name)); });
                setAllStudents(sortedGrouped);
                if (Object.keys(sortedGrouped).length > 0) setExpandedClasses({ [Object.keys(sortedGrouped)[0]]: true });
            }
        };

        const loadInitialSeatsFromDB = async () => {
            const todayStr = getKSTDateString();
            const { data: sessionData } = await supabaseClient.from('clinic_session_state').select('*').eq('session_date', todayStr);
            if (!sessionData || sessionData.length === 0) return;

            const newStudents = { ...studentsRef.current };
            for (const sess of sessionData) {
                let effectiveSeat = sess.manual_seat;
                if (!effectiveSeat && sess.seat) {
                    effectiveSeat = sess.seat;
                    await supabaseClient.from('clinic_session_state').update({ manual_seat: effectiveSeat }).eq('student_id', sess.student_id);
                }
                if (!effectiveSeat) continue;
                
                const { data: sData } = await supabaseClient.from('student').select('name, enrollment(class(name))').eq('student_id', sess.student_id).single();
                const metaName = sData?.name || '학생';
                const metaClasses = sData?.enrollment?.map((e: any) => e.class?.name).filter(Boolean) || ['반 미배정'];
                
                if (!newStudents[effectiveSeat]) {
                    newStudents[effectiveSeat] = {
                        name: metaName, classes: metaClasses, status: 'idle', studentId: sess.student_id,
                        firstSeenAt: new Date(sess.started_at).getTime() || Date.now(),
                        clinicDurationMs: sess.duration_ms || DEFAULT_CLINIC_DURATION_MS,
                        totalCalls: 0, totalHints: 0, calls: {}, offlineSince: null
                    };
                }
            }
            updateStudents(newStudents);
        };
        fetchAllStudents(); loadInitialSeatsFromDB();
    }, [isAuthorized, updateStudents]);

    useEffect(() => {
        if (!isAuthorized) return;
        const interval = setInterval(() => {
            setNow(Date.now());
            if (channelRef.current && syncPresenceRef.current) syncPresenceRef.current(channelRef.current.presenceState());
        }, 1000);
        return () => clearInterval(interval);
    }, [isAuthorized]);

    useEffect(() => {
        if (!isAuthorized || !isMounted) return;
        const dbCrossValidationInterval = setInterval(async () => {
            const todayStr = getKSTDateString();
            const { data: sessionData, error } = await supabaseClient.from('clinic_session_state').select('*').eq('session_date', todayStr);
            if (error || !sessionData) return;

            const dbSeats = new Map();
            for (const s of sessionData) {
                let effectiveSeat = s.manual_seat;
                if (!effectiveSeat && s.seat) {
                    effectiveSeat = s.seat;
                    supabaseClient.from('clinic_session_state').update({ manual_seat: effectiveSeat }).eq('student_id', s.student_id).then();
                }
                if (effectiveSeat) dbSeats.set(effectiveSeat, s);
            }

            const current = { ...studentsRef.current };
            let isModified = false;

            for (const [targetSeat, dbRecord] of Array.from(dbSeats.entries())) {
                const oldSeat = Object.keys(current).find(s => current[s].studentId === dbRecord.student_id);
                if (oldSeat && oldSeat !== targetSeat) {
                    current[targetSeat] = { ...current[oldSeat], clinicDurationMs: dbRecord.duration_ms };
                    delete current[oldSeat]; isModified = true;
                } else if (!oldSeat && !current[targetSeat]) {
                    const { data: sData } = await supabaseClient.from('student').select('name, enrollment(class(name))').eq('student_id', dbRecord.student_id).single();
                    current[targetSeat] = {
                        name: sData?.name || '학생', classes: sData?.enrollment?.map((e: any) => e.class?.name).filter(Boolean) || ['반 미배정'],
                        status: 'idle', studentId: dbRecord.student_id, firstSeenAt: new Date(dbRecord.started_at).getTime() || Date.now(),
                        clinicDurationMs: dbRecord.duration_ms || DEFAULT_CLINIC_DURATION_MS,
                        totalCalls: 0, totalHints: 0, calls: {}, offlineSince: null, activity: '포털/수동 배정 연동'
                    };
                    isModified = true;
                } else if (oldSeat === targetSeat) {
                    const isTimeAdjusting = pendingTimeAdjustRef.current[targetSeat] && Date.now() < pendingTimeAdjustRef.current[targetSeat].expiresAt;
                    if (!isTimeAdjusting && dbRecord.duration_ms !== undefined && current[targetSeat].clinicDurationMs !== dbRecord.duration_ms) {
                        current[targetSeat].clinicDurationMs = dbRecord.duration_ms; isModified = true;
                    }
                }
            }

            Object.keys(current).forEach(uiSeat => {
                const isPendingDelete = pendingDeletesRef.current[uiSeat] && Date.now() < pendingDeletesRef.current[uiSeat];
                const isPendingMove = pendingMovesRef.current[uiSeat] && Date.now() < pendingMovesRef.current[uiSeat].expiresAt;
                if (!dbSeats.has(uiSeat) && !isPendingDelete && !isPendingMove && !current[uiSeat].dummy) {
                    appendLog('border-slate-800', 'bg-slate-900 text-white', '교차검증', `[${uiSeat}] 유령 청소 완료`, `DB에 해당 정보가 없어 정리되었습니다.`);
                    delete current[uiSeat]; isModified = true;
                }
            });

            if (isModified) updateStudents(current);
        }, 5000);
        return () => clearInterval(dbCrossValidationInterval);
    }, [isAuthorized, isMounted, updateStudents, appendLog]);

    const recordTaStat = (name: string, mark: string) => {
        setTaStats(prev => {
            const next = { ...prev };
            const key = name || '이름 미상';
            if (!next[key]) next[key] = { total: 0, hint: 0, skip: 0 };
            next[key].total++;
            if (mark === 'hint') next[key].hint++; else if (mark === 'skip') next[key].skip++;
            return next;
        });
    };

    const handleTaActionFromOtherScreen = (payload: any) => {
        const { seat, action, qNum, taName, mark } = payload;
        const currentStudents = { ...studentsRef.current };

        if (action === 'force_cancel_call') {
            if (currentStudents[seat]?.calls) delete currentStudents[seat].calls[qNum];
            if (Object.keys(currentStudents[seat]?.calls || {}).length === 0) currentStudents[seat].status = 'idle';
            removeLogsByTypeAndSeat('call', seat, qNum);
            appendLog('border-slate-400', 'bg-slate-100 text-slate-600', '호출해제', `[${seat}] ${qNum}번 문항 지도 종료`, `${taName || '총책임자'} · ${mark === 'hint' ? '힌트 제공 후 종료' : mark === 'skip' ? '설명 없이 넘어감' : '지도 종료'}`);
            recordTaStat(taName || '총책임자', mark);
        } else if (action === 'force_return_to_seat') {
            if (currentStudents[seat]) { currentStudents[seat].status = 'idle'; currentStudents[seat].awaySince = null; }
            removeLogsByTypeAndSeat('away', seat);
            appendLog('border-slate-400', 'bg-slate-100 text-slate-600', '복귀처리', `[${seat}] 자리비움 해제`, `다른 화면에서 해제했습니다.`);
        } else if (action === 'force_checkout' || action === 'force_checkout_by_ta') {
            if (currentStudents[seat]) {
                const st = currentStudents[seat];
                if (st.studentId) supabaseClient.from('clinic_session_state').update({ seat: null, manual_seat: null }).eq('student_id', st.studentId).then();
                appendLog(action === 'force_checkout_by_ta' ? 'border-rose-600' : 'border-slate-800', action === 'force_checkout_by_ta' ? 'bg-rose-600 text-white' : 'bg-slate-900 text-white', action === 'force_checkout_by_ta' ? '강제퇴실' : '퇴실완료', `[${seat}] ${st.name} 퇴실 처리`, `다른 화면에서 처리되었습니다.`);
                removeLogsByTypeAndSeat('call', seat); removeLogsByTypeAndSeat('submit', seat); removeLogsByTypeAndSeat('away', seat); removeLogsByTypeAndSeat('recheck', seat);
                delete currentStudents[seat]; pendingDeletesRef.current[seat] = Date.now() + PENDING_GUARD_MS;
            }
        }
        updateStudents(currentStudents);
    };

    useEffect(() => {
        if (!isAuthorized) return;
        
        const channel = supabaseClient.channel(CLINIC_ROOM);
        channelRef.current = channel;

        channel
            .on('presence', { event: 'sync' }, () => { if (syncPresenceRef.current) syncPresenceRef.current(channel.presenceState()); })
            .on('broadcast', { event: 'student_action' }, ({ payload }: { payload: any }) => {
                const { seat, data, action } = payload;
                const st = { ...studentsRef.current };
                const activeSeat = Object.keys(st).find(s => st[s].studentId === data.studentId) || seat;

                if (action === 'depart') {
                    if (st[activeSeat]) {
                        supabaseClient.from('clinic_session_state').update({ seat: null, manual_seat: null }).eq('student_id', st[activeSeat].studentId).then();
                        appendLog('border-slate-800', 'bg-slate-900 text-white', '퇴실완료', `[${activeSeat}] ${st[activeSeat].name} 퇴실`, `정상 로그아웃 되었습니다.`);
                        delete st[activeSeat];
                    }
                } else if (st[activeSeat]) {
                    if (action === 'update_activity') { st[activeSeat].activity = data.activity; }
                    else if (action === 'typing') {
                        st[activeSeat].isTyping = true;
                        if (st[activeSeat].typingTimeout) clearTimeout(st[activeSeat].typingTimeout);
                        st[activeSeat].typingTimeout = setTimeout(() => {
                            if (studentsRef.current[activeSeat]) updateStudents({ ...studentsRef.current, [activeSeat]: { ...studentsRef.current[activeSeat], isTyping: false } });
                        }, 2000);
                    } else if (action === 'call') {
                        st[activeSeat].calls[data.qNum] = Date.now(); st[activeSeat].status = 'call';
                        appendLog('border-rose-500', 'bg-rose-100 text-rose-600', '질문호출', `[${activeSeat}] ${data.name} 질문 요청`, `${data.qNum}번 문항 설명 대기 중`, 'call', { seat: activeSeat, qNum: data.qNum });
                    } else if (action === 'cancel_call') {
                        delete st[activeSeat].calls[data.qNum];
                        if (Object.keys(st[activeSeat].calls).length === 0) st[activeSeat].status = 'idle';
                        removeLogsByTypeAndSeat('call', activeSeat, data.qNum);
                    } else if (action === 'away') {
                        st[activeSeat].status = 'away'; st[activeSeat].awaySince = Date.now();
                        appendLog('border-amber-500', 'bg-amber-100 text-amber-700', '자리비움', `[${activeSeat}] ${data.name} 자리비움`, `학생이 자리를 비웠습니다.`, 'away', { seat: activeSeat });
                    } else if (action === 'cancel_away') {
                        st[activeSeat].status = 'idle'; st[activeSeat].awaySince = null;
                        removeLogsByTypeAndSeat('away', activeSeat);
                    } else if (action === 'hint') {
                        st[activeSeat].status = 'hint'; st[activeSeat].lastHint = { qNum: data.qNum, level: data.level, at: Date.now() }; st[activeSeat].totalHints = (st[activeSeat].totalHints || 0) + 1;
                        setTimeout(() => { if (studentsRef.current[activeSeat]?.status === 'hint') updateStudents({ ...studentsRef.current, [activeSeat]: { ...studentsRef.current[activeSeat], status: 'idle' } }); }, 10000);
                    } else if (action === 'submit') {
                        st[activeSeat].status = 'submitted'; st[activeSeat].score = data.score;
                        appendLog('border-blue-500', 'bg-blue-100 text-blue-600', '답안제출', `[${activeSeat}] ${data.name} 제출`, `최종 점수 [${data.score} / 5].`);
                    } else if (action === 'recheck_request') {
                        if (!st[activeSeat].rechecks) st[activeSeat].rechecks = {};
                        st[activeSeat].rechecks[data.uid] = { ...data, seat: activeSeat };
                        appendLog('border-indigo-500', 'bg-indigo-100 text-indigo-600', '재확인요청', 
                            <span className="underline decoration-dotted cursor-pointer hover:text-indigo-600" onClick={() => setRecheckModal({ isOpen: true, seat: activeSeat, uid: data.uid })}>{data.name}</span>, 
                            `${data.qNum}번 문항 · 직접 확인하세요.`, 'recheck', { seat: activeSeat, uid: data.uid }
                        );
                    }
                }
                updateStudents(st);
            })
            .on('broadcast', { event: 'ta_action' }, ({ payload }: { payload: any }) => handleTaActionFromOtherScreen(payload))
            .subscribe((status: string) => setConnectionStatus(status === 'SUBSCRIBED' ? 'connected' : status === 'CHANNEL_ERROR' || status === 'TIMED_OUT' ? 'error' : 'connecting'));

        return () => { supabaseClient.removeChannel(channel); };
    }, [isAuthorized, updateStudents, appendLog, removeLogsByTypeAndSeat]);

    const syncActiveStudentsFromPresence = (presenceState: any) => {
        const currentStudents = { ...studentsRef.current };
        const presenceByStudentId: any = {};
        const newActiveTAs: any = {};

        Object.values(presenceState).forEach((metas: any) => {
            let latestMeta = metas.reduce((prev: any, curr: any) => (curr.updatedAt || 0) > (prev.updatedAt || 0) ? curr : prev, metas[0]);
            if (!latestMeta) return;

            if (latestMeta.role === 'ta') {
                const key = latestMeta.clientId || latestMeta.name;
                newActiveTAs[key] = { name: latestMeta.name || '이름 미상', joined_at: latestMeta.joined_at || Date.now(), handling: latestMeta.handling || null, clientId: latestMeta.clientId || key };
            } else if (latestMeta.studentId) {
                if (!presenceByStudentId[latestMeta.studentId] || latestMeta.updatedAt > presenceByStudentId[latestMeta.studentId].lastUpdatedAt) {
                    presenceByStudentId[latestMeta.studentId] = { ...latestMeta, lastUpdatedAt: latestMeta.updatedAt };
                }
            }
        });

        let isModified = false;
        Object.keys(currentStudents).forEach(seat => {
            const st = currentStudents[seat];
            if (st.dummy || !st.studentId) return;
            const pData = presenceByStudentId[st.studentId];
            const remainingMs = (st.firstSeenAt + st.clinicDurationMs) - Date.now();
            
            if (!pData) {
                if (remainingMs > 0 && st.offlineSince !== null) { st.offlineSince = null; isModified = true; }
                else if (remainingMs <= 0 && !st.offlineSince) { st.offlineSince = Date.now(); isModified = true; }
            } else {
                if (st.offlineSince) { st.offlineSince = null; isModified = true; }
                st.lastUpdatedAt = pData.lastUpdatedAt;
                if (pData.activity && st.activity !== pData.activity) { st.activity = pData.activity; isModified = true; }
            }
        });
        setActiveTAs(newActiveTAs);
        if (isModified) updateStudents(currentStudents);
    };
    syncPresenceRef.current = syncActiveStudentsFromPresence;

    useEffect(() => {
        const handlePointerMove = (e: PointerEvent) => {
            if (!draggedSeat && !draggedListStudent) return;
            const ghost = document.getElementById('drag-ghost');
            if (ghost) { ghost.style.left = `${e.clientX + 10}px`; ghost.style.top = `${e.clientY + 10}px`; }
            const elements = document.elementsFromPoint(e.clientX, e.clientY);
            const cell = elements.find(el => el.getAttribute('data-seat'));
            document.querySelectorAll('[data-seat]').forEach(el => el.classList.remove('ring-4', 'ring-indigo-400'));
            if (cell) {
                const targetSeat = cell.getAttribute('data-seat');
                if (targetSeat && targetSeat !== draggedSeat && !studentsRef.current[targetSeat]) {
                    cell.classList.add('ring-4', 'ring-indigo-400');
                }
            }
        };

        const handlePointerUp = async (e: PointerEvent) => {
            if (!draggedSeat && !draggedListStudent) return;
            document.querySelectorAll('[data-seat]').forEach(el => el.classList.remove('ring-4', 'ring-indigo-400'));
            const elements = document.elementsFromPoint(e.clientX, e.clientY);
            const cell = elements.find(el => el.getAttribute('data-seat'));
            
            if (draggedListStudent) {
                if (cell) {
                    const targetSeat = cell.getAttribute('data-seat')!;
                    if (!studentsRef.current[targetSeat]) {
                        if (window.confirm(`${draggedListStudent.name} 학생을 [${targetSeat}] 자리에 강제 배정하시겠습니까?`)) {
                            supabaseClient.from('clinic_session_state').upsert({
                                student_id: draggedListStudent.id, session_date: getKSTDateString(), started_at: new Date().toISOString(), duration_ms: DEFAULT_CLINIC_DURATION_MS, seat: targetSeat, manual_seat: targetSeat
                            }).then();

                            const currentStudents = { ...studentsRef.current };
                            currentStudents[targetSeat] = { name: draggedListStudent.name, classes: draggedListStudent.classes, status: 'idle', studentId: draggedListStudent.id, firstSeenAt: Date.now(), clinicDurationMs: DEFAULT_CLINIC_DURATION_MS, totalCalls: 0, totalHints: 0, calls: {}, offlineSince: null, activity: '수동 배정됨' };
                            updateStudents(currentStudents);
                            pendingMovesRef.current[targetSeat] = { newSeat: targetSeat, expiresAt: Date.now() + 5000 };
                            
                            // 💡 추가됨: 수동배정 시 로그
                            appendLog('border-indigo-500', 'bg-indigo-100 text-indigo-700', '수동배정', `[${targetSeat}] ${draggedListStudent.name}`, `목록에서 수동 배정했습니다.`);
                        }
                    } else alert('이미 다른 학생이 있는 자리입니다.');
                }
                setDraggedListStudent(null);
                return;
            }

            if (cell) {
                const targetSeat = cell.getAttribute('data-seat')!;
                if (targetSeat !== draggedSeat && !studentsRef.current[targetSeat]) {
                    const studentId = studentsRef.current[draggedSeat!]?.studentId;
                    const sName = studentsRef.current[draggedSeat!]?.name || '학생';
                    
                    if (window.confirm(`${sName} 학생을 ${draggedSeat}에서 ${targetSeat}으로 이동하시겠습니까?`)) {
                        if (studentId) supabaseClient.from('clinic_session_state').update({ seat: targetSeat, manual_seat: targetSeat }).eq('student_id', studentId).then();
                        const currentStudents = { ...studentsRef.current };
                        currentStudents[targetSeat] = currentStudents[draggedSeat!];
                        delete currentStudents[draggedSeat!];
                        updateStudents(currentStudents);
                        sendToStudent(draggedSeat!, 'move_seat', { newSeat: targetSeat });
                        pendingMovesRef.current[draggedSeat!] = { newSeat: targetSeat, expiresAt: Date.now() + 5000 };

                        // 💡 추가됨: 좌석 이동 시 로그
                        appendLog('border-indigo-500', 'bg-indigo-100 text-indigo-700', '좌석이동', `[${draggedSeat} → ${targetSeat}] ${sName} 좌석 변경`, `수동으로 좌석을 옮겼습니다.`);
                    }
                } else if (studentsRef.current[targetSeat] && targetSeat !== draggedSeat) {
                    alert('빈 자리로만 옮길 수 있습니다.');
                }
            }
            setDraggedSeat(null); setSelectedSeatForMove(null);
        };

        if (draggedSeat || draggedListStudent) {
            document.addEventListener('pointermove', handlePointerMove);
            document.addEventListener('pointerup', handlePointerUp);
        }
        return () => {
            document.removeEventListener('pointermove', handlePointerMove);
            document.removeEventListener('pointerup', handlePointerUp);
        };
    }, [draggedSeat, draggedListStudent, updateStudents, appendLog]);

    const handlePointerDown = (e: React.PointerEvent, seat: string) => {
        if (e.button !== 0 || !activeStudents[seat] || (e.target as HTMLElement).closest('button')) return;
        setDraggedSeat(seat); setSelectedSeatForMove(seat); e.preventDefault();
    };

    const handleListPointerDown = (e: React.PointerEvent, student: any) => {
        if (e.button !== 0) return;
        setDraggedListStudent(student); e.preventDefault();
    };

    // 💡 변경됨: 시간 추가 액션 로그 
    const adjustClinicTime = async (seat: string, deltaMinutes: number) => {
        const st = studentsRef.current[seat];
        if (!st) return;
        const newDuration = Math.max(0, (st.clinicDurationMs || DEFAULT_CLINIC_DURATION_MS) + (deltaMinutes * 60 * 1000));
        const currentStudents = { ...studentsRef.current };
        currentStudents[seat].clinicDurationMs = newDuration;
        updateStudents(currentStudents);
        pendingTimeAdjustRef.current[seat] = { value: newDuration, expiresAt: Date.now() + 3000 };
        
        if (st.studentId) await supabaseClient.from('clinic_session_state').update({ duration_ms: newDuration }).eq('student_id', st.studentId);
        sendToStudent(seat, 'adjust_clinic_time', { deltaMs: deltaMinutes * 60 * 1000, newDuration, studentId: st.studentId || null });
        
        // 💡 추가됨: 시간조정 시 로그
        const sign = deltaMinutes > 0 ? '+' : '';
        appendLog('border-indigo-400', 'bg-indigo-100 text-indigo-700', '시간조정', `[${seat}] ${st.name} 이용시간 ${sign}${deltaMinutes}분 조정`, `총책임자가 클리닉 이용 가능 시간을 조정했습니다.`);
    };

    // 💡 변경됨: 강제 퇴실 액션 로그 
    const confirmForceCheckout = () => {
        const seat = forceCheckoutModal.seat;
        if (!seat) return;
        const currentStudents = { ...studentsRef.current };
        if (currentStudents[seat]) {
            const st = currentStudents[seat];
            sendToStudent(seat, 'force_checkout_by_ta');
            if (st.studentId) supabaseClient.from('clinic_session_state').update({ seat: null, manual_seat: null }).eq('student_id', st.studentId).then();
            removeLogsByTypeAndSeat('call', seat); 
            
            // 💡 추가됨: 강제퇴실 시 로그
            appendLog('border-rose-600', 'bg-rose-600 text-white', '강제퇴실', `[${seat}] ${st.name} 강제 퇴실 처리`, `수동으로 진행 중 강제 퇴실 처리되었습니다.`);
            
            delete currentStudents[seat];
            pendingDeletesRef.current[seat] = Date.now() + PENDING_GUARD_MS;
        }
        updateStudents(currentStudents);
        setForceCheckoutModal({ isOpen: false, seat: null });
    };

    // 💡 변경됨: 각종 조교 액션 로그 
    const taAction = (seat: string, type: string, qNum: any = null) => {
        const currentStudents = { ...studentsRef.current };
        const sName = currentStudents[seat]?.name || "학생";

        if (type === 'cancel_call') {
            if (qNum !== null) {
                if (currentStudents[seat]?.calls) delete currentStudents[seat].calls[qNum];
                if (Object.keys(currentStudents[seat]?.calls || {}).length === 0) currentStudents[seat].status = 'idle';
                removeLogsByTypeAndSeat('call', seat, qNum);
                sendToStudent(seat, 'force_cancel_call', { qNum: Number(qNum) });
                recordTaStat('총책임자', '');

                // 💡 추가됨: 호출해제 시 로그
                appendLog('border-slate-400', 'bg-slate-100 text-slate-600', '호출해제', `[${seat}] ${qNum}번 문항 지도 종료`, `${sName} 학생의 ${qNum}번 문항 관련 대면 설명이 끝나 호출을 해제했습니다.`);
            }
        } else if (type === 'clear_away') {
            if (currentStudents[seat]) { currentStudents[seat].status = 'idle'; currentStudents[seat].awaySince = null; }
            removeLogsByTypeAndSeat('away', seat); sendToStudent(seat, 'force_return_to_seat');
            
            // 💡 추가됨: 복귀처리 시 로그
            appendLog('border-slate-400', 'bg-slate-100 text-slate-600', '복귀처리', `[${seat}] ${sName} 자리비움 해제`, `수동으로 자리비움 상태를 해제했습니다.`);
        } else if (type === 'confirm_checkout') {
            if (currentStudents[seat]) {
                const st = currentStudents[seat]; sendToStudent(seat, 'force_checkout');
                if (st.studentId) supabaseClient.from('clinic_session_state').update({ seat: null, manual_seat: null }).eq('student_id', st.studentId).then();
                removeLogsByTypeAndSeat('submit', seat); delete currentStudents[seat];
                pendingDeletesRef.current[seat] = Date.now() + PENDING_GUARD_MS;

                // 💡 추가됨: 퇴실처리 시 로그
                appendLog('border-slate-800', 'bg-slate-900 text-white', '퇴실완료', `[${seat}] ${sName} 퇴실 처리`, `수동으로 퇴실 처리되어 자리가 반납되었습니다.`);
            }
        }
        updateStudents(currentStudents);
    };

    return {
        isAuthorized, authMessage,
        now, startedAt, connectionStatus, isMounted,
        activeStudents, activeTAs, taStats, logs,
        allStudents, leftTab, setLeftTab, expandedClasses, setExpandedClasses,
        draggedSeat, draggedListStudent, selectedSeatForMove,
        forceCheckoutModal, setForceCheckoutModal, recheckModal, setRecheckModal,
        handlePointerDown, handleListPointerDown, adjustClinicTime, confirmForceCheckout, taAction, sendToStudent, removeLogsByTypeAndSeat, appendLog
    };
}