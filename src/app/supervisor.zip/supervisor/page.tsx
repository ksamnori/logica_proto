// src/app/supervisor/page.tsx
"use client";

import React from 'react';
import { useSupervisorData } from './useSupervisorData';
import { formatDuration, seats } from './supervisorUtils';
import LeftPanel from './LeftPanel';
import SeatGrid from './SeatGrid';

export default function SupervisorDashboard() {
    const supervisorData = useSupervisorData();
    const { 
        isAuthorized, authMessage,
        now, startedAt, connectionStatus, isMounted,
        activeStudents, activeTAs, logs,
        draggedSeat, draggedListStudent, taAction
    } = supervisorData;

    // 1. 권한을 확인하고 있는 로딩 상태
    if (isAuthorized === null) {
        return (
            <div className="h-screen flex items-center justify-center bg-slate-200 font-['Pretendard']">
                <div className="bg-white p-8 rounded-2xl shadow-xl w-96 text-center border border-slate-200">
                    <div className="animate-spin text-4xl mb-4">⏳</div>
                    <h2 className="text-xl font-extrabold text-slate-800 mb-2">권한 확인 중</h2>
                    <p className="text-sm text-slate-500 font-bold">{authMessage}</p>
                </div>
            </div>
        );
    }

    // 2. 권한이 없는 경우 (접근 거부)
    if (isAuthorized === false) {
        return (
            <div className="h-screen flex items-center justify-center bg-slate-200 font-['Pretendard']">
                <div className="bg-white p-8 rounded-2xl shadow-xl max-w-md text-center border border-slate-200">
                    <div className="text-5xl mb-4">⛔</div>
                    <h2 className="text-2xl font-extrabold text-rose-600 mb-2">접근 권한 없음</h2>
                    <p className="text-sm text-slate-600 mb-6 font-bold leading-relaxed">{authMessage}</p>
                    <p className="text-xs text-slate-400 mb-6">수퍼바이저 대시보드는 <span className="text-[#002864] font-extrabold">원장</span> 및 <span className="text-[#002864] font-extrabold">실장</span> 권한만 접속할 수 있습니다.</p>
                    <button onClick={() => window.history.back()} className="w-full bg-slate-800 hover:bg-slate-900 text-white font-bold py-3 rounded-lg shadow-md transition-colors">이전 화면으로 돌아가기</button>
                </div>
            </div>
        );
    }

    // 3. 정상 접속 (대시보드 렌더링)
    const studentCount = Object.keys(activeStudents).length;
    const vacantCount = Math.max(0, seats.length - studentCount);
    let callingCount = 0, hintingCount = 0, awayCount = 0, timeUrgentCount = 0;

    Object.values(activeStudents).forEach((st: any) => {
        if (st.status === 'away') awayCount++;
        if (st.status === 'hint') hintingCount++;
        if (st.firstSeenAt && st.clinicDurationMs && (st.firstSeenAt + st.clinicDurationMs) - now <= 5 * 60 * 1000) timeUrgentCount++;
        if (st.calls && Object.keys(st.calls).length > 0) callingCount++;
    });

    return (
        <div className="h-screen flex flex-col overflow-hidden bg-slate-200 font-['Pretendard']">
            <style dangerouslySetInnerHTML={{ __html: `
                @import url('https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/static/pretendard.css');
                @keyframes pulse-red { 0%, 100% { border-color: #ef4444; box-shadow: 0 0 0 0 rgba(239, 68, 68, 0.4); } 50% { border-color: #fca5a5; box-shadow: 0 0 0 6px rgba(239, 68, 68, 0); } }
                .status-help { animation: pulse-red 1.2s infinite; background-color: #fef2f2; border: 2px solid #ef4444; }
                @keyframes flash-yellow { 0%, 100% { background-color: white; } 50% { background-color: #fef9c3; border-color: #eab308; } }
                .hint-flash { animation: flash-yellow 1.5s ease-in-out infinite; }
                @keyframes blink-dot { 0%, 100% { opacity: 1; } 50% { opacity: .35; } }
                .dot-live { animation: blink-dot 1.6s ease-in-out infinite; }
                ::-webkit-scrollbar { width: 7px; height: 7px; }
                ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
            `}} />

            {/* 마우스 고스트 영역 (드래그 시 사용) */}
            {draggedSeat && activeStudents[draggedSeat] && (
                <div id="drag-ghost" className="fixed pointer-events-none z-[9999] opacity-90 shadow-2xl scale-105 bg-white border border-slate-200 rounded-xl p-3 flex flex-col w-[160px] min-h-[196px]">
                    <span className="bg-[#002864] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-sm w-max mb-1">{draggedSeat}</span>
                    <div className="font-bold text-slate-900 text-[13px] mt-auto">{activeStudents[draggedSeat].name}</div>
                </div>
            )}
            {draggedListStudent && (
                <div id="drag-ghost" className="fixed pointer-events-none z-[9999] opacity-90 shadow-2xl scale-105 bg-white border border-slate-200 rounded-xl p-3 flex flex-col w-[160px] min-h-[100px]">
                    <span className="bg-indigo-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-sm w-max mb-1">신규 배정</span>
                    <div className="font-bold text-slate-900 text-[13px] mt-auto">{draggedListStudent.name}</div>
                </div>
            )}

            <header className="bg-gradient-to-r from-[#002864] to-[#013a8f] text-white px-8 py-3.5 flex justify-between items-center shadow-md z-20 shrink-0">
                <div>
                    <h1 className="text-xl font-bold">Logica Clinic <span className="text-blue-300 mx-1">—</span> 총책임자 대시보드</h1>
                    <p className="text-[11px] text-blue-300/80 mt-0.5">전체 클리닉 통합 관제 · Supabase Realtime 기반</p>
                </div>
                <div className="flex items-center gap-4">
                    <div className="text-right pr-4 border-r border-white/15">
                        <div className="text-lg font-bold font-mono">{isMounted ? new Date(now).toLocaleTimeString('ko-KR', { hour12: false }) : '--:--:--'}</div>
                        <div className="text-[10px] text-blue-300/80">가동 시간 <span>{isMounted ? formatDuration(now - startedAt) : '00:00'}</span></div>
                    </div>
                    <span className={`w-2.5 h-2.5 rounded-full shrink-0 dot-live ${connectionStatus === 'connected' ? 'bg-green-500' : connectionStatus === 'error' ? 'bg-rose-500' : 'bg-slate-400'}`}></span>
                    <div className="flex items-center gap-1.5 flex-wrap justify-end">
                        <div className="flex items-center gap-1.5 bg-white/[0.07] px-2.5 py-1.5 rounded-lg text-[13px] font-semibold"><span className="w-2 h-2 rounded-full bg-red-400 shrink-0"></span> 조교 {Object.keys(activeTAs).length}명</div>
                        <div className="flex items-center gap-1.5 bg-white/[0.07] px-2.5 py-1.5 rounded-lg text-[13px] font-semibold"><span className="w-2 h-2 rounded-full bg-blue-300 shrink-0"></span> 학생 {studentCount}명</div>
                        <div className="flex items-center gap-1.5 bg-white/[0.07] px-2.5 py-1.5 rounded-lg text-[13px] font-semibold"><span className="w-2 h-2 rounded-full bg-slate-400 shrink-0"></span> 공석 {vacantCount}석</div>
                        <div className="flex items-center gap-1.5 bg-rose-500/15 px-2.5 py-1.5 rounded-lg text-[13px] font-semibold">🚨 호출대기 {callingCount}건</div>
                    </div>
                </div>
            </header>

            <div className="flex flex-1 overflow-hidden">
                <LeftPanel data={supervisorData} />
                <SeatGrid data={supervisorData} />

                {/* 우측 라이브 로그 영역 */}
                <aside className="w-[400px] bg-white border-l border-slate-300 flex flex-col h-full shadow-2xl z-10 shrink-0">
                    <div className="bg-slate-800 text-white px-5 py-3 font-bold text-sm flex justify-between items-center shrink-0">
                        <span>⚡ 현장 라이브 로그</span>
                        <span className="text-xs bg-rose-500 px-2 py-0.5 rounded animate-pulse">Live</span>
                    </div>
                    <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-slate-50">
                        {logs.length === 0 ? <div className="text-center text-xs text-slate-400 py-8">접수된 기록이 없습니다.</div> : logs.map((log: any) => (
                            <div key={log.id} className={`bg-white p-3 rounded-lg border-l-4 ${log.borderClass} shadow-sm`}>
                                <div className="flex justify-between items-start mb-1">
                                    <span className="text-[10px] font-bold text-slate-400">{log.timestamp}</span>
                                    <span className={`${log.badgeBg} text-[9px] font-bold px-1.5 py-0.5 rounded`}>{log.badgeText}</span>
                                </div>
                                <p className="text-sm font-bold text-slate-800">{log.title}</p>
                                <p className="text-xs text-slate-600 mt-0.5 leading-relaxed">{log.subtitle}</p>
                                {log.type === 'call' && <button onClick={() => taAction(log.data.seat, 'cancel_call', log.data.qNum)} className="mt-2 w-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold py-1.5 rounded transition-colors">호출 종료</button>}
                            </div>
                        ))}
                    </div>
                </aside>
            </div>
        </div>
    );
}