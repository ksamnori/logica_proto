// src/app/supervisor/SeatGrid.tsx
import React from 'react';
import { seats, formatDuration, formatShortAgo } from './supervisorUtils';

export default function SeatGrid({ data }: { data: any }) {
    const {
        now, isMounted, activeStudents, draggedSeat, draggedListStudent, selectedSeatForMove,
        forceCheckoutModal, setForceCheckoutModal, recheckModal, setRecheckModal, confirmForceCheckout,
        handlePointerDown, adjustClinicTime, taAction, sendToStudent, appendLog, removeLogsByTypeAndSeat
    } = data;

    return (
        <main className="flex-1 p-6 bg-slate-200 overflow-y-auto relative">
            <p className="text-xs text-slate-500 font-bold mb-3">💡 학생 카드를 드래그해서 빈 자리에 놓으면 좌석을 옮길 수 있어요.</p>
            <div className="grid grid-cols-10 gap-3">
                {seats.map(seat => {
                    const student = activeStudents[seat];
                    if (!student) {
                        return (
                            <div key={seat} data-seat={seat}
                                 className={`bg-slate-100/50 border-2 border-dashed ${(draggedSeat || draggedListStudent) && selectedSeatForMove !== seat ? 'border-indigo-300 opacity-100 bg-indigo-50/50' : 'border-slate-300 opacity-60'} rounded-xl p-2 flex flex-col items-center justify-center transition-colors min-h-[196px]`}>
                                <span className="text-slate-400 text-[10px] font-bold pointer-events-none">{seat}</span>
                            </div>
                        );
                    }

                    const isOffline = !!student.offlineSince;
                    const isCall = student.status === 'call';
                    const isHint = student.status === 'hint';
                    const isAway = student.status === 'away';
                    const isSubmitted = student.status === 'submitted';
                    const isDragging = draggedSeat === seat;
                    
                    const cardClass = isOffline ? 'bg-slate-100 border-slate-300 opacity-70 grayscale-[50%]' 
                                    : isCall ? 'status-help bg-white' 
                                    : isHint ? 'hint-flash bg-white border-slate-200' 
                                    : isAway ? 'bg-amber-50 border-amber-400' 
                                    : isSubmitted ? 'bg-blue-50 border-blue-400' 
                                    : 'bg-white border-slate-200 hover:shadow-md hover:border-slate-300';
                    
                    const badgeBg = isOffline ? 'bg-slate-500 text-white' : isCall ? 'bg-rose-600 text-white' : isHint ? 'bg-yellow-400 text-yellow-900' : isAway ? 'bg-amber-500 text-white' : isSubmitted ? 'bg-blue-600 text-white' : 'bg-emerald-100 text-emerald-700';
                    const badgeText = isOffline ? '⚫ 오프라인' : isCall ? `🚨 ${Object.keys(student.calls || {}).length}` : isHint ? '💡 힌트' : isAway ? '🚶 자리비움' : isSubmitted ? '✅ 완료' : '🟢 온라인';
                    
                    const remainingMs = (student.firstSeenAt + student.clinicDurationMs) - now;
                    const isUrgent = remainingMs <= 5 * 60 * 1000;
                    const calls = Object.entries(student.calls || {}).sort(([, a]:any, [, b]:any) => a - b);
                    const oldestCallAt = calls.length > 0 ? calls[0][1] : null;

                    return (
                        <div key={seat} data-seat={seat} onPointerDown={(e) => handlePointerDown(e, seat)}
                             className={`relative border ${isAway || isSubmitted ? 'border-2' : ''} rounded-xl p-3 flex flex-col justify-between shadow-sm cursor-grab active:cursor-grabbing min-h-[196px] transition-all duration-300 ${cardClass} ${isDragging ? 'opacity-35 ring-4 ring-indigo-500 ring-offset-1' : ''}`}>
                            <button onClick={(e) => { e.stopPropagation(); setForceCheckoutModal({ isOpen: true, seat }); }} title="강제 퇴실" className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 hover:bg-rose-600 text-white rounded-full flex items-center justify-center shadow-md border-2 border-white z-30 transition-transform hover:scale-125">
                                <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="4"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                            <div className="flex justify-between items-start mb-1 pointer-events-none">
                                <span className="bg-[#002864] text-white text-[9px] font-bold px-1.5 py-0.5 rounded shadow-sm">{seat}</span>
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${badgeBg}`}>{badgeText}</span>
                            </div>
                            <div className="mt-auto pointer-events-none">
                                <div className="font-bold text-slate-900 text-[13px] truncate" title={student.name}>{student.name}</div>
                                {student.classes?.length > 0 ? (
                                    <div className="text-[9px] font-bold text-emerald-600 truncate mb-1">{student.classes[0]}</div>
                                ) : <div className="text-[9px] font-bold text-slate-300 truncate mb-1">반 없음</div>}
                                
                                {student.activity && (
                                    <div className="text-[10px] font-bold text-indigo-600 truncate mb-1 flex items-center gap-1">{student.activity} {student.isTyping && <span className="animate-pulse">✍️</span>}</div>
                                )}
                                <div className="flex items-center gap-2 mt-1 text-[9px] text-slate-400 font-bold">
                                    <span>⏱ <span className="tabular-nums">{isMounted ? formatDuration(now - student.firstSeenAt) : '00:00'}</span></span>
                                    {student.totalCalls > 0 && <span className="text-rose-400">🚨×{student.totalCalls}</span>}
                                    {student.totalHints > 0 && <span className="text-amber-400">💡×{student.totalHints}</span>}
                                </div>
                                {isAway && <div className="text-[10px] font-bold text-amber-600 mt-1">비운 지 <span className="tabular-nums">{isMounted ? formatDuration(now - student.awaySince) : '00:00'}</span></div>}
                                {isCall && oldestCallAt && <div className="text-[10px] font-bold text-rose-600 mt-1">대기 <span className="tabular-nums">{isMounted ? formatDuration(now - Number(oldestCallAt)) : '00:00'}</span></div>}
                                {student.lastHint && <div className="text-[9px] font-bold text-indigo-400 mt-1 truncate">최근 힌트 Q{student.lastHint.qNum} ({isMounted ? formatShortAgo(now - student.lastHint.at) : '방금'} 전)</div>}

                                <div className="pointer-events-auto">
                                    {isAway && <button onClick={(e) => { e.stopPropagation(); taAction(seat, 'clear_away'); }} className="w-full bg-amber-100 text-amber-700 text-[10px] font-bold py-1.5 rounded border border-amber-300 mt-1.5">복귀 처리</button>}
                                    {isSubmitted && (
                                        <div className="flex flex-col gap-1 mt-1.5">
                                            <div className="bg-white border border-blue-200 rounded text-center py-0.5 text-[10px] font-bold text-blue-800">{student.score}/5점</div>
                                            <button onClick={(e) => { e.stopPropagation(); taAction(seat, 'confirm_checkout'); }} className="bg-slate-800 text-white text-[10px] font-bold py-1.5 rounded">퇴실처리</button>
                                        </div>
                                    )}
                                </div>

                                {student.firstSeenAt && student.clinicDurationMs != null && (
                                    <div className={`flex items-center justify-between mt-1.5 pt-1.5 border-t border-slate-100 pointer-events-auto ${isUrgent ? 'text-rose-600' : 'text-slate-400'}`}>
                                        <span className="text-[9px] font-bold whitespace-nowrap">⏳ <span className="tabular-nums">{isMounted ? formatDuration(remainingMs) : '00:00'}</span></span>
                                        <div className="flex items-center rounded-md border border-slate-200 overflow-hidden shadow-sm shrink-0">
                                            <button onClick={(e) => { e.stopPropagation(); adjustClinicTime(seat, -10); }} className="w-5 h-5 flex items-center justify-center bg-white text-slate-400 leading-none">-</button>
                                            <span className="w-px h-3.5 bg-slate-200"></span>
                                            <button onClick={(e) => { e.stopPropagation(); adjustClinicTime(seat, 10); }} className="w-5 h-5 flex items-center justify-center bg-white text-slate-400 leading-none">+</button>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    );
                })}
            </div>

            {/* 강제 퇴실 모달 */}
            {forceCheckoutModal.isOpen && (
                <div className="fixed inset-0 bg-slate-900/40 flex items-center justify-center z-50 backdrop-blur-sm">
                    <div className="bg-white rounded-2xl shadow-2xl p-6 w-[340px] text-center">
                        <div className="text-4xl mb-3">🚪</div>
                        <h3 className="text-lg font-extrabold text-slate-800 mb-2">강제 퇴실 확인</h3>
                        <p className="text-sm text-slate-600 mb-6"><span className="font-bold text-rose-600">{activeStudents[forceCheckoutModal.seat!]?.name}</span> 학생을 퇴실시키겠습니까?</p>
                        <div className="flex gap-2">
                            <button onClick={() => setForceCheckoutModal({ isOpen: false, seat: null })} className="flex-1 bg-slate-100 text-slate-600 font-bold py-3 rounded-lg">취소</button>
                            <button onClick={confirmForceCheckout} className="flex-1 bg-rose-600 text-white font-bold py-3 rounded-lg">강제 퇴실</button>
                        </div>
                    </div>
                </div>
            )}

            {/* AI 재확인 모달 (💡 변경됨: 액션 후 로그 출력) */}
            {recheckModal.isOpen && (
                <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-40 px-4">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden">
                        <div className="bg-indigo-600 text-white px-5 py-3 flex justify-between items-center">
                            <span className="font-bold text-sm">🔄 AI 채점 재확인</span>
                            <button onClick={() => setRecheckModal({ isOpen: false, seat: null, uid: null })} className="text-white/80 hover:text-white">✕</button>
                        </div>
                        <div className="p-5 space-y-3 max-h-[70vh] overflow-y-auto">
                            <img className="w-full rounded-lg border border-slate-200" src={activeStudents[recheckModal.seat!]?.rechecks?.[recheckModal.uid!]?.imageDataUrl || ''} alt="답안" />
                        </div>
                        <div className="flex gap-2 p-4 border-t border-slate-100">
                            <button onClick={() => { 
                                const stName = activeStudents[recheckModal.seat!]?.name || '학생';
                                const qNum = activeStudents[recheckModal.seat!]?.rechecks?.[recheckModal.uid!]?.qNum || '?';
                                sendToStudent(recheckModal.seat!, 'resolve_recheck', { uid: recheckModal.uid, verdict: 'incorrect' }); 
                                removeLogsByTypeAndSeat('recheck', recheckModal.seat!, Number(recheckModal.uid)); 
                                appendLog('border-rose-500', 'bg-rose-100 text-rose-600', '재확인·오답', `[${recheckModal.seat!}] ${stName} 재확인 결과: 오답 처리`, `${qNum}번 문항 · 총책임자가 이미지를 직접 확인해 처리했습니다.`);
                                setRecheckModal({ isOpen: false, seat: null, uid: null }); 
                            }} className="flex-1 bg-rose-50 text-rose-600 font-bold py-3 rounded-xl">❌ 오답</button>
                            
                            <button onClick={() => { 
                                const stName = activeStudents[recheckModal.seat!]?.name || '학생';
                                const qNum = activeStudents[recheckModal.seat!]?.rechecks?.[recheckModal.uid!]?.qNum || '?';
                                sendToStudent(recheckModal.seat!, 'resolve_recheck', { uid: recheckModal.uid, verdict: 'correct' }); 
                                removeLogsByTypeAndSeat('recheck', recheckModal.seat!, Number(recheckModal.uid)); 
                                appendLog('border-emerald-500', 'bg-emerald-100 text-emerald-600', '재확인·정답', `[${recheckModal.seat!}] ${stName} 재확인 결과: 정답 처리`, `${qNum}번 문항 · 총책임자가 이미지를 직접 확인해 처리했습니다.`);
                                setRecheckModal({ isOpen: false, seat: null, uid: null }); 
                            }} className="flex-1 bg-emerald-600 text-white font-bold py-3 rounded-xl">✅ 정답</button>
                        </div>
                    </div>
                </div>
            )}
        </main>
    );
}