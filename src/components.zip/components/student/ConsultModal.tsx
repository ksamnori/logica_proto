// src/components/student/ConsultModal.tsx
"use client";

import React, { useState, useEffect } from "react";
import { supabase } from "@/lib/supabase";

interface ConsultModalProps {
  isOpen: boolean;
  studentId: string;
  instId: string;
  logData: any | null;
  onClose: () => void;
  onSuccess: () => void;
}

export default function ConsultModal({ isOpen, studentId, instId, logData, onClose, onSuccess }: ConsultModalProps) {
  // 🌟 summary(상담 주제) 상태 추가
  const [consultForm, setConsultForm] = useState({ 
    logId: null as any, 
    type: "재원상담", 
    method: "전화", 
    summary: "", 
    content: "" 
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (logData) {
        setConsultForm({ 
          logId: logData.consultation_log_id || logData.id, 
          type: logData.consultation_type, 
          method: logData.contact_method, 
          summary: logData.parent_summary || "", // 기존 데이터 불러오기
          content: logData.content 
        });
      } else {
        setConsultForm({ logId: null, type: "재원상담", method: "전화", summary: "", content: "" });
      }
    }
  }, [isOpen, logData]);

  const submitConsultLog = async () => {
    if (!consultForm.content.trim()) return alert("상담 내용을 입력해주세요.");
    
    const myTenantId = localStorage.getItem("logica_tenant_id");

    setIsSaving(true);
    try {
      if (consultForm.logId) {
        // 🌟 수정 시 parent_summary 업데이트
        const { error } = await supabase.from("consultation_log")
          .update({ 
            consultation_type: consultForm.type, 
            contact_method: consultForm.method, 
            parent_summary: consultForm.summary,
            content: consultForm.content 
          })
          .eq("consultation_log_id", consultForm.logId);

        if (error) throw error;
      } else {
        if (!myTenantId) {
           alert("소속 지점 정보가 없어 저장할 수 없습니다. 새로고침 해주세요.");
           setIsSaving(false);
           return;
        }
        // 🌟 등록 시 parent_summary 포함
        const { error } = await supabase.from("consultation_log").insert({ 
            student_id: studentId, 
            instructor_id: instId, 
            consultation_type: consultForm.type, 
            contact_method: consultForm.method, 
            parent_summary: consultForm.summary,
            content: consultForm.content,
            tenant_id: myTenantId
        });
        if (error) throw error;
      }
      onSuccess();
      onClose();
    } catch (e: any) { 
      alert("상담 기록 저장 실패: " + e.message); 
    } finally {
      setIsSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm flex justify-center items-center z-50 p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl flex flex-col transform transition-all animate-[fadeIn_0.2s_ease-out]">
        <div className="bg-indigo-600 p-5 text-white flex justify-between items-center shrink-0 rounded-t-2xl">
          <h3 className="text-lg font-extrabold flex items-center gap-2"><svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"></path></svg>{consultForm.logId ? '상담 기록 수정' : '새 상담 기록 등록'}</h3>
          <button onClick={onClose} className="text-white hover:text-rose-200 transition-colors"><svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
        </div>
        <div className="p-6 space-y-5 bg-slate-50">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">상담 유형</label>
              <select value={consultForm.type} onChange={(e: any)=>setConsultForm({...consultForm, type: e.target.value})} className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-sm font-bold focus:outline-none focus:border-indigo-500">
                <option value="재원상담">재원상담</option><option value="신규상담">신규상담</option><option value="퇴원상담">퇴원상담</option><option value="성적상담">성적상담</option><option value="태도상담">태도상담</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">연락 방법</label>
              <select value={consultForm.method} onChange={(e: any)=>setConsultForm({...consultForm, method: e.target.value})} className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-sm font-bold focus:outline-none focus:border-indigo-500">
                <option value="전화">전화</option><option value="방문">방문</option><option value="채널톡">학원 메신저</option><option value="문자/카톡">문자/카카오톡</option>
              </select>
            </div>
          </div>
          
          {/* 🌟 학부모 노출용 상담 주제 인풋 추가 */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">
              상담 주제 <span className="text-indigo-500 font-normal ml-1">(학부모 앱 노출)</span>
            </label>
            <input 
              type="text" 
              value={consultForm.summary} 
              onChange={(e: any) => setConsultForm({...consultForm, summary: e.target.value})} 
              placeholder="예: 9월 모의고사 성적 분석 및 향후 학습 방향" 
              className="w-full bg-white border border-slate-300 rounded-lg px-3 py-2.5 text-sm font-bold focus:outline-none focus:border-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">
              상세 내용 <span className="text-rose-500 font-normal ml-1">(학원 내부용)</span>
            </label>
            <textarea rows={4} value={consultForm.content} onChange={(e: any)=>setConsultForm({...consultForm, content: e.target.value})} placeholder="선생님들만 볼 수 있는 상세 대화 내용을 기록해주세요." className="w-full bg-white border border-slate-300 rounded-lg px-3 py-3 text-sm focus:outline-none focus:border-indigo-500 resize-none"></textarea>
          </div>
        </div>
        <div className="p-5 bg-white border-t border-slate-200 flex justify-end gap-3 shrink-0 rounded-b-2xl">
          <button onClick={onClose} className="px-5 py-2.5 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-colors text-sm">취소</button>
          <button onClick={submitConsultLog} disabled={isSaving} className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-xl hover:bg-indigo-700 transition-colors shadow-md text-sm disabled:opacity-50">기록 저장</button>
        </div>
      </div>
    </div>
  );
}