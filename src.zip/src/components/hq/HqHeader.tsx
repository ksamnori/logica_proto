// src/components/hq/HqHeader.tsx
"use client";

import React, { useEffect, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useHqShell } from "./HqShellContext";
import { ATTENDANCE_MODES, getRankMeta } from "@/lib/hq/constants";
import { resolveStoragePublicUrl } from "@/lib/hq/clientApi";
import { useHqHref } from "@/lib/hq/hqRoutes";
import { toCanonicalHqPath } from "@/lib/hq/hqRouteUtils";

const PAGE_TITLES: Record<string, { title: string; subtitle: string }> = {
  "/hq": {
    title: "본부 홈 대시보드",
    subtitle: "오늘의 근무 현황 · 우선 결재/전자계약 · 출판 하판 마감 브리핑",
  },
  "/hq/notices": {
    title: "사내 공지사항",
    subtitle: "전사 · 부서별 주요 안내사항 · 게시 예약 및 구성원 댓글 소통",
  },
  "/hq/members": {
    title: "구성원 · 인사 정보 관리",
    subtitle: "본부 임직원 디렉토리 · 입퇴사 온보딩 체크리스트 · 인사 발령 관리",
  },
  "/hq/org-chart": {
    title: "본부 조직도",
    subtitle: "시점별 부서 트리 · 계약월급/유지율 트렌드 지표 · 조직 구조 설정",
  },
  "/hq/meetings": {
    title: "미팅 · 회의록 관리",
    subtitle: "사내 회의 일정 공유 · 참석 여부(RSVP) · 대화 기록 및 요약 아카이브",
  },
  "/hq/attendance": {
    title: "근무 · 유연근무 타임라인",
    subtitle: "내 근무 · 구성원 24h 타임라인 · 시차/원격/외근 체크인 및 주 52시간 관리",
  },
  "/hq/leaves": {
    title: "내 휴가 · 연차 현황",
    subtitle: "연차·맞춤휴가 신청 · 월별 자동부여/사용 상세 원장 · 연차 사용 계획",
  },
  "/hq/work-management": {
    title: "근태 관리 · 근무 관리",
    subtitle: "근태 대시보드 · 초과근무 보상 휴가 부여 · 휴일 대체 · 근태 마감 보호",
  },
  "/hq/leave-management": {
    title: "근태 관리 · 휴가 관리",
    subtitle: "당해 연말(12.31) 기준 잔여연차 보유현황 · 사용내역 · 월별 원장 · 스마트 연차 촉진",
  },
  "/hq/contracts": {
    title: "전자계약 · 저작권/외주 계약 관리",
    subtitle: "근로·연봉·비밀유지(NDA) 및 저자 출판권·외주 용역 전자서명",
  },
  "/hq/approvals": {
    title: "워크플로우",
    subtitle: "내 문서함 · 회사 문서함 · 문서 양식 관리 및 양식별 승인/참조 프로세스",
  },
  "/hq/expenses": {
    title: "비용 · 경비 정산 관리",
    subtitle: "지출결의 자동 연동 · 법인카드/인쇄비/영수증 정산 처리",
  },
  "/hq/payroll": {
    title: "급여 · 외주 원천세(3.3% / 8.8%) · 인세 정산",
    subtitle: "세무사 급여대장 엑셀 1클릭 명세서 배부 · 세무사 전달 기초자료 · 은행 대량이체 · 저자 인세/퇴직금",
  },
  "/hq/year-end-tax": {
    title: "연말정산 (서류 수합 · 원천징수영수증)",
    subtitle: "홈택스 간소화 PDF · 추가 증빙 간편 제출 및 근로소득 원천징수영수증 상시 보관함",
  },
  "/hq/insights": {
    title: "인사이트 (인력 · 인건비/경비 · 출판 지표)",
    subtitle: "본부 조직·연차 소진율, 급여·외주(3.3%)·저자인세·경비 추이 및 출판 공정 핵심 데이터",
  },
  "/hq/publishing": {
    title: "출판 기획 · 편집 마감 & ISBN 공정 보드",
    subtitle: "기획·원고검수·교정(1~3교)·디자인·인쇄하판·출간 파이프라인 관리",
  },
  "/hq/messenger": {
    title: "전사 소통 메신저",
    subtitle: "본부 부서 및 전국 가맹점 실시간 대화 · 조직도 검색",
  },
  "/hq/analytics": {
    title: "진단평가 데이터 분석",
    subtitle: "전국 지점 진단평가 성취도 및 문항 통계",
  },
  "/hq/contest-db": {
    title: "사고력 · 문장제 문제 DB",
    subtitle: "출판 연구소 전용 문항 검색 및 한국어 번역 관리",
  },
  "/hq/permissions": {
    title: "포털 메뉴 권한 관리",
    subtitle: "임직원별 연구 DB · 진단평가 분석 열람 권한 제어",
  },
  "/hq/settings": {
    title: "본부 환경 설정",
    subtitle: "회사 기본 정보 · 쉬는 날(공휴일) · 회사 직인 · 계열사 관리",
  },
};

function formatKstTime(iso?: string | null): string {
  if (!iso) return "";
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return "";
  return dt.toLocaleTimeString("ko-KR", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

export default function HqHeader() {
  const pathname = usePathname();
  const canonicalPath = toCanonicalHqPath(pathname);
  const router = useRouter();
  const hqHref = useHqHref();
  const {
    me,
    pendingApprovalCount,
    approvalAlertActive,
    newApprovalArrivedCount,
    dismissApprovalAlert,
    unreadChatCount,
    myTodayAttendance,
    sidebarCollapsed,
    toggleSidebar,
    chatDrawerOpen,
    toggleChatDrawer,
    canAccessMenu,
    quickCheckIn,
    quickCheckOut,
    openProfileModal,
    logout,
  } = useHqShell();

  const [clockBusy, setClockBusy] = useState(false);

  // 결재함에 진입하면 새 결재 도착 알림(깜빡임)을 자동 해제
  useEffect(() => {
    if (canonicalPath === "/hq/approvals" && approvalAlertActive) {
      dismissApprovalAlert();
    }
  }, [approvalAlertActive, canonicalPath, dismissApprovalAlert]);

  const meta = PAGE_TITLES[canonicalPath] || {
    title: "본부 워크스페이스",
    subtitle: "천종현수학연구소 HQ 통합 시스템",
  };

  const rankMeta = getRankMeta(me?.rank_code);
  const avatarUrl = resolveStoragePublicUrl(me?.profile_image_url);

  const handleQuickClockIn = async () => {
    setClockBusy(true);
    try {
      await quickCheckIn("OFFICE");
    } catch (err: any) {
      alert(err?.message || "출근 체크인 중 오류가 발생했습니다.");
    } finally {
      setClockBusy(false);
    }
  };

  const handleQuickClockOut = async () => {
    if (!confirm("오늘 업무를 마무리하고 퇴근 기록하시겠습니까?")) return;
    setClockBusy(true);
    try {
      await quickCheckOut();
    } catch (err: any) {
      alert(err?.message || "퇴근 처리 중 오류가 발생했습니다.");
    } finally {
      setClockBusy(false);
    }
  };

  const handleLogoutClick = () => {
    if (confirm("본부 워크스페이스에서 로그아웃 하시겠습니까?")) {
      logout();
    }
  };

  const modeMeta = myTodayAttendance
    ? ATTENDANCE_MODES[myTodayAttendance.work_mode] || ATTENDANCE_MODES.OFFICE
    : null;

  return (
    <header className="print:hidden h-16 bg-white border-b border-slate-200 px-4 sm:px-6 flex items-center justify-between gap-3 shrink-0 z-10">
      <div className="flex items-center gap-2.5 min-w-0">
        {sidebarCollapsed && (
          <button
            type="button"
            onClick={toggleSidebar}
            title="사이드바 펼치기"
            className="w-8 h-8 rounded-lg border border-slate-200 hover:bg-slate-100 text-slate-600 flex items-center justify-center text-sm font-bold shrink-0 transition-colors"
          >
            ◫
          </button>
        )}
        <div className="min-w-0">
          <h2 className="text-[15px] sm:text-[16px] font-bold text-slate-800 leading-tight truncate">
            {meta.title}
          </h2>
          <p className="text-xs text-slate-500 mt-0.5 truncate hidden sm:block">
            {meta.subtitle}
          </p>
        </div>
      </div>

      <div className="flex items-center gap-1.5 sm:gap-2 shrink-0 whitespace-nowrap">
        {/* 실시간 출퇴근 미니 위젯 */}
        {!myTodayAttendance ? (
          <div className="hidden lg:flex items-center rounded-xl border border-emerald-200 bg-emerald-50/70 p-0.5">
            <button
              type="button"
              disabled={clockBusy}
              onClick={handleQuickClockIn}
              className="px-2.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-colors disabled:opacity-50"
            >
              {clockBusy ? "처리중..." : "🟢 출근하기"}
            </button>
            <button
              type="button"
              onClick={() => router.push(hqHref("/hq/attendance"))}
              className="px-2 py-1.5 text-[11px] font-bold text-emerald-800 hover:underline"
              title="시차출퇴근 · 재택 · 외근 선택"
            >
              유연근무▾
            </button>
          </div>
        ) : myTodayAttendance.status === "WORKING" ? (
          <div
            className={`hidden lg:flex items-center gap-1.5 rounded-xl px-2.5 py-1 border ${
              myTodayAttendance.location_note === "자동 근무 기록"
                ? "border-teal-200 bg-teal-50/80"
                : "border-blue-200 bg-blue-50"
            }`}
          >
            <button
              type="button"
              onClick={() => router.push(hqHref("/hq/attendance"))}
              className={`text-xs font-bold hover:underline flex items-center gap-1 ${
                myTodayAttendance.location_note === "자동 근무 기록"
                  ? "text-teal-800"
                  : "text-blue-800"
              }`}
            >
              <span>
                {myTodayAttendance.location_note === "자동 근무 기록"
                  ? "⏱️"
                  : modeMeta?.icon || "🏢"}
              </span>
              <span>
                {myTodayAttendance.location_note === "자동 근무 기록"
                  ? "자동 기록 중"
                  : modeMeta?.shortLabel || "근무중"}{" "}
                {formatKstTime(myTodayAttendance.check_in_at)}~
              </span>
            </button>
            <button
              type="button"
              disabled={clockBusy}
              onClick={handleQuickClockOut}
              className="px-2 py-0.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-[11px] font-bold transition-colors disabled:opacity-50"
            >
              퇴근
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => router.push(hqHref("/hq/attendance"))}
            className="hidden lg:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 text-xs font-bold transition-colors"
          >
            <span>
              {myTodayAttendance.status === "DONE" ? "✅ 퇴근완료" : "🌴 휴가·반차"}
            </span>
            {myTodayAttendance.check_out_at && (
              <span className="text-[11px] text-slate-500">
                {formatKstTime(myTodayAttendance.check_out_at)}
              </span>
            )}
          </button>
        )}

        {pendingApprovalCount > 0 && canonicalPath !== "/hq/approvals" && (
          <div className="relative hidden sm:block">
            <button
              type="button"
              onClick={() => {
                dismissApprovalAlert();
                router.push(hqHref("/hq/approvals"));
              }}
              title={`내 결재 대기 문서 ${pendingApprovalCount}건`}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-xs font-bold transition-colors ${
                approvalAlertActive
                  ? "hq-approval-flash bg-rose-600 border-rose-600 text-white"
                  : "bg-rose-50 hover:bg-rose-100 border-rose-200 text-rose-700"
              }`}
            >
              <span className="hq-bell-ring inline-block">🔔</span>
              <span>결재 대기</span>
              <span
                className={`px-1.5 py-0.5 rounded-full text-[11px] leading-none ${
                  approvalAlertActive
                    ? "bg-white text-rose-600"
                    : "bg-rose-600 text-white"
                }`}
              >
                {pendingApprovalCount}건
              </span>
              {approvalAlertActive && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75 animate-ping" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-amber-400 ring-2 ring-white" />
                </span>
              )}
            </button>

            {/* 새 결재 도착 토스트 (모든 페이지 공통) */}
            {approvalAlertActive && newApprovalArrivedCount > 0 && (
              <div className="absolute right-0 top-full mt-2 w-72 rounded-2xl bg-white border border-rose-200 shadow-2xl p-3.5 z-50 whitespace-normal">
                <div className="flex items-start gap-2.5">
                  <span className="hq-bell-ring inline-block text-lg leading-none mt-0.5">
                    🔔
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="text-xs font-extrabold text-slate-900">
                      새 결재 문서가 도착했어요
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5 leading-relaxed">
                      내 승인을 기다리는 문서가 {newApprovalArrivedCount}건 새로
                      들어왔습니다. (총 {pendingApprovalCount}건 대기)
                    </p>
                    <div className="mt-2.5 flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() => {
                          dismissApprovalAlert();
                          router.push(hqHref("/hq/approvals"));
                        }}
                        className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-[11px] font-extrabold"
                      >
                        결재함 열기
                      </button>
                      <button
                        type="button"
                        onClick={dismissApprovalAlert}
                        className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 text-[11px] font-bold"
                      >
                        나중에
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <button
          type="button"
          onClick={() => router.push(hqHref("/hq/approvals?new=1"))}
          className="px-3.5 py-2 rounded-xl bg-brand hover:bg-brand-hover text-white text-xs font-bold shadow-sm transition-colors flex items-center gap-1.5"
        >
          <span>✍️</span>
          <span className="hidden sm:inline">새 결재 기안</span>
        </button>

        {canAccessMenu("/hq/messenger") && (
          <button
            type="button"
            onClick={() => {
              if (canonicalPath === "/hq/messenger") return;
              toggleChatDrawer();
            }}
            title={
              unreadChatCount > 0
                ? `사내 메신저 열기 (안 읽은 메시지 ${unreadChatCount}건)`
                : "사내 메신저 열기"
            }
            className={`relative px-3 py-2 rounded-xl border text-xs font-extrabold transition-all flex items-center gap-1.5 text-[#3c1e1e] shadow-xs ${
              chatDrawerOpen || canonicalPath === "/hq/messenger"
                ? "bg-[#f5d800] border-[#e0c400] ring-2 ring-[#fee500]/60"
                : "bg-[#fee500] hover:bg-[#f5dc00] border-[#f0d800]"
            }`}
          >
            <span className="text-sm leading-none">💬</span>
            <span className="hidden md:inline">메신저</span>
            {unreadChatCount > 0 && (
              <span className=" -top-1.5 -right-1.5 absolute min-w-[20px] h-5 px-1.5 rounded-full bg-rose-600 text-white text-[10px] font-extrabold flex items-center justify-center shadow-sm ring-2 ring-white leading-none">
                {unreadChatCount > 99 ? "99+" : unreadChatCount}
              </span>
            )}
          </button>
        )}

        <div className="w-px h-5 bg-slate-200 mx-1" />

        <button
          type="button"
          onClick={openProfileModal}
          className="flex items-center gap-2.5 px-2.5 py-1.5 rounded-xl hover:bg-slate-100 transition-colors text-left"
          title="내 프로필 및 부재중 자동응답 설정"
        >
          <div className="relative w-8 h-8 rounded-full bg-slate-200 border border-slate-300 flex items-center justify-center text-slate-600 font-bold text-xs overflow-hidden shrink-0">
            <span>{me?.name?.slice(0, 1) || "H"}</span>
            {avatarUrl && (
              <img
                src={avatarUrl}
                alt={me?.name || "profile"}
                className="absolute inset-0 w-full h-full object-cover"
              />
            )}
          </div>
          <div className="hidden md:block">
            <div className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
              <span>{me?.name || "로딩중"}</span>
              <span
                className={`px-1.5 py-0.5 rounded border text-[10px] font-bold ${rankMeta.badgeClass}`}
              >
                {me?.job_title || rankMeta.defaultTitle}
              </span>
            </div>
            <div className="text-[11px] text-slate-500">
              {me?.department || "본부"}
            </div>
          </div>
        </button>

        <button
          type="button"
          onClick={handleLogoutClick}
          className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-rose-50 text-slate-600 hover:text-rose-600 text-xs font-bold transition-colors"
        >
          로그아웃
        </button>
      </div>
    </header>
  );
}
