// src/components/hq/HqShellContext.tsx
"use client";

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";
import { subscribePostgresChanges } from "@/lib/postgresRealtimeHub";
import {
  fetchContestAccess,
  hasSupabaseSession,
} from "@/app/(dashboard)/contest-db/useContestDb";
import type { ContestAccessLevel } from "@/app/(dashboard)/contest-db/contestUtils";
import { hqFetch } from "@/lib/hq/clientApi";
import { DEFAULT_HQ_COMPANY_SETTINGS } from "@/lib/hq/defaultCompanySettings";
import {
  type MemberPermissionSubject,
  type ResolvedMemberPermissionState,
  resolveMemberPermissions,
} from "@/lib/hq/hqPermissionEngine";
import { useHqHref } from "@/lib/hq/hqRoutes";
import type {
  HqAttendanceRecord,
  HqCompanySettings,
  HqMember,
  HqWorkMode,
} from "@/lib/hq/types";

interface HqShellState {
  instId: string;
  me: HqMember | null;
  members: HqMember[];
  companySettings: HqCompanySettings;
  isHrManager: boolean;
  isHqAdmin: boolean;
  canAccessAnalytics: boolean;
  contestAccess: ContestAccessLevel;
  myPermissions: ResolvedMemberPermissionState;
  canAccessMenu: (canonicalHqPath: string) => boolean;
  hasHqPerm: (permKey: string) => boolean;
  canAccessTargetPerm: (
    permKey: string,
    target: MemberPermissionSubject | null | undefined
  ) => boolean;
  pendingApprovalCount: number;
  /** 새 결재 문서가 실시간으로 도착하여 우상단 알림이 깜빡이는 상태 */
  approvalAlertActive: boolean;
  /** 마지막 알림 해제 이후 새로 도착한 결재 문서 수 */
  newApprovalArrivedCount: number;
  dismissApprovalAlert: () => void;
  unsignedContractCount: number;
  unreadChatCount: number;
  myTodayAttendance: HqAttendanceRecord | null;
  myWeeklyMinutes: number;
  schemaMissing: boolean;
  sessionExpired: boolean;
  isBooting: boolean;
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  chatDrawerOpen: boolean;
  openChatDrawer: () => void;
  closeChatDrawer: () => void;
  toggleChatDrawer: () => void;
  refreshMembers: () => Promise<void>;
  refreshCompanySettings: () => Promise<void>;
  refreshApprovalBadge: () => Promise<void>;
  refreshAttendanceState: () => Promise<void>;
  refreshContractBadge: () => Promise<void>;
  refreshPermissions: () => Promise<void>;
  refreshChatUnread: () => Promise<void>;
  quickCheckIn: (workMode?: HqWorkMode, locationNote?: string) => Promise<void>;
  quickCheckOut: () => Promise<void>;
  openProfileModal: (subModal?: "basic" | "hr" | null | unknown) => void;
  openSettingsModal: (initialTab?: string) => void;
  logout: () => Promise<void>;
}

const HqShellContext = createContext<HqShellState | null>(null);

export function useHqShell(): HqShellState {
  const ctx = useContext(HqShellContext);
  if (!ctx) {
    throw new Error("useHqShell must be used inside HqShellProvider");
  }
  return ctx;
}

export function useOptionalHqShell(): HqShellState | null {
  return useContext(HqShellContext);
}

export function HqShellProvider({
  children,
  onOpenProfile,
  onOpenSettings,
}: {
  children: React.ReactNode;
  onOpenProfile: (subModal?: "basic" | "hr" | null | unknown) => void;
  onOpenSettings?: (initialTab?: string) => void;
}) {
  const router = useRouter();
  const hqHref = useHqHref();

  const [instId, setInstId] = useState("");
  const [me, setMe] = useState<HqMember | null>(null);
  const [members, setMembers] = useState<HqMember[]>([]);
  const [companySettings, setCompanySettings] = useState<HqCompanySettings>(
    DEFAULT_HQ_COMPANY_SETTINGS
  );
  const [isHrManager, setIsHrManager] = useState(false);
  const [isHqAdmin, setIsHqAdmin] = useState(false);
  const [canAccessAnalytics, setCanAccessAnalytics] = useState(false);
  const [contestAccess, setContestAccess] = useState<ContestAccessLevel>(null);
  const [pendingApprovalCount, setPendingApprovalCount] = useState(0);
  const [approvalAlertActive, setApprovalAlertActive] = useState(false);
  const [newApprovalArrivedCount, setNewApprovalArrivedCount] = useState(0);
  const lastPendingCountRef = useRef<number | null>(null);
  const [unsignedContractCount, setUnsignedContractCount] = useState(0);
  const [unreadChatCount, setUnreadChatCount] = useState(0);
  const [myTodayAttendance, setMyTodayAttendance] =
    useState<HqAttendanceRecord | null>(null);
  const [myWeeklyMinutes, setMyWeeklyMinutes] = useState(0);
  const [schemaMissing, setSchemaMissing] = useState(false);
  const [sessionExpired, setSessionExpired] = useState(false);
  const [isBooting, setIsBooting] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [chatDrawerOpen, setChatDrawerOpen] = useState(false);

  const openChatDrawer = useCallback(() => setChatDrawerOpen(true), []);
  const closeChatDrawer = useCallback(() => setChatDrawerOpen(false), []);
  const toggleChatDrawer = useCallback(
    () => setChatDrawerOpen((prev) => !prev),
    []
  );

  useEffect(() => {
    try {
      if (localStorage.getItem("logica_hq_sidebar_collapsed") === "1") {
        setSidebarCollapsed(true);
      }
    } catch {
      // ignore
    }
  }, []);

  const toggleSidebar = useCallback(() => {
    setSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem("logica_hq_sidebar_collapsed", next ? "1" : "0");
      } catch {
        // ignore
      }
      return next;
    });
  }, []);

  const logout = useCallback(async () => {
    document.cookie =
      "sb-access-token=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    document.cookie =
      "logica_tenant_id=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    localStorage.clear();
    sessionStorage.clear();
    await supabase.auth.signOut().catch(() => {});
    router.replace(hqHref("/hq/login"));
  }, [hqHref, router]);

  const refreshMembers = useCallback(async () => {
    try {
      const res = await hqFetch<{
        success: boolean;
        schemaMissing: boolean;
        extSchemaMissing?: boolean;
        data: {
          meId: string;
          isHrManager: boolean;
          isHqAdmin: boolean;
          members: HqMember[];
        };
      }>("/api/hq/members");

      setSchemaMissing(Boolean(res.schemaMissing || res.extSchemaMissing));
      setIsHrManager(Boolean(res.data.isHrManager));
      setIsHqAdmin(Boolean(res.data.isHqAdmin));
      setMembers(res.data.members || []);

      const myRow =
        (res.data.members || []).find((m) => m.instructor_id === res.data.meId) ||
        null;
      setMe(myRow);
      if (myRow) {
        localStorage.setItem("logica_instructor_name", myRow.name);
        localStorage.setItem("logica_instructor_position", myRow.job_title);
        if (myRow.tenant_id) {
          localStorage.setItem("logica_tenant_id", myRow.tenant_id);
          document.cookie = `logica_tenant_id=${myRow.tenant_id}; path=/; max-age=604800;`;
        }
      }
    } catch (err: any) {
      const msg = String(err?.message || "");
      if (/403|본부\(HQ\) 소속/.test(msg)) {
        alert("🏢 본부(HQ) 임직원 전용 워크스페이스입니다.");
        await logout();
      } else if (/401|만료|로그인/.test(msg)) {
        setSessionExpired(true);
      }
    }
  }, [logout]);

  const refreshCompanySettings = useCallback(async () => {
    try {
      const res = await hqFetch<{
        success: boolean;
        data: { settings: HqCompanySettings };
      }>("/api/hq/settings");
      if (res.data?.settings) {
        setCompanySettings(res.data.settings);
      }
    } catch {
      // ignore offline/unauth
    }
  }, []);

  const refreshApprovalBadge = useCallback(async () => {
    try {
      const res = await hqFetch<{
        success: boolean;
        schemaMissing: boolean;
        data: { myPendingCount: number };
      }>("/api/hq/approvals");
      if (res.schemaMissing) setSchemaMissing(true);
      const nextCount = Number(res.data?.myPendingCount || 0);
      const prevCount = lastPendingCountRef.current;
      lastPendingCountRef.current = nextCount;
      setPendingApprovalCount(nextCount);

      // 최초 로드 이후 내 결재 대기 건수가 늘어났다면 → 새 결재 도착 알림(깜빡임) 활성화
      if (prevCount !== null && nextCount > prevCount) {
        const added = nextCount - prevCount;
        setNewApprovalArrivedCount((c) => c + added);
        setApprovalAlertActive(true);
        if (typeof window !== "undefined") {
          window.dispatchEvent(
            new CustomEvent("hq:approval-incoming", {
              detail: { added, total: nextCount },
            })
          );
        }
      } else if (nextCount === 0) {
        setApprovalAlertActive(false);
        setNewApprovalArrivedCount(0);
      }
    } catch {
      // ignore badge fetch errors when offline/unauth
    }
  }, []);

  const dismissApprovalAlert = useCallback(() => {
    setApprovalAlertActive(false);
    setNewApprovalArrivedCount(0);
  }, []);

  const refreshAttendanceState = useCallback(async () => {
    try {
      const res = await hqFetch<{
        success: boolean;
        schemaMissing: boolean;
        data: {
          myToday: HqAttendanceRecord | null;
          myWeeklyMinutes: number;
        };
      }>("/api/hq/attendance");
      if (res.schemaMissing) setSchemaMissing(true);
      setMyTodayAttendance(res.data?.myToday || null);
      setMyWeeklyMinutes(Number(res.data?.myWeeklyMinutes || 0));
    } catch {
      // ignore
    }
  }, []);

  const refreshContractBadge = useCallback(async () => {
    try {
      const res = await hqFetch<{
        success: boolean;
        schemaMissing: boolean;
        data: { myUnsignedCount: number };
      }>("/api/hq/contracts");
      if (res.schemaMissing) setSchemaMissing(true);
      setUnsignedContractCount(Number(res.data?.myUnsignedCount || 0));
    } catch {
      // ignore
    }
  }, []);

  const quickCheckIn = useCallback(
    async (workMode: HqWorkMode = "OFFICE", locationNote?: string) => {
      await hqFetch("/api/hq/attendance", {
        method: "POST",
        body: {
          action: "CHECK_IN",
          work_mode: workMode,
          location_note: locationNote,
        },
      });
      await refreshAttendanceState();
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("hq:attendance-updated"));
      }
    },
    [refreshAttendanceState]
  );

  const quickCheckOut = useCallback(async () => {
    await hqFetch("/api/hq/attendance", {
      method: "POST",
      body: { action: "CHECK_OUT" },
    });
    await refreshAttendanceState();
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("hq:attendance-updated"));
    }
  }, [refreshAttendanceState]);

  const refreshPermissions = useCallback(async () => {
    if (!(await hasSupabaseSession())) {
      setContestAccess(null);
      setCanAccessAnalytics(false);
      setSessionExpired(true);
      return;
    }
    setSessionExpired(false);
    fetchContestAccess().then(setContestAccess);
    supabase
      .rpc("has_hq_permission", { p_permission: "admission_analytics" })
      .then(({ data }) => setCanAccessAnalytics(data === true));
    supabase
      .rpc("is_hq_admin")
      .then(({ data }) => {
        if (data === true) setIsHqAdmin(true);
      });
  }, []);

  const refreshChatUnread = useCallback(async () => {
    const uid = instId || localStorage.getItem("logica_instructor_id") || "";
    if (!uid) return;
    try {
      const { data: myRooms } = await supabase
        .from("internal_chat_member")
        .select("room_id, last_read_at")
        .eq("instructor_id", uid)
        .eq("is_active", true);

      if (!myRooms || myRooms.length === 0) {
        setUnreadChatCount(0);
        return;
      }

      const roomIds = myRooms.map((r: any) => r.room_id);
      const { data: msgs } = await supabase
        .from("internal_chat_message")
        .select("room_id, sender_id, created_at")
        .in("room_id", roomIds)
        .neq("sender_id", uid)
        .order("created_at", { ascending: false })
        .limit(300);

      const readMap = new Map<string, number>();
      myRooms.forEach((r: any) => {
        readMap.set(
          String(r.room_id),
          new Date(r.last_read_at || "1970-01-01T00:00:00Z").getTime()
        );
      });

      let unread = 0;
      (msgs || []).forEach((m: any) => {
        const lastRead = readMap.get(String(m.room_id)) || 0;
        if (new Date(m.created_at).getTime() > lastRead) unread++;
      });
      setUnreadChatCount(unread);
    } catch {
      // ignore
    }
  }, [instId]);

  useEffect(() => {
    let mounted = true;

    const boot = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      let uid =
        session?.user?.id || localStorage.getItem("logica_instructor_id") || "";
      if (!uid) {
        router.replace(hqHref("/hq/login"));
        return;
      }

      if (session?.access_token) {
        document.cookie = `sb-access-token=${session.access_token}; path=/; max-age=604800;`;
        localStorage.setItem("logica_instructor_id", session.user.id);
        uid = session.user.id;
      }

      if (!mounted) return;
      setInstId(uid);

      await Promise.all([
        refreshMembers(),
        refreshCompanySettings(),
        refreshApprovalBadge(),
        refreshAttendanceState(),
        refreshContractBadge(),
        refreshPermissions(),
      ]);

      if (mounted) setIsBooting(false);
    };

    boot();
    return () => {
      mounted = false;
    };
  }, [
    hqHref,
    router,
    refreshMembers,
    refreshCompanySettings,
    refreshApprovalBadge,
    refreshAttendanceState,
    refreshContractBadge,
    refreshPermissions,
  ]);

  useEffect(() => {
    if (!instId) return;
    refreshChatUnread();

    const unsubMsg = subscribePostgresChanges(
      { table: "internal_chat_message", events: ["INSERT"] },
      () => {
        refreshChatUnread();
      }
    );

    const unsubChatMember = subscribePostgresChanges(
      { table: "internal_chat_member", events: ["INSERT", "UPDATE"] },
      () => {
        refreshChatUnread();
      }
    );

    const onApprovalChange = () => {
      refreshApprovalBadge();
      refreshMembers();
      refreshAttendanceState();
    };
    const onAttendanceChange = () => {
      refreshAttendanceState();
    };
    const onContractChange = () => {
      refreshContractBadge();
      refreshMembers();
    };

    window.addEventListener("hq:approval-updated", onApprovalChange);
    window.addEventListener("hq:attendance-updated", onAttendanceChange);
    window.addEventListener("hq:contract-updated", onContractChange);

    // =====================================================================
    // 결재 문서 실시간 감지: Supabase Realtime(결재 단계/문서 변경) + 30초 폴링 + 탭 복귀 즉시 갱신
    // =====================================================================
    let approvalDebounce: ReturnType<typeof setTimeout> | null = null;
    const scheduleApprovalRefresh = () => {
      if (approvalDebounce) clearTimeout(approvalDebounce);
      approvalDebounce = setTimeout(() => {
        approvalDebounce = null;
        refreshApprovalBadge();
      }, 700);
    };

    const unsubApprovalStep = subscribePostgresChanges(
      { table: "hq_approval_step", events: ["INSERT", "UPDATE"] },
      (payload) => {
        const row: any = payload.new || {};
        if (!row.approver_id || String(row.approver_id) === String(instId)) {
          scheduleApprovalRefresh();
        }
      }
    );
    const unsubApprovalDoc = subscribePostgresChanges(
      { table: "hq_approval_doc", events: ["INSERT", "UPDATE"] },
      () => scheduleApprovalRefresh()
    );

    const approvalPollTimer = window.setInterval(() => {
      if (document.visibilityState === "visible") {
        refreshApprovalBadge();
      }
    }, 30_000);

    const onVisibleAgain = () => {
      if (document.visibilityState === "visible") scheduleApprovalRefresh();
    };
    document.addEventListener("visibilitychange", onVisibleAgain);
    window.addEventListener("focus", onVisibleAgain);

    return () => {
      unsubMsg();
      unsubChatMember();
      unsubApprovalStep();
      unsubApprovalDoc();
      if (approvalDebounce) clearTimeout(approvalDebounce);
      window.clearInterval(approvalPollTimer);
      document.removeEventListener("visibilitychange", onVisibleAgain);
      window.removeEventListener("focus", onVisibleAgain);
      window.removeEventListener("hq:approval-updated", onApprovalChange);
      window.removeEventListener("hq:attendance-updated", onAttendanceChange);
      window.removeEventListener("hq:contract-updated", onContractChange);
    };
  }, [
    instId,
    refreshChatUnread,
    refreshApprovalBadge,
    refreshMembers,
    refreshAttendanceState,
    refreshContractBadge,
  ]);

  // 로그인 설정의 PC/모바일 자동 로그아웃 주기 만료 체크
  useEffect(() => {
    if (!instId) return;
    const checkExpiry = () => {
      const expStr = localStorage.getItem("hq_session_expires_at");
      if (expStr && Number(expStr) > 0 && Date.now() > Number(expStr)) {
        logout();
      }
    };
    checkExpiry();
    const timer = window.setInterval(checkExpiry, 60000);
    return () => window.clearInterval(timer);
  }, [instId, logout]);

  const myPermissions = useMemo(
    () =>
      resolveMemberPermissions({
        member: me,
        rawSettings: companySettings.extra_settings?.permission_settings,
        isDbHqAdmin: isHqAdmin,
        canAccessAnalyticsRpc: canAccessAnalytics,
        hasContestAccess: Boolean(contestAccess),
      }),
    [
      me,
      companySettings.extra_settings?.permission_settings,
      isHqAdmin,
      canAccessAnalytics,
      contestAccess,
    ]
  );

  const effectiveIsHqAdmin = isHqAdmin || myPermissions.isSuperAdmin;
  const effectiveIsHrManager =
    isHrManager ||
    effectiveIsHqAdmin ||
    Boolean(
      myPermissions.effectivePermissions["hr.employment_manage"] ||
        myPermissions.effectivePermissions["payroll.run"] ||
        myPermissions.effectivePermissions["company.basic_manage"] ||
        myPermissions.effectivePermissions["permission.manage"]
    );

  const canAccessMenu = useCallback(
    (canonicalPath: string) => myPermissions.canAccessRoute(canonicalPath),
    [myPermissions]
  );

  const hasHqPerm = useCallback(
    (permKey: string) =>
      effectiveIsHqAdmin || Boolean(myPermissions.effectivePermissions[permKey]),
    [effectiveIsHqAdmin, myPermissions]
  );

  const canAccessTargetPerm = useCallback(
    (
      permKey: string,
      target: MemberPermissionSubject | null | undefined
    ): boolean => {
      if (!target) return false;
      if (effectiveIsHqAdmin) return true;
      return myPermissions.canAccessTargetMember(
        permKey,
        target,
        companySettings.extra_settings?.org_chart_nodes
      );
    },
    [
      companySettings.extra_settings?.org_chart_nodes,
      effectiveIsHqAdmin,
      myPermissions,
    ]
  );

  // 지정 출·퇴근 시각 도래 시 자동 근무 시작·퇴근 상태가 즉시 반영되도록 1분 주기 동기화
  useEffect(() => {
    if (!me?.instructor_id) return;
    const timer = setInterval(() => {
      refreshAttendanceState();
    }, 60_000);
    return () => clearInterval(timer);
  }, [me?.instructor_id, refreshAttendanceState]);

  const openSettingsModal = useCallback(
    (initialTab?: string) => {
      if (onOpenSettings) {
        onOpenSettings(initialTab);
      } else {
        router.push(
          hqHref(
            initialTab ? `/hq/settings?tab=${initialTab}` : "/hq/settings"
          )
        );
      }
    },
    [hqHref, onOpenSettings, router]
  );

  return (
    <HqShellContext.Provider
      value={{
        instId,
        me,
        members,
        companySettings,
        isHrManager: effectiveIsHrManager,
        isHqAdmin: effectiveIsHqAdmin,
        canAccessAnalytics:
          canAccessAnalytics || myPermissions.canAccessRoute("/hq/analytics"),
        contestAccess,
        myPermissions,
        canAccessMenu,
        hasHqPerm,
        canAccessTargetPerm,
        pendingApprovalCount,
        approvalAlertActive,
        newApprovalArrivedCount,
        dismissApprovalAlert,
        unsignedContractCount,
        unreadChatCount,
        myTodayAttendance,
        myWeeklyMinutes,
        schemaMissing,
        sessionExpired,
        isBooting,
        sidebarCollapsed,
        toggleSidebar,
        chatDrawerOpen,
        openChatDrawer,
        closeChatDrawer,
        toggleChatDrawer,
        refreshMembers,
        refreshCompanySettings,
        refreshApprovalBadge,
        refreshAttendanceState,
        refreshContractBadge,
        refreshPermissions,
        refreshChatUnread,
        quickCheckIn,
        quickCheckOut,
        openProfileModal: onOpenProfile,
        openSettingsModal,
        logout,
      }}
    >
      {children}
    </HqShellContext.Provider>
  );
}
