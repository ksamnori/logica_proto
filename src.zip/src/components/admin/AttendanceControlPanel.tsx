// src/components/admin/AttendanceControlPanel.tsx
"use client";

import React, { useState, useEffect, useMemo, useRef } from "react";
import { supabase } from "../../lib/supabase";
import { subscribePostgresChanges } from "@/lib/postgresRealtimeHub";

const unwrap = <T,>(obj: T | T[] | undefined | null): T | undefined => {
  if (Array.isArray(obj)) return obj[0];
  return obj || undefined;
};

const ENDED_ENROLLMENT_STATUSES = ["수강종료", "종료", "퇴원", "취소"];
const isEndedEnrollment = (e: any): boolean => {
  if (!e) return true;
  if (ENDED_ENROLLMENT_STATUSES.includes(String(e.status || "").trim())) return true;
  if (e.end_date) return true;
  return false;
};


const getKSTDateStr = (offsetDays = 0) => {
  const kstAdjusted = new Date(Date.now() + (9 * 3600000) - (6 * 3600000) + (offsetDays * 86400000));
  return kstAdjusted.toISOString().split('T')[0];
};

const formatTimeAsKST = (isoStr: string) => {
  if (!isoStr) return "";
  const d = new Date(isoStr);
  if (isNaN(d.getTime())) return "";
  const kst = new Date(d.getTime() + (9 * 3600000));
  return `${String(kst.getUTCHours()).padStart(2, '0')}:${String(kst.getMinutes()).padStart(2, '0')}`;
};

const formatDateAndDayKST = (isoStr?: string) => {
  const baseDate = isoStr ? new Date(isoStr) : new Date();
  if (isNaN(baseDate.getTime())) return "";
  const kst = new Date(baseDate.getTime() + (9 * 3600000));
  const days = ['일', '월', '화', '수', '목', '금', '토'];
  const mm = String(kst.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(kst.getUTCDate()).padStart(2, '0');
  const dayName = days[kst.getUTCDay()];
  return `${mm}.${dd} (${dayName})`;
};

interface AttendanceControlPanelProps {
  classStats: any[];
  todayIso: string;
  onQueueMessage: (msgOrMsgs: any | any[]) => void;
}

export default function AttendanceControlPanel({ classStats, todayIso, onQueueMessage }: AttendanceControlPanelProps) {
  const [selectedAttClassId, setSelectedAttClassId] = useState<string>("all");
  const [attStudents, setAttStudents] = useState<any[]>([]);
  const [activeAttMenu, setActiveAttMenu] = useState<string | null>(null);
  const [manualModalData, setManualModalData] = useState<any | null>(null);
  const [manualForm, setManualForm] = useState({ status: "NONE", checkIn: "", checkOut: "" });

  const [viewMode, setViewMode] = useState<"card" | "list">("card");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [hideTestStudents, setHideTestStudents] = useState<boolean>(true);
  
  const [searchQuery, setSearchQuery] = useState<string>("");

  const fetchTimeoutRef = useRef<any>(null);
  const isBulkProcessing = useRef<boolean>(false);
  const selectedAttClassIdRef = useRef<string>(selectedAttClassId);
  selectedAttClassIdRef.current = selectedAttClassId;

  useEffect(() => {
    const closeMenu = (e: MouseEvent) => {
      const target = e.target as Element;
      if (target.closest('.kebab-container')) return;
      setActiveAttMenu(null);
    };
    document.addEventListener("mousedown", closeMenu);
    return () => { document.removeEventListener("mousedown", closeMenu); };
  }, []);

  useEffect(() => {
    const savedMode = localStorage.getItem("logica_att_view_mode");
    if (savedMode === "list" || savedMode === "card") setViewMode(savedMode);
    
    const savedFilter = localStorage.getItem("logica_att_status_filter");
    if (savedFilter) setStatusFilter(savedFilter === 'null' ? null : savedFilter);
  }, []);

  const handleViewModeChange = (mode: "card" | "list") => {
    setViewMode(mode);
    localStorage.setItem("logica_att_view_mode", mode);
  };

  const handleStatusFilterChange = (filter: string | null) => {
    setStatusFilter(filter);
    localStorage.setItem("logica_att_status_filter", filter === null ? 'null' : filter);
  };

  const requestFetch = (classId: string) => {
    if (isBulkProcessing.current) return; 
    if (fetchTimeoutRef.current) clearTimeout(fetchTimeoutRef.current);
    fetchTimeoutRef.current = setTimeout(() => {
      fetchAttendance(classId);
    }, 800); 
  };

  const fetchAttendance = async (classId: string) => {
    if (!classId) return;
    const today = getKSTDateStr();
    const yesterday = getKSTDateStr(-1);
    const tId = localStorage.getItem("logica_tenant_id");

    let stQuery = supabase.from("student").select(`
      student_id, name, status, parent(name, phone), 
      enrollment(enrollment_id, class_id, status, end_date, class(name, instructor(name)))
    `).eq("status", "재원").limit(10000);
    
    if (tId && tId !== 'hq') stQuery = stQuery.eq("tenant_id", tId);

    const clinicQuery = supabase
      .from("clinic_session_state")
      .select("student_id, ended_at, started_at, last_seen_at, session_date")
      .in("session_date", [today, yesterday])
      .limit(10000);

    const attQuery = supabase
      .from("attendance")
      .select("attendance_id, student_id, status, check_in_time, check_out_time, attendance_date")
      .in("attendance_date", [today, yesterday])
      .limit(10000);

    const [stRes, clinicRes, attRes] = await Promise.all([stQuery, clinicQuery, attQuery]);
    
    if (stRes.error || !stRes.data) {
      console.error("데이터 로딩 오류:", stRes.error);
      setAttStudents([]);
      return;
    }

    const todayClinics = clinicRes.data || [];
    const todayAtts = attRes.data || [];
    let targetStudents = stRes.data;
    
    if (classId !== "all") {
      targetStudents = stRes.data.filter(st => 
        st.enrollment && st.enrollment.some((e: any) => !isEndedEnrollment(e) && String(e.class_id) === String(classId))
      );
    }

    const mappedAtt = targetStudents.map((st: any) => {
      const myAtts = todayAtts.filter((a: any) => {
          if (String(a.student_id) !== String(st.student_id)) return false;
          const checkInKST = a.check_in_time ? new Date(new Date(a.check_in_time).getTime() + 9 * 3600000 - 6 * 3600000).toISOString().split('T')[0] : a.attendance_date;
          return checkInKST === today || a.attendance_date === today;
      });
      
      myAtts.sort((a: any, b: any) => a.attendance_id - b.attendance_id);
      const latestAtt = myAtts.length > 0 ? myAtts[myAtts.length - 1] : undefined;
      
      const parentInfo = unwrap(st.parent);
      
      const activeEnrolls = (st.enrollment || []).filter((e: any) => !isEndedEnrollment(e));
      let mainEnroll = activeEnrolls.length > 0 ? activeEnrolls[0] : null;
      if (classId !== "all" && activeEnrolls.length > 0) {
         mainEnroll = activeEnrolls.find((e:any) => String(e.class_id) === String(classId)) || mainEnroll;
      }

      const className = mainEnroll?.class ? unwrap(mainEnroll.class)?.name : "미배정";
      const classInstructor = mainEnroll?.class?.instructor?.name || "미정";

      let currentStatus = latestAtt?.status || "NONE";

      if (currentStatus === '출석') currentStatus = '등원';
      if (['등원', '지각'].includes(currentStatus) && latestAtt?.check_out_time) {
          currentStatus = '하원';
      }

      const studentClinics = todayClinics.filter(c => String(c.student_id) === String(st.student_id));
      const isActiveInClinic = studentClinics.some(c => {
          if (c.ended_at) return false; 
          const targetTime = c.last_seen_at || c.started_at;
          if (!targetTime) return false;
          return (Date.now() - new Date(targetTime).getTime()) < 3 * 60 * 1000;
      });

      if (isActiveInClinic && currentStatus !== '결석') {
          currentStatus = "클리닉중";
      }
      
      return { 
        id: st.student_id, 
        name: st.name, 
        className: className,
        classInstructor: classInstructor, 
        classId: mainEnroll?.class_id || null,
        enrollId: mainEnroll?.enrollment_id || null,
        parentPhone: parentInfo?.phone || "",
        parentName: parentInfo?.name || "",
        att_id: latestAtt?.attendance_id, 
        status: currentStatus, 
        checkIn: latestAtt?.check_in_time,
        checkOut: latestAtt?.check_out_time,
        attDate: latestAtt?.attendance_date || today
      };
    });

    setAttStudents(mappedAtt.sort((a: any, b: any) => {
      if (a.className !== b.className) return (a.className || "").localeCompare(b.className || "");
      return (a.name || "").localeCompare(b.name || "");
    }));
  };

  useEffect(() => {
    if (selectedAttClassId) {
      requestFetch(selectedAttClassId);
      const syncInterval = setInterval(() => {
        if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
        if (!isBulkProcessing.current) fetchAttendance(selectedAttClassId);
      }, 15000);
      const handleVisible = () => {
        if (document.visibilityState === "visible" && !isBulkProcessing.current) {
          requestFetch(selectedAttClassId);
        }
      };
      document.addEventListener("visibilitychange", handleVisible);
      return () => {
        clearInterval(syncInterval);
        document.removeEventListener("visibilitychange", handleVisible);
      };
    } else {
      setAttStudents([]);
    }
  }, [selectedAttClassId]);

  // 🌟 [핵심 수정] selectedAttClassIdRef 참조로 반 필터 전환 시 채널 재구독 폭주(IncreaseSubscriptionConnectionPool) 원천 차단
  useEffect(() => {
    const unsubAtt = subscribePostgresChanges(
      { table: 'attendance' },
      () => {
        if (isBulkProcessing.current) return;
        const curId = selectedAttClassIdRef.current;
        if (curId) requestFetch(curId);
      }
    );

    // 🌟 clinic_session_state의 UPDATE(학생 하트비트 last_seen_at)를 제외하고 INSERT/DELETE만 공유 채널로 구독
    const unsubClinic = subscribePostgresChanges(
      { table: 'clinic_session_state', serverEvents: ['INSERT', 'DELETE'] },
      () => {
        if (isBulkProcessing.current) return;
        const curId = selectedAttClassIdRef.current;
        if (curId) requestFetch(curId);
      }
    );

    return () => {
      unsubAtt();
      unsubClinic();
    };
  }, []);

  const baseStudents = useMemo(() => {
    let filtered = attStudents;
    if (hideTestStudents) {
      // 이름에 '테스트'·'선생님'이 들어간 더미 학생 제외 (띄어쓰기 무시)
      filtered = filtered.filter(s => !/테스트|선생님/.test(String(s.name || '').replace(/\s/g, '')));
    }
    if (searchQuery.trim() !== "") {
      filtered = filtered.filter(s => s.name.includes(searchQuery.trim()));
    }
    return filtered;
  }, [attStudents, hideTestStudents, searchQuery]);

  const groupedStudents = useMemo(() => {
    const groups: Record<string, any[]> = {};
    baseStudents.forEach(st => {
      const cName = st.className || '미배정';
      if (!groups[cName]) groups[cName] = [];
      groups[cName].push(st);
    });
    return groups;
  }, [baseStudents]);

  const filteredDisplayGroups = useMemo(() => {
    const result = [];
    const entries = Object.entries(groupedStudents).sort(([a], [b]) => a === '미배정' ? 1 : b === '미배정' ? -1 : a.localeCompare(b));
    
    for (const [cName, students] of entries) {
      const filtered = students.filter((s: any) => {
        if (statusFilter === 'inClass') return ['등원', '지각'].includes(s.status);
        if (statusFilter === 'inClinic') return s.status === '클리닉중';
        if (statusFilter === 'goneHome') return ['하원', '조퇴'].includes(s.status);
        if (statusFilter === 'notArrived') return ['NONE', '결석'].includes(s.status);
        return true; 
      });

      if (filtered.length > 0) {
        const cInstructor = filtered[0].classInstructor || '미정';
        result.push({ cName, cInstructor, students: filtered, totalCount: students.length });
      }
    }
    return result;
  }, [groupedStudents, statusFilter]);

  const flowSummary = useMemo(() => {
    let notArrived = 0, inClass = 0, inClinic = 0, goneHome = 0, absent = 0;
    baseStudents.forEach(st => {
      if (st.status === 'NONE') notArrived++;
      else if (st.status === '결석') absent++;
      else if (st.status === '클리닉중') inClinic++;
      else if (['등원', '지각'].includes(st.status)) inClass++;
      else if (['하원', '조퇴'].includes(st.status)) goneHome++;
    });
    return { notArrived, inClass, inClinic, goneHome, absent, total: baseStudents.length };
  }, [baseStudents]);

  const handleAttAction = async (student: any, action: string) => {
    const today = getKSTDateStr();
    const nowTimestamp = new Date().toISOString();
    let payload: any = {};

    if (action === "ABSENT" && student.status !== "결석") {
      if (!confirm(`[${student.name}] 학생을 '결석' 처리하시겠습니까?`)) return;
    }

    const { data: existingRecords } = await supabase
      .from("attendance")
      .select("attendance_id")
      .eq("student_id", student.id)
      .eq("attendance_date", today);
      
    const existingId = existingRecords && existingRecords.length > 0 ? existingRecords[0].attendance_id : student.att_id;

    if (action === "DELETE") {
      if (!confirm(`[${student.name}] 학생의 오늘 출결 기록을 완벽히 초기화(삭제)하시겠습니까?\n\n※ 주의: 테스트/실수로 생성된 조교(클리닉) 기록도 함께 파기되어 '미등원' 상태로 강제 리셋됩니다.`)) return;
      if (existingId) await supabase.from("attendance").delete().eq("attendance_id", existingId);
      await supabase.from("clinic_session_state").delete().eq("student_id", student.id).in("session_date", [today, getKSTDateStr(-1)]);
      requestFetch(selectedAttClassId);
      return;
    }

    if (action === "PRESENT") {
      payload = { status: "등원" };
      if (!student.checkIn) payload.check_in_time = nowTimestamp;
    } else if (action === "LATE") {
      payload = { status: "지각" };
      if (!student.checkIn) payload.check_in_time = nowTimestamp;
    } else if (action === "ABSENT") {
      payload = { status: "결석", check_in_time: null, check_out_time: null };
    } else if (action === "EARLY_LEAVE") {
      payload = { status: "조퇴" };
      if (!student.checkOut) payload.check_out_time = nowTimestamp;
    } else if (action === "CLINIC") {
      payload = { status: "클리닉중" };
    } else if (action === "GO_HOME") {
      payload = { status: "하원", check_out_time: nowTimestamp }; 
    }

    setAttStudents(prev => prev.map(s => 
      s.id === student.id ? { ...s, ...payload } : s
    ));

    if (['PRESENT', 'LATE', 'ABSENT', 'EARLY_LEAVE', 'GO_HOME'].includes(action)) {
        let statusLabel = action === 'PRESENT' ? '등원' :
                          action === 'LATE' ? '지각' :
                          action === 'ABSENT' ? '결석' :
                          action === 'EARLY_LEAVE' ? '조퇴' : '하원';
        
        const nowStr = formatTimeAsKST(nowTimestamp);
        const timeString = `${today.replace(/-/g, '.')} ${nowStr}`;
        
        if (statusLabel && student.parentPhone) {
            onQueueMessage({
              id: `${student.id}_${statusLabel}_${Date.now()}`,
              parentPhone: student.parentPhone,
              parentName: student.parentName || student.name,
              studentName: student.name,
              timeString: timeString,
              statusLabel: statusLabel,
              previewTitle: `[출결] ${statusLabel}`,
              previewDesc: `${student.parentPhone} • ${timeString}`,
              templateId: "KA01TP260921034958500GAtQOl600yJ"
            });
        }
    }

    try {
      if (existingId) {
        await supabase.from("attendance").update(payload).eq("attendance_id", existingId);
      } else {
        await supabase.from("attendance").insert({
          student_id: student.id, class_id: student.classId, enrollment_id: student.enrollId, attendance_date: today, ...payload
        });
      }
    } catch (e) { console.error("업데이트 에러:", e); }
    finally { requestFetch(selectedAttClassId); }
  };

  const bulkAttend = async () => {
    if (!confirm(`현재 미처리된 전체 학생을 일괄 "등원" 처리하시겠습니까?\n(알림톡이 전송될 수 있습니다)`)) return;
    
    const toUpdate = baseStudents.filter(s => s.status === "NONE");
    if (toUpdate.length === 0) {
      alert("일괄 처리할 미등원 학생이 없습니다.");
      return;
    }

    const today = getKSTDateStr();
    const nowTimestamp = new Date().toISOString();
    const nowStr = formatTimeAsKST(nowTimestamp);
    const timeString = `${today.replace(/-/g, '.')} ${nowStr}`;

    setAttStudents(prev => prev.map(s => 
      s.status === "NONE" ? { ...s, status: "등원", checkIn: nowTimestamp } : s
    ));

    isBulkProcessing.current = true;

    const newMessages = toUpdate.filter(s => s.parentPhone).map(s => ({
        id: `${s.id}_등원_${Date.now()}`,
        parentPhone: s.parentPhone,
        parentName: s.parentName || s.name,
        studentName: s.name,
        timeString: timeString,
        statusLabel: '등원',
        previewTitle: `[출결] 등원`,
        previewDesc: `${s.parentPhone} • ${timeString}`,
        templateId: "KA01TP260921034958500GAtQOl600yJ"
    }));

    if (newMessages.length > 0) onQueueMessage(newMessages); 

    const inserts = toUpdate.map(s => ({
      student_id: s.id, class_id: s.classId, enrollment_id: s.enrollId, attendance_date: today, status: "등원", check_in_time: nowTimestamp
    }));

    try { await supabase.from("attendance").insert(inserts); } 
    catch (e) { console.error(e); alert("일괄 처리 중 오류가 발생했습니다."); } 
    finally { setTimeout(() => { isBulkProcessing.current = false; fetchAttendance(selectedAttClassId); }, 1500); }
  };

  const bulkGoHome = async () => {
    if (!confirm(`현재 등원/클리닉 중인 전체 학생을 일괄 "하원" 처리하시겠습니까?\n(알림톡이 전송될 수 있습니다)`)) return;
    
    const toUpdate = baseStudents.filter(s => s.att_id && !['하원', '조퇴', '결석', 'NONE'].includes(s.status));
    if (toUpdate.length === 0) {
      alert("일괄 처리할 하원 대상 학생이 없습니다.");
      return;
    }

    const today = getKSTDateStr();
    const nowTimestamp = new Date().toISOString();
    const nowStr = formatTimeAsKST(nowTimestamp);
    const timeString = `${today.replace(/-/g, '.')} ${nowStr}`;

    setAttStudents(prev => prev.map(s => 
      (s.att_id && !['하원', '조퇴', '결석', 'NONE'].includes(s.status)) 
        ? { ...s, status: "하원", checkOut: nowTimestamp } 
        : s
    ));

    isBulkProcessing.current = true;

    const newMessages = toUpdate.filter(s => s.parentPhone).map(s => ({
        id: `${s.id}_하원_${Date.now()}`,
        parentPhone: s.parentPhone,
        parentName: s.parentName || s.name,
        studentName: s.name,
        timeString: timeString,
        statusLabel: '하원',
        previewTitle: `[출결] 하원`,
        previewDesc: `${s.parentPhone} • ${timeString}`,
        templateId: "KA01TP260921034958500GAtQOl600yJ"
    }));

    if (newMessages.length > 0) onQueueMessage(newMessages); 

    try {
      await Promise.all(toUpdate.map(s => 
        supabase.from("attendance").update({ status: "하원", check_out_time: nowTimestamp }).eq("attendance_id", s.att_id)
      ));
    } 
    catch (e) { console.error(e); alert("일괄 처리 중 오류가 발생했습니다."); } 
    finally { setTimeout(() => { isBulkProcessing.current = false; fetchAttendance(selectedAttClassId); }, 1500); }
  };

  const openManualModal = (student: any) => {
    setManualModalData(student);
    setManualForm({
      status: student.status === "NONE" ? "등원" : student.status,
      checkIn: formatTimeAsKST(student.checkIn),
      checkOut: formatTimeAsKST(student.checkOut)
    });
    setActiveAttMenu(null);
  };

  const handleManualSave = async () => {
    const today = getKSTDateStr();
    const toIsoString = (timeStr: string) => {
      if (!timeStr) return null;
      const [hh, mm] = timeStr.split(':');
      const d = new Date(`${today}T${hh}:${mm}:00+09:00`);
      return d.toISOString();
    };

    const { status, checkIn, checkOut } = manualForm;

    if (['등원', '지각', '결석', '조퇴', '하원'].includes(status) && manualModalData.parentPhone) {
        const timeTarget = status === '조퇴' || status === '하원' ? checkOut : checkIn;
        const nowStr = timeTarget || formatTimeAsKST(new Date().toISOString());
        const timeString = `${today.replace(/-/g, '.')} ${nowStr}`;
        onQueueMessage({
          id: `${manualModalData.id}_${status}_${Date.now()}`,
          parentPhone: manualModalData.parentPhone,
          parentName: manualModalData.parentName || manualModalData.name,
          studentName: manualModalData.name,
          timeString: timeString,
          statusLabel: status,
          previewTitle: `[출결] ${status}`,
          previewDesc: `${manualModalData.parentPhone} • ${timeString}`,
          templateId: "KA01TP260921034958500GAtQOl600yJ"
        });
    }

    const { data: existingRecords } = await supabase.from("attendance").select("attendance_id").eq("student_id", manualModalData.id).eq("attendance_date", today);
    const existingId = existingRecords && existingRecords.length > 0 ? existingRecords[0].attendance_id : manualModalData.att_id;

    try {
      if (status === "NONE") {
        if (existingId) await supabase.from("attendance").delete().eq("attendance_id", existingId);
      } else {
        const payload: any = { status, check_in_time: toIsoString(checkIn), check_out_time: toIsoString(checkOut) };
        if (status === "결석") { payload.check_in_time = null; payload.check_out_time = null; }

        if (existingId) {
          await supabase.from("attendance").update(payload).eq("attendance_id", existingId);
        } else {
          await supabase.from("attendance").insert({
            student_id: manualModalData.id, class_id: manualModalData.classId, enrollment_id: manualModalData.enrollId, attendance_date: today, ...payload
          });
        }
      }
      alert("✅ 상태가 성공적으로 수동 반영되었습니다.");
    } catch (e) { alert("❌ 업데이트 중 오류가 발생했습니다."); } 
    finally { setManualModalData(null); requestFetch(selectedAttClassId); }
  };

  return (
    <>
      <div className="mb-6">
        <div className="px-4 sm:px-6 py-4 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 sm:gap-0 bg-white rounded-t-2xl border shadow-sm relative z-10">
          <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <span>📡</span> 실시간 동선
            
            <div className="relative ml-2 font-normal">
              <span className="absolute inset-y-0 left-0 flex items-center pl-2.5 text-slate-400 text-xs">
                🔍
              </span>
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="학생 이름 검색"
                className="pl-7 pr-3 py-1.5 text-xs font-bold border border-slate-200 rounded-lg focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 w-[130px] sm:w-[150px] shadow-inner bg-slate-50 focus:bg-white transition-colors text-slate-700"
              />
            </div>
          </h3>
          
          <div className="flex items-center gap-3 w-full sm:w-auto mt-2 sm:mt-0">
            <label title="이름에 '테스트' 또는 '선생님'이 들어간 학생을 명단에서 뺍니다" className="flex items-center gap-1.5 cursor-pointer bg-slate-50 hover:bg-slate-100 px-3 py-1.5 rounded-lg border border-slate-200 transition-colors shadow-inner shrink-0 mr-1">
              <input 
                type="checkbox" 
                className="w-3.5 h-3.5 accent-slate-600 rounded cursor-pointer"
                checked={hideTestStudents}
                onChange={(e) => setHideTestStudents(e.target.checked)}
              />
              <span className="text-xs font-bold text-slate-700 select-none flex items-center gap-1">🚫 테스트 제외</span>
            </label>

            <div className="bg-slate-100 p-1 rounded-lg flex items-center shadow-inner shrink-0">
              <button 
                onClick={() => handleViewModeChange('card')} 
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${viewMode === 'card' ? 'bg-white text-indigo-600 shadow-sm border border-slate-200/50' : 'text-slate-400 hover:text-slate-600'}`}
              >
                🗃️ 카드
              </button>
              <button 
                onClick={() => handleViewModeChange('list')} 
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition-colors ${viewMode === 'list' ? 'bg-white text-indigo-600 shadow-sm border border-slate-200/50' : 'text-slate-400 hover:text-slate-600'}`}
              >
                🗂️ 리스트
              </button>
            </div>

            <select 
              value={selectedAttClassId} 
              onChange={e => setSelectedAttClassId(e.target.value)}
              className="border border-indigo-300 rounded-lg py-1.5 px-3 text-xs font-bold text-indigo-900 bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 shadow-sm w-full sm:w-[250px]"
            >
              <option value="all">🌐 학원 전체 요약 보기</option>
              {classStats.map(c => (
                <option key={c.class_id} value={c.class_id}>{c.name} ({c.instructor?.name || '미정'})</option>
              ))}
            </select>
          </div>
        </div>
        
        <div className="flex flex-col lg:flex-row bg-white border border-t-0 border-slate-200 rounded-b-2xl shadow-sm overflow-hidden min-h-[450px]">
          
          <div className="w-full lg:w-[200px] bg-slate-50 border-r border-slate-200 flex flex-col shrink-0">
            <div className="p-4 flex flex-col gap-3">
              <div>
                <span className="text-xs font-bold text-slate-500 mb-2 block">
                  {selectedAttClassId === 'all' ? '학원 전체 동선 요약' : '반별 동선 요약'}
                </span>
                
                <div className="flex flex-col gap-1.5">
                  <button onClick={() => handleStatusFilterChange(null)} className={`flex justify-between items-center w-full text-left bg-white border rounded-lg p-2 shadow-sm transition-all ${statusFilter === null ? 'border-slate-800 ring-1 ring-slate-800 bg-slate-50' : 'border-slate-200 hover:border-slate-300'}`}>
                    <span className="text-xs font-bold text-slate-700">🌐 전체 보기</span>
                    <span className="text-sm font-bold text-slate-800">{flowSummary.total}명</span>
                  </button>
                  <button onClick={() => handleStatusFilterChange('inClass')} className={`flex justify-between items-center w-full text-left bg-white border rounded-lg p-2 shadow-sm transition-all ${statusFilter === 'inClass' ? 'border-blue-500 ring-1 ring-blue-500 bg-blue-50' : 'border-slate-200 hover:border-blue-300'}`}>
                    <span className="text-xs font-bold text-slate-500">🏫 원내 체류</span>
                    <span className="text-sm font-bold text-blue-600">{flowSummary.inClass}명</span>
                  </button>
                  <button onClick={() => handleStatusFilterChange('inClinic')} className={`flex justify-between items-center w-full text-left bg-white border rounded-lg p-2 shadow-sm transition-all ${statusFilter === 'inClinic' ? 'border-purple-500 ring-1 ring-purple-500 bg-purple-50' : 'border-slate-200 hover:border-purple-300'}`}>
                    <span className="text-xs font-bold text-slate-500">✍️ 클리닉중</span>
                    <span className="text-sm font-bold text-purple-600">{flowSummary.inClinic}명</span>
                  </button>
                  <button onClick={() => handleStatusFilterChange('goneHome')} className={`flex justify-between items-center w-full text-left bg-white border rounded-lg p-2 shadow-sm transition-all ${statusFilter === 'goneHome' ? 'border-emerald-500 ring-1 ring-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-emerald-300'}`}>
                    <span className="text-xs font-bold text-slate-500">👋 하원 완료</span>
                    <span className="text-sm font-bold text-emerald-600">{flowSummary.goneHome}명</span>
                  </button>
                  <button onClick={() => handleStatusFilterChange('notArrived')} className={`flex justify-between items-center w-full text-left bg-white border rounded-lg p-2 shadow-sm transition-all ${statusFilter === 'notArrived' ? 'border-slate-400 ring-1 ring-slate-400 bg-slate-100' : 'border-slate-200 hover:border-slate-300'}`}>
                    <span className="text-xs font-bold text-slate-500">❓ 미등원 (결석)</span>
                    <span className="text-sm font-bold text-slate-500">{flowSummary.notArrived + flowSummary.absent}명</span>
                  </button>
                </div>

              </div>
              
              <div className="flex flex-col gap-1.5 pt-2 border-t border-slate-200">
                <span className="text-xs font-bold text-slate-500 mb-0.5">일괄 출결 처리</span>
                <button onClick={bulkAttend} disabled={!selectedAttClassId} className="w-full text-xs font-bold bg-brand hover:bg-blue-900 text-white py-2.5 rounded-xl transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                  일괄 등원 처리 (카톡)
                </button>
                <button onClick={bulkGoHome} disabled={!selectedAttClassId} className="w-full text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white py-2.5 rounded-xl transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed">
                  일괄 하원 처리 (카톡)
                </button>
              </div>
            </div>
          </div>

          <div className="flex-1 overflow-hidden flex flex-col bg-slate-50/50">
            {filteredDisplayGroups.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-400 font-bold text-sm gap-2">
                <span className="text-3xl">☕</span>
                {searchQuery ? "검색된 이름이 없습니다." : statusFilter ? "해당 상태의 학생이 없습니다." : "조회된 학생이 없습니다."}
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto custom-scroll p-4 pb-8">
                
                {viewMode === "list" ? (
                  <div className="w-full bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <table className="w-full text-left border-collapse table-auto">
                      <thead>
                        <tr className="bg-slate-50 border-b border-slate-200">
                          <th className="py-2.5 px-2 text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[50px] text-center">이름</th>
                          <th className="py-2.5 px-1 text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[50px] text-center">상태</th>
                          <th className="py-2.5 px-1 text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[60px] text-center">날짜(요일)</th>
                          <th className="py-2.5 px-1 text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[40px] text-center">등원</th>
                          <th className="py-2.5 px-1 text-xs font-bold text-slate-500 uppercase tracking-wider min-w-[40px] text-center">하원</th>
                          <th className="py-2.5 px-2 text-xs font-bold text-slate-500 uppercase tracking-wider text-left pl-3 w-full">출결 관리</th>
                        </tr>
                      </thead>
                      <tbody>
                        {filteredDisplayGroups.map(({ cName, cInstructor, students, totalCount }) => (
                          <React.Fragment key={cName}>
                            <tr className="bg-slate-100/60 border-b border-slate-200">
                              <td colSpan={6} className="py-1.5 px-3 text-xs font-bold text-indigo-700">
                                <span className="w-1.5 h-3 bg-indigo-500 inline-block align-middle mr-1.5 rounded-full"></span>
                                {cName} 
                                {cName !== '미배정' && <span className="text-indigo-400 font-bold text-xs ml-1">({cInstructor})</span>}
                                <span className="text-slate-400 font-bold ml-1">
                                  (반 전체 {totalCount}명 {(statusFilter || searchQuery) && <span className="text-indigo-500 bg-indigo-50 px-1 rounded ml-1">필터됨 {students.length}명</span>})
                                </span>
                              </td>
                            </tr>
                            {students.map((student: any) => {
                              const isNotArrived = student.status === 'NONE';
                              let flowIcon = "❓"; let flowText = "미등원"; let flowColor = "text-slate-500 bg-slate-100 border-slate-200";
                              if (['등원', '지각'].includes(student.status)) { flowIcon = "🏫"; flowText = "원내체류"; flowColor = "text-blue-700 bg-blue-50 border-blue-200"; }
                              else if (student.status === '클리닉중') { flowIcon = "✍️"; flowText = "클리닉중"; flowColor = "text-purple-700 bg-purple-50 border-purple-200"; }
                              else if (['하원', '조퇴'].includes(student.status)) { flowIcon = "👋"; flowText = "하원완료"; flowColor = "text-emerald-700 bg-emerald-50 border-emerald-200"; }
                              else if (student.status === '결석') { flowIcon = "❌"; flowText = "결석"; flowColor = "text-rose-700 bg-rose-50 border-rose-200"; }
                              
                              const timeInStr = student.checkIn ? formatTimeAsKST(student.checkIn) : "-";
                              const timeOutStr = student.checkOut ? formatTimeAsKST(student.checkOut) : "-";
                              const dateAndDayStr = formatDateAndDayKST(student.checkIn || student.attDate);
                              
                              return (
                                <tr key={student.id} className={`border-b border-slate-100 last:border-0 hover:bg-indigo-50/40 transition-colors ${isNotArrived ? 'opacity-80 grayscale-[0.3]' : ''}`}>
                                  <td className="py-1.5 px-2 text-center">
                                    <span className={`text-xs font-bold truncate block max-w-[60px] mx-auto ${isNotArrived ? 'text-slate-500' : 'text-slate-800'}`} title={student.name}>
                                      {student.name}
                                    </span>
                                  </td>
                                  <td className="py-1.5 px-1 text-center">
                                    <span className={`px-1.5 py-0.5 rounded text-xs font-bold border ${flowColor} whitespace-nowrap`}>
                                      {flowIcon} {flowText}
                                    </span>
                                  </td>
                                  <td className="py-1.5 px-1 text-center text-xs font-bold text-slate-500 whitespace-nowrap">
                                    {dateAndDayStr}
                                  </td>
                                  <td className="py-1.5 px-1 text-center text-xs font-bold text-blue-700">{timeInStr}</td>
                                  <td className="py-1.5 px-1 text-center text-xs font-bold text-emerald-700">{timeOutStr}</td>
                                  <td className="py-1.5 px-2 text-left pl-3">
                                    <div className="flex items-center justify-start gap-1 flex-nowrap whitespace-nowrap">
                                      <button onClick={() => handleAttAction(student, 'PRESENT')} className="px-1.5 py-1 bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded text-xs transition-colors border border-blue-100 whitespace-nowrap">등원</button>
                                      <button onClick={() => handleAttAction(student, 'LATE')} className="px-1.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 font-bold rounded text-xs transition-colors border border-amber-100 whitespace-nowrap">지각</button>
                                      <button onClick={() => handleAttAction(student, 'CLINIC')} className="px-1.5 py-1 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded text-xs transition-colors border border-purple-100 whitespace-nowrap">클리닉</button>
                                      <button onClick={() => handleAttAction(student, 'EARLY_LEAVE')} className="px-1.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded text-xs transition-colors border border-indigo-100 whitespace-nowrap">조퇴</button>
                                      <button onClick={() => handleAttAction(student, 'GO_HOME')} className="px-1.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded text-xs transition-colors border border-emerald-100 whitespace-nowrap">하원</button>
                                      <button onClick={() => handleAttAction(student, 'ABSENT')} className="px-1.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded text-xs transition-colors border border-rose-100 whitespace-nowrap">결석</button>
                                      
                                      <div className="w-[1px] h-3 bg-slate-200 mx-0.5 shrink-0"></div>
                                      
                                      <button onClick={() => openManualModal(student)} className="px-1.5 py-1 text-slate-500 hover:bg-slate-100 border border-slate-200 font-bold rounded text-xs transition-colors" title="수동 설정">
                                        ⚙️수동
                                      </button>
                                      <button onClick={() => handleAttAction(student, 'DELETE')} className="px-1.5 py-1 text-rose-500 hover:bg-rose-50 border border-rose-200 font-bold rounded text-xs transition-colors" title="기록 삭제">
                                        🗑️삭제
                                      </button>
                                    </div>
                                  </td>
                                </tr>
                              )
                            })}
                          </React.Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {filteredDisplayGroups.map(({ cName, cInstructor, students, totalCount }) => (
                      <div key={cName}>
                        <h4 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5 pl-1">
                          <span className="w-1.5 h-3 bg-indigo-500 rounded-full"></span>
                          {cName} 
                          <span className="text-xs font-bold text-slate-400 ml-1">
                            반 전체 {totalCount}명 {(statusFilter || searchQuery) && <span className="text-indigo-500 bg-indigo-50 px-1 rounded ml-1">필터됨 {students.length}명</span>}
                          </span>
                        </h4>
                        
                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 gap-1.5">
                          {students.map((student: any) => {
                            const isMenuOpen = activeAttMenu === student.id;
                            const isNotArrived = student.status === 'NONE';

                            let flowIcon = "❓"; let flowText = "미등원"; let flowColor = "text-slate-500 bg-slate-200/50 border-slate-300";
                            if (['등원', '지각'].includes(student.status)) { flowIcon = "🏫"; flowText = "원내체류"; flowColor = "text-blue-700 bg-blue-50 border-blue-200"; }
                            else if (student.status === '클리닉중') { flowIcon = "✍️"; flowText = "클리닉중"; flowColor = "text-purple-700 bg-purple-50 border-purple-200"; }
                            else if (['하원', '조퇴'].includes(student.status)) { flowIcon = "👋"; flowText = "하원완료"; flowColor = "text-emerald-700 bg-emerald-50 border-emerald-200"; }
                            else if (student.status === '결석') { flowIcon = "❌"; flowText = "결석"; flowColor = "text-rose-700 bg-rose-50 border-rose-200"; }

                            const timeInStr = student.checkIn ? formatTimeAsKST(student.checkIn) : "";
                            const timeOutStr = student.checkOut ? formatTimeAsKST(student.checkOut) : "";                            
                            
                            const cardBgClass = isNotArrived 
                              ? "bg-slate-100/80 border-slate-300 border-dashed opacity-80 hover:opacity-100" 
                              : "bg-white border-slate-200 hover:border-indigo-300";

                            return (
                              <div key={student.id} className={`p-2 rounded-xl border flex flex-col justify-between transition-all relative gap-1.5 ${cardBgClass} ${isMenuOpen ? 'z-50 shadow-md ring-2 ring-indigo-200' : 'z-10 shadow-sm'}`}>
                                <div className="flex justify-between items-start w-full min-w-0">
                                  <div className="flex flex-col gap-0.5 min-w-0 flex-1 pr-1">
                                    <span className="font-bold text-slate-800 text-[12px] truncate w-full leading-tight">{student.name}</span>
                                    
                                    <div className="flex items-center justify-between w-full mt-0.5">
                                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold border ${flowColor} whitespace-nowrap shrink-0`}>
                                        {flowIcon} {flowText}
                                      </span>
                                      <span className="text-xs font-bold text-slate-400 whitespace-nowrap shrink-0 pl-1">
                                        {!timeInStr && !timeOutStr ? '기록 없음' : (
                                          <>
                                            {timeInStr && <span className="text-blue-600">{timeInStr}</span>}
                                            {timeInStr && timeOutStr && <span className="text-slate-300 mx-0.5">›</span>}
                                            {timeOutStr && <span className="text-emerald-600">{timeOutStr}</span>}
                                          </>
                                        )}
                                      </span>
                                    </div>
                                  </div>

                                  <div className="relative inline-block shrink-0 kebab-container mt-0.5">
                                    <button onClick={() => setActiveAttMenu(isMenuOpen ? null : student.id)} className="p-0.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded transition-colors">
                                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="1.5"></circle><circle cx="12" cy="5" r="1.5"></circle><circle cx="12" cy="19" r="1.5"></circle></svg>
                                    </button>
                                    
                                    {isMenuOpen && (
                                      <div className="absolute right-0 top-5 w-28 bg-white shadow-2xl rounded-xl border border-slate-200 z-[9999] py-1 text-left">
                                        <button onClick={() => { setActiveAttMenu(null); handleAttAction(student, 'LATE'); }} className="w-full text-left px-3 py-1.5 text-xs font-bold text-amber-600 hover:bg-slate-50 flex items-center gap-1.5">⏰ 지각 처리</button>
                                        <button onClick={() => { setActiveAttMenu(null); handleAttAction(student, 'EARLY_LEAVE'); }} className="w-full text-left px-3 py-1.5 text-xs font-bold text-indigo-600 hover:bg-slate-50 flex items-center gap-1.5">🏃 조퇴 처리</button>
                                        <button onClick={() => { setActiveAttMenu(null); handleAttAction(student, 'ABSENT'); }} className="w-full text-left px-3 py-1.5 text-xs font-bold text-rose-600 hover:bg-slate-50 flex items-center gap-1.5">❌ 결석 처리</button>
                                        <hr className="border-slate-100 my-0.5" />
                                        <button onClick={() => openManualModal(student)} className="w-full text-left px-3 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-50 flex items-center gap-1.5">⚙️ 수동 설정</button>
                                        <button onClick={() => { setActiveAttMenu(null); handleAttAction(student, 'DELETE'); }} className="w-full text-left px-3 py-1.5 text-xs font-bold text-rose-500 hover:bg-slate-50 flex items-center gap-1.5">🗑️ 기록 삭제</button>
                                      </div>
                                    )}
                                  </div>
                                </div>

                                <div className="flex gap-1 mt-1 pt-1.5 border-t border-slate-100">
                                  <button onClick={() => handleAttAction(student, 'PRESENT')} className="flex-1 py-1 flex items-center justify-center bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold rounded-md text-xs tracking-tighter whitespace-nowrap transition-colors border border-blue-100">등원</button>
                                  <button onClick={() => handleAttAction(student, 'CLINIC')} className="flex-1 py-1 flex items-center justify-center bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded-md text-xs tracking-tighter whitespace-nowrap transition-colors border border-purple-100">클리닉</button>
                                  <button onClick={() => handleAttAction(student, 'GO_HOME')} className="flex-1 py-1 flex items-center justify-center bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-md text-xs tracking-tighter whitespace-nowrap transition-colors border border-emerald-100">하원</button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

              </div>
            )}
          </div>
        </div>
      </div>

      {manualModalData && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/50 backdrop-blur-sm px-4">
          <div className="bg-white p-6 rounded-2xl w-full max-w-sm shadow-2xl">
            <h3 className="text-lg font-bold text-slate-800 mb-5 border-b border-slate-100 pb-3 flex items-center gap-2">⚙️ 수동 상태 설정 <span className="text-sm font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded ml-auto">{manualModalData.name}</span></h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">위치 / 상태</label>
                <select value={manualForm.status} onChange={e => setManualForm({...manualForm, status: e.target.value})} className="border border-slate-300 p-2.5 w-full rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:border-indigo-500 bg-slate-50">
                  <option value="등원">🏫 원내체류 (등원)</option>
                  <option value="클리닉중">✍️ 클리닉중</option>
                  <option value="하원">👋 하원 완료</option>
                  <option value="결석">❌ 결석</option>
                  <option value="지각">⏰ 지각</option>
                  <option value="조퇴">🏃 조퇴</option>
                  <option value="NONE">🗑️ 미처리 (초기화)</option>
                </select>
              </div>

              {manualForm.status !== "NONE" && manualForm.status !== "결석" && (
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">등원 시간</label>
                  <input type="time" value={manualForm.checkIn} onChange={e => setManualForm({...manualForm, checkIn: e.target.value})} className="border border-slate-300 p-2 w-full rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:border-indigo-500" />
                </div>
              )}

              {manualForm.status !== "NONE" && manualForm.status !== "결석" && (
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1.5">종료/하원 시간</label>
                  <input type="time" value={manualForm.checkOut} onChange={e => setManualForm({...manualForm, checkOut: e.target.value})} className="border border-slate-300 p-2 w-full rounded-xl text-sm font-bold text-slate-700 focus:outline-none focus:border-indigo-500" />
                </div>
              )}
            </div>

            <div className="flex justify-end gap-2 mt-8">
              <button onClick={() => setManualModalData(null)} className="px-5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl text-sm transition-colors">취소</button>
              <button onClick={handleManualSave} className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-sm shadow-md transition-colors">저장하기</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}