// src/app/(dashboard)/exam-list/page.tsx
"use client";

import { useEffect, useState, useMemo, useRef } from "react";
import { useRouter } from "next/navigation";
import { getExamsAction, deleteExamAction } from "@/app/actions/examActions";
import { supabase } from "@/lib/supabase"; 
import { ensureInstructorSession } from "@/lib/session";

// 분리된 모달 컴포넌트 임포트
import PublishModal from "@/components/exam/PublishModal";
import GradingModal from "@/components/exam/GradingModal";
import { compareSubQuestions, buildMergedQuestionGroups, getCleanUrl } from "@/app/exam/step2/examUtils";

type MainTabType = 'ALL' | 'EXAM' | 'WEEKLY' | 'HOMEWORK' | 'OVERDUE' | 'INCORRECT' | 'SIMILAR';
type ExamBucket = 'EXAM' | 'WEEKLY' | 'HOMEWORK' | 'OVERDUE' | 'INCORRECT' | 'SIMILAR' | 'OTHER';

const VALID_MAIN_TABS: MainTabType[] = [
  'ALL',
  'WEEKLY',
  'INCORRECT',
  'OVERDUE',
  'HOMEWORK',
  'SIMILAR',
  'EXAM',
];

function classifyExamItem(exam: any): {
  bucket: ExamBucket;
  badgeLabel: string;
  badgeColorClass: string;
  searchKeywords: string;
} {
  const rawType = String(exam?.exam_type || '').normalize('NFC').trim();
  const typeStr = rawType || '평가';
  const titleStr = String(exam?.title || '').normalize('NFC').trim();
  const subTitleStr = String(exam?.sub_title || '').normalize('NFC').trim();
  const tagsStr = String(exam?.exam_tags || '').normalize('NFC').trim();

  // 1. 미완료과제 (클리닉실·회차 이관 등으로 생성된 미완료 과제/프린트 최우선 분리)
  if (
    typeStr === '미완료과제' ||
    /^\[미완료\s*과제\]/.test(titleStr) ||
    /미완료\s*프린트/.test(titleStr)
  ) {
    return {
      bucket: 'OVERDUE',
      badgeLabel: '미완료과제',
      badgeColorClass: 'bg-rose-50 text-rose-600 border-rose-200',
      searchKeywords: '미완료과제 미완료 프린트',
    };
  }

  // 2. 쌍둥이/유사 프린트
  if (['오답유사', '과제오답유사'].includes(typeStr)) {
    return {
      bucket: 'SIMILAR',
      badgeLabel: typeStr,
      badgeColorClass: 'bg-violet-50 text-violet-600 border-violet-200',
      searchKeywords: `${typeStr} 쌍둥이 유사`,
    };
  }

  // 3. 오답 복습 프린트 (주차 오답 프린트가 주간테스트 탭에 섞이지 않도록 선분류)
  const isWeeklyWrongTitle =
    /([0-9xX]+\s*주차|주차)/.test(titleStr) && /오답\s*(프린트)?/.test(titleStr);
  if (['오답프린트', '오답'].includes(typeStr) || isWeeklyWrongTitle) {
    const label = ['오답프린트', '오답'].includes(typeStr) ? typeStr : '오답프린트';
    return {
      bucket: 'INCORRECT',
      badgeLabel: label,
      badgeColorClass: 'bg-emerald-50 text-emerald-600 border-emerald-200',
      searchKeywords: `${label} 오답 복습`,
    };
  }

  // 4. 정규 시험: 입학테스트 · 진단평가 · 분기평가
  const isQuarterlyByType =
    typeStr === '분기평가' ||
    typeStr === '분기테스트' ||
    typeStr.includes('분기평가') ||
    typeStr.includes('분기테스트');
  const isQuarterlyByMeta =
    !['과제', '과제프린트', '주간테스트'].includes(typeStr) &&
    !/오답\s*(프린트|유사)?/.test(titleStr) &&
    (titleStr.includes('분기평가') ||
      titleStr.includes('분기테스트') ||
      tagsStr.includes('분기평가') ||
      tagsStr.includes('분기테스트'));

  if (isQuarterlyByType || isQuarterlyByMeta) {
    return {
      bucket: 'EXAM',
      badgeLabel:
        typeStr === '분기테스트'
          ? '분기평가'
          : isQuarterlyByType
          ? typeStr
          : '분기평가',
      badgeColorClass: 'bg-fuchsia-50 text-fuchsia-700 border-fuchsia-200',
      searchKeywords: `${typeStr} 분기평가 분기테스트 정규시험`,
    };
  }

  const isDiagnosticByType =
    typeStr === '입학테스트' ||
    typeStr === '진단평가' ||
    typeStr.includes('입학테스트') ||
    typeStr.includes('진단평가');
  const isDiagnosticByMeta =
    !['과제', '과제프린트', '주간테스트'].includes(typeStr) &&
    !/오답\s*(프린트|유사)?/.test(titleStr) &&
    (titleStr.includes('입학테스트') ||
      titleStr.includes('진단평가') ||
      tagsStr.includes('입학테스트') ||
      tagsStr.includes('진단평가'));

  if (isDiagnosticByType || isDiagnosticByMeta) {
    return {
      bucket: 'EXAM',
      badgeLabel: typeStr === '입학테스트' ? '진단평가' : (isDiagnosticByType ? typeStr : '진단평가'),
      badgeColorClass: 'bg-blue-50 text-blue-700 border-blue-200',
      searchKeywords: '진단평가 입학테스트 정규시험',
    };
  }

  // 5. 주간테스트: '주간테스트' 유형속성 또는 'xx주차 평가' 제목 패턴 시험지
  const isWeeklyTitle =
    /[0-9xX]+\s*주차\s*평가/.test(titleStr) ||
    /[0-9xX]+\s*주차\s*평가/.test(subTitleStr);
  if (typeStr === '주간테스트' || isWeeklyTitle) {
    return {
      bucket: 'WEEKLY',
      badgeLabel: '주간테스트',
      badgeColorClass: 'bg-cyan-50 text-cyan-700 border-cyan-300',
      searchKeywords: `${typeStr} 주간테스트 주차 평가`,
    };
  }

  // 6. 문제지 과제
  if (['과제', '과제프린트'].includes(typeStr)) {
    return {
      bucket: 'HOMEWORK',
      badgeLabel: typeStr,
      badgeColorClass: 'bg-amber-50 text-amber-700 border-amber-200',
      searchKeywords: `${typeStr} 문제지 과제`,
    };
  }

  // 7. 그 외 기타 평가 (중간평가, 단원평가, 선택없음 등)

  return {
    bucket: 'OTHER',
    badgeLabel: typeStr,
    badgeColorClass: 'bg-slate-100 text-slate-600 border-slate-300',
    searchKeywords: typeStr,
  };
}

export default function ExamListPage() {
  const router = useRouter();

  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);

  const [exams, setExams] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const EXAM_LIST_FILTER_STORAGE_KEY = "logica_exam_list_filter_state";
  const EXAM_LIST_SCROLL_STORAGE_KEY = "logica_exam_list_scroll_top";
  const EXAM_LIST_GRADING_MODAL_STORAGE_KEY = "logica_exam_list_grading_modal";

  const [mainTab, setMainTab] = useState<MainTabType>(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (VALID_MAIN_TABS.includes(saved.mainTab)) return saved.mainTab;
      } catch (e) {}
    }
    return 'ALL';
  });
  const [filterLevel, setFilterLevel] = useState(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (saved.filterLevel) return String(saved.filterLevel);
      } catch (e) {}
    }
    return "ALL";
  });
  const [filterGrade, setFilterGrade] = useState(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (saved.filterGrade) return String(saved.filterGrade);
      } catch (e) {}
    }
    return "ALL";
  });
  const [filterCreator, setFilterCreator] = useState(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (saved.filterCreator) return String(saved.filterCreator);
      } catch (e) {}
    }
    return "ALL";
  });
  const [searchQuery, setSearchQuery] = useState(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (typeof saved.searchQuery === "string") return saved.searchQuery;
      } catch (e) {}
    }
    return "";
  });
  const PAGE_SIZE = 30;
  const [currentPage, setCurrentPage] = useState<number>(() => {
    if (typeof window !== "undefined") {
      try {
        const saved = JSON.parse(sessionStorage.getItem("logica_exam_list_filter_state") || "{}");
        if (typeof saved.currentPage === "number" && saved.currentPage >= 1) return saved.currentPage;
      } catch (e) {}
    }
    return 1;
  });
  const listScrollRef = useRef<HTMLDivElement>(null);
  const restoredScrollRef = useRef(false);

  // 탭/분류/검색/페이지 상태가 바뀔 때마다 sessionStorage에 즉시 저장하여 Viewer나 Step 2에서 돌아왔을 때 그대로 유지
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      sessionStorage.setItem(
        EXAM_LIST_FILTER_STORAGE_KEY,
        JSON.stringify({ mainTab, filterLevel, filterGrade, filterCreator, searchQuery, currentPage })
      );
    } catch (e) {}
  }, [mainTab, filterLevel, filterGrade, filterCreator, searchQuery, currentPage]);

  // 목록 로딩 완료 후 이전 스크롤 위치 복원
  useEffect(() => {
    if (!isLoading && exams.length > 0 && !restoredScrollRef.current && listScrollRef.current) {
      restoredScrollRef.current = true;
      const savedTop = Number(sessionStorage.getItem(EXAM_LIST_SCROLL_STORAGE_KEY) || "0");
      if (savedTop > 0) {
        requestAnimationFrame(() => {
          if (listScrollRef.current) listScrollRef.current.scrollTop = savedTop;
        });
      }
    }
  }, [isLoading, exams.length]);

  const [publishModal, setPublishModal] = useState<{ isOpen: boolean; examId: string; title: string }>({ isOpen: false, examId: "", title: "" });
  const resolveInitialGradingModal = (): { isOpen: boolean; examId: string; title: string } => {
    if (typeof window !== "undefined") {
      try {
        const sp = new URLSearchParams(window.location.search);
        const qExamId = sp.get("open_grading_exam_id");
        const qTitle = sp.get("open_grading_title") || "";
        if (qExamId) {
          return { isOpen: true, examId: String(qExamId), title: String(qTitle) };
        }
      } catch (e) {}
      try {
        const saved = JSON.parse(sessionStorage.getItem(EXAM_LIST_GRADING_MODAL_STORAGE_KEY) || "null");
        if (saved && saved.isOpen && saved.examId) {
          return { isOpen: true, examId: String(saved.examId), title: String(saved.title || "") };
        }
      } catch (e) {}
    }
    return { isOpen: false, examId: "", title: "" };
  };

  const [gradingModal, setGradingModal] = useState<{ isOpen: boolean; examId: string; title: string }>(resolveInitialGradingModal);

  // 채점 페이지에서 뒤로가기로 복귀 시(URL 쿼리, sessionStorage, popstate, pageshow, focus 모두 대응) 출제 및 채점 현황 모달 복원
  // (주의: 여기서 sessionStorage를 자동 삭제하면 Strict Mode 이중 마운트나 라우터 캐시 복원 시 모달이 닫히므로, 닫기(onClose) 시에만 삭제)
  useEffect(() => {
    const syncGradingModalFromStorageOrUrl = () => {
      const resolved = resolveInitialGradingModal();
      if (resolved.isOpen && resolved.examId) {
        setGradingModal((prev) => {
          if (prev.isOpen && prev.examId === resolved.examId && prev.title) return prev;
          return resolved;
        });
      }
    };

    syncGradingModalFromStorageOrUrl();
    window.addEventListener("pageshow", syncGradingModalFromStorageOrUrl);
    window.addEventListener("popstate", syncGradingModalFromStorageOrUrl);
    window.addEventListener("focus", syncGradingModalFromStorageOrUrl);
    return () => {
      window.removeEventListener("pageshow", syncGradingModalFromStorageOrUrl);
      window.removeEventListener("popstate", syncGradingModalFromStorageOrUrl);
      window.removeEventListener("focus", syncGradingModalFromStorageOrUrl);
    };
  }, [isAuthorized]);

  // 만약 모달에 examId만 있고 title이 비어있다면 exams 로드 후 제목 자동 채움
  useEffect(() => {
    if (gradingModal.isOpen && gradingModal.examId && !gradingModal.title && exams.length > 0) {
      const matched = exams.find((e: any) => String(e.exam_id) === String(gradingModal.examId));
      if (matched?.title) {
        setGradingModal((prev) => ({ ...prev, title: matched.title }));
      }
    }
  }, [gradingModal.isOpen, gradingModal.examId, gradingModal.title, exams]);

  // 🌟 [정답지 조회 모달 상태]
  const [answerModal, setAnswerModal] = useState<{ isOpen: boolean; examId: string; title: string }>({ isOpen: false, examId: "", title: "" });
  const [answerData, setAnswerData] = useState<{
    num: number;
    subItems: {
      subIndex: number;
      answer: string;
      answerImg1: string;
      answerImg2: string;
    }[];
  }[]>([]);
  const [isLoadingAnswers, setIsLoadingAnswers] = useState(false);

  const [isSuperAdmin, setIsSuperAdmin] = useState(false);
  const [canDeleteExam, setCanDeleteExam] = useState(false);

  const mathJaxRef = useRef(false);

  // MathJax 초기화
  useEffect(() => {
    if (!document.getElementById("MathJax-script") && !mathJaxRef.current) {
      mathJaxRef.current = true;
      (window as any).MathJax = {
        tex: { inlineMath: [["$", "$"], ["\\(", "\\)"]], displayMath: [["$$", "$$"], ["\\[", "\\]"]], processEscapes: true },
        chtml: { displayAlign: 'center', displayIndent: '0em' },
        svg: { fontCache: 'global' }
      };
      const script = document.createElement("script");
      script.id = "MathJax-script";
      script.src = "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js";
      script.async = true;
      document.head.appendChild(script);
    }
  }, []);

  // 정답지 모달 렌더링 후 수식 변환 트리거
  useEffect(() => {
    if (answerModal.isOpen && answerData.length > 0) {
      const timer = setTimeout(() => {
        if (typeof window !== "undefined" && (window as any).MathJax && (window as any).MathJax.typesetPromise) {
          (window as any).MathJax.typesetPromise().catch(() => {});
        }
      }, 150);
      return () => clearTimeout(timer);
    }
  }, [answerModal.isOpen, answerData]);

  useEffect(() => {
    const checkAccess = async () => {
      if (!(await ensureInstructorSession())) {
        alert("로그인 정보가 없습니다. 다시 로그인해 주세요.");
        router.replace("/");
        return;
      }

      const role = localStorage.getItem("logica_instructor_role") || "";
      const pos = localStorage.getItem("logica_instructor_position") || "";
      const tId = localStorage.getItem("logica_tenant_id") || "";
      
      const isGodMode = role === 'SUPER_ADMIN' || role === 'ADMIN' || 
                        pos.includes('최고관리자') || pos.includes('대장') || pos.includes('원장');
      
      setIsSuperAdmin(isGodMode);

      if (isGodMode) {
        setIsAuthorized(true);
        setCanDeleteExam(true);
        return;
      }

      if (!tId || !role) {
         alert("권한 정보가 없습니다.");
         router.replace("/home");
         return;
      }

      const { data } = await supabase
        .from('tenant_role_permissions')
        .select('allowed_menus')
        .eq('tenant_id', tId)
        .eq('role_name', role)
        .maybeSingle();

      if (!data || (!data.allowed_menus.includes("ALL") && !data.allowed_menus.includes("/exam-list"))) {
        alert("⛔ 문제지 보관함에 접근할 권한이 없습니다.");
        router.replace("/home");
      } else {
        setIsAuthorized(true);
        if (data.allowed_menus.includes('action_delete_exam')) {
          setCanDeleteExam(true);
        }
      }
    };

    checkAccess();
  }, [router]);

  useEffect(() => {
    if (isAuthorized) {
      loadExams();
    }
  }, [isAuthorized]);

  const formatDateTime = (dateString: string) => {
    if (!dateString) return '-';
    const d = new Date(dateString);
    return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')} ${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };

  const loadExams = async (isSilent = false) => {
    if (!isSilent) setIsLoading(true);
    
    const tenantId = localStorage.getItem("logica_tenant_id");
    const result = await getExamsAction(tenantId || undefined);
    
    if (result.success) {
      let fetchedExams = result.data || [];
      if (tenantId && tenantId !== 'hq') {
         fetchedExams = fetchedExams.filter((e: any) => !e.tenant_id || e.tenant_id === tenantId);
      }
      setExams(fetchedExams);
    } else {
      alert(result.message);
    }
    
    if (!isSilent) setIsLoading(false);
  };

  const openAnswerModal = async (examId: string, title: string) => {
    setAnswerModal({ isOpen: true, examId, title });
    setIsLoadingAnswers(true);
    setAnswerData([]);
    try {
      const [{ data: masterRow }, { data: examItems, error }] = await Promise.all([
        supabase
          .from('exam_master')
          .select('exam_type, layout_settings')
          .eq('exam_id', examId)
          .maybeSingle(),
        supabase
          .from('exam_item')
          .select('question_id, sort_order, question_db(question_id, parent_question_id, question, answer, answer_image_url, answer_image_2_url, question_number, sub_num, pdf_source, source_book_name, book_name, final_printed_page, detected_page_num)')
          .eq('exam_id', examId)
          .order('sort_order', { ascending: true }),
      ]);

      if (error) throw error;

      const orderedQuestions = (examItems || [])
        .map((item: any) => {
          const qdb: any = Array.isArray(item.question_db) ? item.question_db[0] : item.question_db;
          if (!qdb) return null;
          return {
            ...qdb,
            question_id: qdb.question_id || item.question_id,
            sort_order: item.sort_order,
          };
        })
        .filter(Boolean);

      let userMergedTextQuestions: any[][] = [];
      const rawSettings = masterRow?.layout_settings;
      if (rawSettings) {
        const parsed = typeof rawSettings === 'string'
          ? (() => { try { return JSON.parse(rawSettings); } catch (e) { return null; } })()
          : rawSettings;
        if (Array.isArray(parsed?.userMergedTextQuestions)) {
          userMergedTextQuestions = parsed.userMergedTextQuestions;
        }
      }

      const customGroupMap = new Map<string, string>();
      userMergedTextQuestions.forEach((arr: any[], idx: number) => {
        const gId = `custom_group_${idx}`;
        (arr || []).forEach((qid: any) => customGroupMap.set(String(qid).replace(/_added_\d+$/, ''), gId));
      });

      let groupedList: { items: any[] }[] = [];
      const lType = masterRow?.exam_type || '';
      const parsedMasterSettings = rawSettings
        ? (typeof rawSettings === 'string'
            ? (() => { try { return JSON.parse(rawSettings); } catch { return null; } })()
            : rawSettings)
        : null;
      const isDiag =
        lType === '입학테스트' ||
        lType === '진단평가' ||
        ((lType === '분기평가' || lType === '분기테스트') &&
          (parsedMasterSettings?.isQuarterlyLock || orderedQuestions.length >= 30));
      if (isDiag && userMergedTextQuestions.length === 0 && orderedQuestions.length > 0) {
        const mergedBuilt = buildMergedQuestionGroups(orderedQuestions, true, true);
        groupedList = mergedBuilt.map((mg: any) => ({ items: mg.items || [] }));
      } else {
        const groupMap = new Map<string, { items: any[] }>();
        orderedQuestions.forEach((q: any) => {
          const realQId = String(q.question_id).replace(/_added_\d+$/, '');
          let gId = customGroupMap.get(realQId);
          if (!gId) gId = `single_${q.question_id}_${Math.random()}`;
          if (!groupMap.has(gId)) groupMap.set(gId, { items: [] });
          groupMap.get(gId)!.items.push(q);
        });
        groupedList = Array.from(groupMap.values());
        groupedList.forEach((g) => {
          if (g.items.length > 1) g.items.sort(compareSubQuestions);
        });
      }

      const formatted = groupedList.map((g, idx) => {
        const subItems = (g.items || []).map((q: any, sIdx: number) => {
          const rawAns = q?.answer !== null && q?.answer !== undefined && String(q.answer).trim() !== '' && String(q.answer).trim().toLowerCase() !== 'null'
            ? String(q.answer).trim()
            : '';
          const img1 = q?.answer_image_url && String(q.answer_image_url) !== 'null' && String(q.answer_image_url).trim() !== ''
            ? getCleanUrl(String(q.answer_image_url).trim())
            : '';
          const img2 = q?.answer_image_2_url && String(q.answer_image_2_url) !== 'null' && String(q.answer_image_2_url).trim() !== ''
            ? getCleanUrl(String(q.answer_image_2_url).trim())
            : '';
          return {
            subIndex: sIdx + 1,
            answer: rawAns,
            answerImg1: img1,
            answerImg2: img2,
          };
        });
        return {
          num: idx + 1,
          subItems,
        };
      });

      setAnswerData(formatted);
    } catch (err: any) {
      alert('정답 데이터를 불러오는 데 실패했습니다.');
    } finally {
      setIsLoadingAnswers(false);
    }
  };

  // 🌟 [핵심 변경] 수식을 완벽하게 파싱하고 줄바꿈 및 한글 깨짐을 방지하는 로직
  const formatMathTextForWeb = (text: string) => {
    if (!text) return "";
    let t = String(text);
    
    // 1. <br> 태그 보호
    t = t.replace(/<br\s*\/?>/gi, '[[BR]]');
    // 2. HTML 꺾쇠 이스케이프 처리
    t = t.replace(/</g, ' &lt; ').replace(/>/g, ' &gt; ');
    // 3. 보호된 <br> 태그 복구
    t = t.replace(/\[\[BR\]\]/g, '<br>');
    
    // 4. 기존 $ 또는 $$ 기호 완벽 제거 (전체를 $로 감쌀 때 오류 방지)
    t = t.replace(/\$\$/g, '');
    t = t.replace(/\$/g, '');

    // 5. 쉼표(,) 뒤에 띄어쓰기가 없으면 띄어쓰기 강제 추가 (자연스러운 줄바꿈 유도)
    t = t.replace(/,(?=[^\s])/g, ', ');

    // 6. 한글을 MathJax 변수(이탤릭체)로 인식하지 못하도록 \text{}로 감싸기
    t = t.replace(/([가-힣]+([ \t]*[가-힣]+)*)/g, '\\text{$1}');

    // 7. 동그라미 숫자(①~⑳)도 \text{}로 감싸기 (깨짐 방지)
    t = t.replace(/([①-⑳])/g, '\\text{$1}');
    
    return t;
  };

  const handlePrintAnswers = () => {
    const printWin = window.open('', '_blank');
    if (!printWin) {
      alert('팝업 차단이 설정되어 있습니다. 팝업을 허용해주세요.');
      return;
    }
    
    const content = answerData.map(item => {
      const isMulti = item.subItems.length > 1;
      const subsHtml = item.subItems.map(sub => {
        const prefixHtml = isMulti ? `<span style="color:#475569; font-weight:800; margin-right:6px;">(${sub.subIndex})</span>` : '';
        const ansHtml = sub.answer
          ? `$${formatMathTextForWeb(sub.answer)}$`
          : (sub.answerImg1 || sub.answerImg2 ? '' : '<span style="color:#94a3b8; font-size:13px;">정답 없음</span>');
        const img1Html = sub.answerImg1
          ? `<div style="margin-top:4px;"><a href="${sub.answerImg1}" target="_blank" rel="noopener noreferrer" style="font-size:11px; color:#059669; font-weight:bold; text-decoration:underline;">🖼️ 해답 이미지 보기</a><div style="margin-top:4px;"><img src="${sub.answerImg1}" style="max-width:100%; max-height:120px; object-fit:contain; border-radius:4px; border:1px solid #e2e8f0;" /></div></div>`
          : '';
        const img2Html = sub.answerImg2
          ? `<div style="margin-top:4px;"><a href="${sub.answerImg2}" target="_blank" rel="noopener noreferrer" style="font-size:11px; color:#059669; font-weight:bold; text-decoration:underline;">🖼️ 해답 이미지 2 보기</a><div style="margin-top:4px;"><img src="${sub.answerImg2}" style="max-width:100%; max-height:120px; object-fit:contain; border-radius:4px; border:1px solid #e2e8f0;" /></div></div>`
          : '';
        return `<div style="margin-bottom:${isMulti ? '6px' : '0'}; text-align:${isMulti ? 'left' : 'center'}; width:100%;">${prefixHtml}${ansHtml}${img1Html}${img2Html}</div>`;
      }).join('');

      return `
      <div style="border: 1px solid #cbd5e1; padding: 12px; border-radius: 8px; text-align: center; break-inside: avoid; background-color: #fff; overflow: hidden; display: flex; flex-direction: column; align-items: center; justify-content: flex-start;">
        <div style="font-size: 13px; font-weight: bold; color: #002864; background: #eff6ff; padding: 3px 10px; border-radius: 12px; display: inline-block; margin-bottom: 8px; flex-shrink: 0;">${item.num}번</div>
        <div style="font-size: 15px; font-weight: bold; color: #334155; word-break: break-all; white-space: normal; line-height: 1.5; width: 100%; overflow-x: auto;">
          ${subsHtml}
        </div>
      </div>
    `;
    }).join('');

    printWin.document.write(`
      <html>
        <head>
          <title>${answerModal.title} - 정답지</title>
          <style>
            body { font-family: 'Malgun Gothic', 'Apple SD Gothic Neo', sans-serif; padding: 30px; background-color: #f8fafc; }
            h2 { text-align: center; color: #002864; margin-bottom: 30px; font-size: 24px; border-bottom: 2px solid #e2e8f0; padding-bottom: 15px; }
            .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; }
            /* 인쇄 시 MathJax 줄바꿈 강제 설정 */
            mjx-container { white-space: normal !important; word-wrap: break-word !important; }
            @media print { 
              .no-print { display: none; } 
              body { background-color: white; padding: 10px; }
            }
          </style>
          <script>
            MathJax = {
              tex: { inlineMath: [['$', '$'], ['\\\\(', '\\\\)']] },
              svg: { fontCache: 'global' }
            };
          </script>
          <script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
        </head>
        <body>
          <div class="no-print" style="text-align: right; margin-bottom: 20px;">
            <button onclick="window.print()" style="padding: 10px 20px; font-size: 15px; font-weight: bold; cursor: pointer; background: #002864; color: white; border: none; border-radius: 6px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">🖨️ 인쇄하기</button>
          </div>
          <h2>📑 [정답지] ${answerModal.title}</h2>
          <div class="grid">
            ${content}
          </div>
        </body>
      </html>
    `);
    printWin.document.close();
  };

  const uniqueGrades = useMemo(() => {
    const standardGrades = [
      "초등 1-1", "초등 1-2", "초등 2-1", "초등 2-2", "초등 3-1", "초등 3-2",
      "초등 4-1", "초등 4-2", "초등 5-1", "초등 5-2", "초등 6-1", "초등 6-2",
      "중등 1-1", "중등 1-2", "중등 2-1", "중등 2-2", "중등 3-1", "중등 3-2",
    ];
    const fromExams = (exams.map((e) => e.major_grade).filter(Boolean) as string[]).filter(
      (g) => !g.startsWith("고등") && !g.startsWith("고")
    );
    const merged = Array.from(new Set([...standardGrades, ...fromExams]));
    const getWeight = (g: string) => {
      if (g.startsWith("초등")) return 1;
      if (g.startsWith("중등")) return 2;
      return 9;
    };
    return merged.sort((a, b) => {
      const wA = getWeight(a);
      const wB = getWeight(b);
      if (wA !== wB) return wA - wB;
      return a.localeCompare(b, "ko", { numeric: true });
    });
  }, [exams]);

  const detectExamLevels = (exam: any): Set<string> => {
    const found = new Set<string>();
    let combined = `${exam.title || ""} ${exam.sub_title || ""}`;
    if (!combined.trim()) return found;

    const fullNames: [RegExp, string][] = [
      [/ultimate/gi, "Ultimate"],
      [/master/gi, "Master"],
      [/apex/gi, "Apex"],
      [/titan/gi, "Titan"],
      [/horizon/gi, "Horizon"],
    ];

    fullNames.forEach(([regex, levelName]) => {
      if (regex.test(combined)) {
        found.add(levelName);
        combined = combined.replace(regex, " ");
      }
    });

    // 영단어 일부가 아닌 독립/레벨 약어(예: 52U, 5-2M, [A], T반, H레벨, UM 등)에서 U, M, A, T, H 추출
    const codeRegex = /(?:^|[^a-zA-Z])([UMATH]{1,5})(?:[^a-zA-Z]|$)/gi;
    let match: RegExpExecArray | null;
    while ((match = codeRegex.exec(combined)) !== null) {
      const token = match[1].toUpperCase();
      if (token.includes("U")) found.add("Ultimate");
      if (token.includes("M")) found.add("Master");
      if (token.includes("A")) found.add("Apex");
      if (token.includes("T")) found.add("Titan");
      if (token.includes("H")) found.add("Horizon");
    }

    return found;
  };

  const matchesLevelFilter = (exam: any, selectedLevel: string): boolean => {
    if (selectedLevel === "ALL") return true;
    const levels = detectExamLevels(exam);
    if (selectedLevel === "기타") {
      return levels.size === 0;
    }
    return levels.has(selectedLevel);
  };

  const uniqueCreators = useMemo(() => {
    return Array.from(new Set(exams.map(e => {
      const instructor = Array.isArray(e.instructor) ? e.instructor[0] : e.instructor;
      return instructor?.name || '시스템 선생님';
    }))).sort();
  }, [exams]);

  const matchesGradeAndSubTitle = (exam: any, selectedGrade: string): boolean => {
    if (selectedGrade === "ALL") return true;
    if (exam.major_grade === selectedGrade || exam.target_grade === selectedGrade) return true;

    const sub = String(exam.sub_title || "").trim();
    if (!sub) return false;
    if (sub.includes(selectedGrade)) return true;

    const m = selectedGrade.match(/(초등|중등|고등)?\s*(\d+)\s*-\s*(\d+)/);
    if (!m) return sub.includes(selectedGrade);

    const school = m[1] || "";
    const g = m[2];
    const s = m[3];
    const dashToken = `${g}-${s}`;     // 예: "5-2"
    const compactToken = `${g}${s}`;   // 예: "52"

    // 학교급이 명시된 부제목에서 다른 학교급(초/중/고)과 혼동되는 경우 방지
    if (school === "초등" && (sub.includes("중") || sub.includes("고")) && !sub.includes("초")) {
      return false;
    }
    if (school === "중등" && (sub.includes("초") || sub.includes("고")) && !sub.includes("중")) {
      return false;
    }
    if (school === "고등" && (sub.includes("초") || sub.includes("중")) && !sub.includes("고")) {
      return false;
    }

    if (
      sub.includes(dashToken) ||
      sub.includes(compactToken) ||
      sub.includes(`${g}학년 ${s}학기`) ||
      sub.includes(`${g}학년${s}학기`)
    ) {
      return true;
    }

    if (school === "중등") {
      const midNum = Number(g) + 6;
      if (sub.includes(`${midNum}-${s}`) || sub.includes(`${midNum}${s}`)) {
        return true;
      }
    }

    return false;
  };

  const filteredExams = useMemo(() => {
    return exams.filter(exam => {
      const classified = classifyExamItem(exam);

      let matchMainTab = true;
      if (mainTab !== 'ALL') {
        matchMainTab = classified.bucket === mainTab;
      }

      const matchLevel = matchesLevelFilter(exam, filterLevel);
      const matchGrade = matchesGradeAndSubTitle(exam, filterGrade);
      
      const instructor = Array.isArray(exam.instructor) ? exam.instructor[0] : exam.instructor;
      const creatorName = instructor?.name || '시스템 선생님';
      const matchCreator = filterCreator === 'ALL' || creatorName === filterCreator;

      const q = searchQuery.trim().normalize('NFC').toLowerCase();
      let matchSearch = true;
      if (q) {
        const titleStr = String(exam.title || '').normalize('NFC').toLowerCase();
        const subTitleStr = String(exam.sub_title || '').normalize('NFC').toLowerCase();
        const scopeStartStr = String(exam.scope_start || '').normalize('NFC').toLowerCase();
        const scopeEndStr = String(exam.scope_end || '').normalize('NFC').toLowerCase();
        const gradeStr = String(exam.major_grade || '').normalize('NFC').toLowerCase();
        const typeLower = classified.searchKeywords.toLowerCase();
        const creatorLower = String(creatorName).normalize('NFC').toLowerCase();
        matchSearch =
          titleStr.includes(q) ||
          subTitleStr.includes(q) ||
          scopeStartStr.includes(q) ||
          scopeEndStr.includes(q) ||
          gradeStr.includes(q) ||
          typeLower.includes(q) ||
          creatorLower.includes(q);
      }
      
      return matchMainTab && matchLevel && matchGrade && matchCreator && matchSearch;
    });
  }, [exams, mainTab, filterLevel, filterGrade, filterCreator, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredExams.length / PAGE_SIZE));
  const safeCurrentPage = Math.min(currentPage, totalPages);

  const pagedExams = useMemo(() => {
    const start = (safeCurrentPage - 1) * PAGE_SIZE;
    return filteredExams.slice(start, start + PAGE_SIZE);
  }, [filteredExams, safeCurrentPage]);

  const handlePageChange = (nextPage: number) => {
    const clamped = Math.max(1, Math.min(totalPages, nextPage));
    setCurrentPage(clamped);
    if (listScrollRef.current) {
      listScrollRef.current.scrollTop = 0;
    }
  };

  const resetFilters = () => {
    setMainTab("ALL"); setFilterLevel("ALL"); setFilterGrade("ALL"); setFilterCreator("ALL"); setSearchQuery(""); setCurrentPage(1);
    try {
      sessionStorage.removeItem(EXAM_LIST_FILTER_STORAGE_KEY);
      sessionStorage.removeItem(EXAM_LIST_SCROLL_STORAGE_KEY);
    } catch (e) {}
  };

  const deleteExam = async (examId: string, examType: string, assignCount: number) => {
    if (!isSuperAdmin && !canDeleteExam) {
      alert("⛔ 출제된 문제지를 삭제할 권한이 없습니다.\n(원장님이 부여한 삭제 권한이 필요합니다.)");
      return;
    }

    if (!confirm("⚠️ 이 문제지를 정말 삭제하시겠습니까?\n(삭제하면 복구할 수 없습니다.)")) return;
    
    if (['오답프린트', '오답', '오답유사', '과제오답유사', '미완료과제'].includes(examType)) {
      if (assignCount >= 2) {
        alert("🚨 2명 이상의 학생에게 배부된 개인 맞춤 프린트는 직접 삭제할 수 없습니다!\n(다른 학생의 채점 기록이 함께 증발하는 것을 방지합니다.)\n\n해당 학생의 타임라인에서 개별적으로 배부 취소(삭제)를 진행해 주세요.");
        return;
      }

      try {
        const { data: assignments } = await supabase.from('exam_assignment').select('assignment_id').eq('exam_id', examId);
        
        if (assignments && assignments.length > 0) {
          const assignIds = assignments.map(a => a.assignment_id);
          await supabase.from('student_answer').delete().in('exam_assignment_id', assignIds);
          await supabase.from('exam_assignment').delete().eq('exam_id', examId);
        }
        
        await supabase.from('exam_item').delete().eq('exam_id', examId);
        await supabase.from('exam_master').delete().eq('exam_id', examId);

        alert("🗑️ 맞춤 프린트가 완전히 파기되었습니다.");
        loadExams(true); 
        return; 
      } catch (err: any) {
        alert("프린트 삭제 중 오류가 발생했습니다: " + err.message);
        return;
      }
    }

    const tenantId = localStorage.getItem("logica_tenant_id");
    const result = await deleteExamAction(examId, tenantId || undefined);
    if (result.success) {
      alert(result.message);
      loadExams(true);
    } else {
      alert(result.message);
    }
  };

  const clearSessionStorageForExam = () => {
    const keysToRemove = [
      'restoreExamQuestions', 'examQuestions', 'examTitle', 'examSubTitle', 'examType', 'examMode', 'testCategory', 'testSourceFilter', 'diagnosticQuestionIds',
      'editOriginalType', 'editOriginalId', 'editStudentId', 'editClassId', 'editMasterId',
      'examUserMergedTextQuestions', 'examHiddenImageQuestions', 'clinicTargetStudentId', 'clinicTargetClassId', 'clinicTargetStudentIds',
      'editHomeworkId', 'editExamId', 'duplicateExamId', 'splitHomeworkIds', 'splitCommonTqIds',
      'isClinicMode', 'logica_exam_list_grading_modal', 'logica_exam_list_from_grading_modal'
    ];
    keysToRemove.forEach(k => sessionStorage.removeItem(k));
  };

  const createNewExam = () => {
    clearSessionStorageForExam();
    router.push('/exam/step1'); 
  };

  const editExam = (examId: string) => {
    clearSessionStorageForExam();
    sessionStorage.setItem('editExamId', examId);
    router.push(`/exam/step2?exam_id=${examId}`);
  };

  const handleForceEdit = (examId: string) => {
    if (confirm("🚨 경고: 이미 배부되어 학생이 풀고 있을 수 있는 시험지입니다!\n강제 수정 시 기존 문항 및 채점 기록과 충돌이 발생할 수 있습니다.\n\n정말 강제로 수정하시겠습니까? (최고관리자 전용 기능)")) {
      editExam(examId);
    }
  };

  const duplicateAndEditExam = (examId: string) => {
    clearSessionStorageForExam();
    sessionStorage.setItem('duplicateExamId', examId);
    router.push(`/exam/step2?duplicate_exam_id=${examId}`);
  };

  if (isAuthorized === null) {
    return <div className="p-10 text-center font-bold text-slate-400">보안 권한 확인 중...</div>;
  }
  
  if (isAuthorized === false) {
    return null; 
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 p-4 sm:p-8 gap-5 overflow-hidden relative font-pretendard">
      
      <div className="flex justify-between items-end shrink-0">
        <div>
          <h2 className="text-xl font-bold text-slate-800">📝 문제지 보관함</h2>
          <p className="text-sm font-bold text-slate-400 mt-1">주간테스트, 오답프린트, 미완료과제, 문제지 과제, 쌍둥이/유사, 정규 시험(진단평가·분기평가)을 분류별로 조회하고 관리합니다.</p>
        </div>
      </div>

      <div className="bg-white px-4 py-3 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between shrink-0 flex-wrap gap-3">
        
        <div className="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl shadow-inner flex-wrap">
          <button 
            onClick={() => { setMainTab('ALL'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'ALL' ? 'bg-white text-slate-800 shadow-md' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-200'}`}
          >
            전체보기
          </button>
          <div className="w-px h-5 bg-slate-300 mx-0.5 hidden sm:block"></div>
          <button 
            onClick={() => { setMainTab('WEEKLY'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'WEEKLY' ? 'bg-cyan-600 text-white shadow-md' : 'text-slate-500 hover:text-cyan-700 hover:bg-cyan-50'}`}
            title="주간테스트 유형 및 xx주차 평가 시험지"
          >
            📅 주간테스트
          </button>
          <button 
            onClick={() => { setMainTab('INCORRECT'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'INCORRECT' ? 'bg-emerald-500 text-white shadow-md' : 'text-slate-500 hover:text-emerald-600 hover:bg-emerald-50'}`}
          >
            ❌ 오답프린트
          </button>
          <button 
            onClick={() => { setMainTab('OVERDUE'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'OVERDUE' ? 'bg-rose-500 text-white shadow-md' : 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'}`}
            title="클리닉실 및 회차 이관 미완료 과제 프린트"
          >
            ⏰ 미완료과제
          </button>
          <button 
            onClick={() => { setMainTab('HOMEWORK'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'HOMEWORK' ? 'bg-amber-500 text-white shadow-md' : 'text-slate-500 hover:text-amber-600 hover:bg-amber-50'}`}
          >
            📝 문제지과제
          </button>
          <button 
            onClick={() => { setMainTab('SIMILAR'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'SIMILAR' ? 'bg-violet-500 text-white shadow-md' : 'text-slate-500 hover:text-violet-600 hover:bg-violet-50'}`}
          >
            🔄 쌍둥이/유사
          </button>
          <button 
            onClick={() => { setMainTab('EXAM'); setCurrentPage(1); }} 
            className={`px-3.5 py-2 rounded-lg font-bold text-[13px] transition-all whitespace-nowrap ${mainTab === 'EXAM' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-500 hover:text-blue-600 hover:bg-blue-50'}`}
            title="입학테스트 · 진단평가 · 분기평가"
          >
            💯 정규 시험
          </button>
        </div>

        <div className="flex items-center gap-2.5 flex-wrap">
          <div className="relative w-64 sm:w-72">
            <span className="absolute inset-y-0 left-0 flex items-center pl-3 text-slate-400 pointer-events-none">🔍</span>
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              placeholder="문제지 제목, 부제목, 범위, 출제자 검색..."
              className="w-full pl-9 pr-8 py-2 border border-slate-300 rounded-lg text-sm font-bold text-slate-700 placeholder:text-slate-400 focus:outline-none focus:border-brand focus:ring-1 focus:ring-brand bg-white shadow-inner"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => { setSearchQuery(""); setCurrentPage(1); }}
                className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-slate-400 hover:text-rose-500 font-bold text-xs"
                title="검색어 지우기"
              >
                ✕
              </button>
            )}
          </div>
          <select value={filterLevel} onChange={e => { setFilterLevel(e.target.value); setCurrentPage(1); }} className="border border-slate-300 text-slate-600 text-sm font-bold rounded-lg px-3 py-2 focus:outline-none focus:border-brand">
            <option value="ALL">레벨 전체</option>
            <option value="Ultimate">Ultimate</option>
            <option value="Master">Master</option>
            <option value="Apex">Apex</option>
            <option value="Titan">Titan</option>
            <option value="Horizon">Horizon</option>
            <option value="기타">기타</option>
          </select>
          <select value={filterGrade} onChange={e => { setFilterGrade(e.target.value); setCurrentPage(1); }} className="border border-slate-300 text-slate-600 text-sm font-bold rounded-lg px-3 py-2 focus:outline-none focus:border-brand">
            <option value="ALL">학년 전체</option>
            {uniqueGrades.map(g => <option key={g} value={g as string}>{g as string}</option>)}
          </select>
          <select value={filterCreator} onChange={e => { setFilterCreator(e.target.value); setCurrentPage(1); }} className="border border-slate-300 text-slate-600 text-sm font-bold rounded-lg px-3 py-2 focus:outline-none focus:border-brand">
            <option value="ALL">출제자 전체</option>
            {uniqueCreators.map(c => <option key={c} value={c as string}>{c as string}</option>)}
          </select>
          <button onClick={resetFilters} className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold text-sm rounded-lg transition-colors border border-slate-300 flex items-center gap-1">
            🔄 초기화
          </button>
          <button onClick={createNewExam} className="ml-2 px-5 py-2.5 bg-brand text-white font-bold text-sm rounded-lg hover:bg-blue-900 transition-colors shadow-sm flex items-center gap-2">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4"></path></svg>
            새 문제지
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl border border-slate-200 shadow-sm flex-1 flex flex-col overflow-hidden min-h-0">
        <div
          ref={listScrollRef}
          onScroll={(e) => {
            try {
              sessionStorage.setItem(EXAM_LIST_SCROLL_STORAGE_KEY, String(e.currentTarget.scrollTop));
            } catch (err) {}
          }}
          className="overflow-y-auto flex-1 custom-scroll"
        >
          <table className="w-full text-left border-collapse whitespace-nowrap">
            <thead className="bg-slate-50 border-b border-slate-200 sticky top-0 z-10">
              <tr>
                <th className="py-2 px-3 font-bold text-slate-500 text-xs text-center w-20">학년 범위</th>
                <th className="py-2 px-3 font-bold text-slate-500 text-xs text-center w-24">유형 속성</th>
                <th className="py-2 px-3.5 font-bold text-slate-500 text-xs">시험지 제목 및 범위</th>
                <th className="py-2 px-3 font-bold text-slate-500 text-xs text-center">생성일시</th>
                <th className="py-2 px-3 font-bold text-slate-500 text-xs text-center">출제자</th>
                <th className="py-2 px-3.5 font-bold text-slate-500 text-xs text-right">관리 액션</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {isLoading ? (
                <tr><td colSpan={6} className="py-10 text-center text-slate-400 font-bold">데이터를 불러오는 중입니다...</td></tr>
              ) : filteredExams.length === 0 ? (
                <tr><td colSpan={6} className="py-10 text-center text-slate-400 font-bold">해당 조건의 문제지가 없습니다.</td></tr>
              ) : (
                pagedExams.map(exam => {
                  const instructor = Array.isArray(exam.instructor) ? exam.instructor[0] : exam.instructor;
                  const creatorName = instructor?.name ? `${instructor.name} 선생님` : '시스템 선생님';
                  const deriveGradeFromExam = (ex: any): string => {
                    if (ex.major_grade && ex.major_grade !== '공통 과정') return ex.major_grade;
                    if (ex.target_grade && ex.target_grade !== '공통 과정') return ex.target_grade;
                    const src = `${ex.sub_title || ''} ${ex.title || ''}`;
                    const mMid = src.match(/중(?:등)?\s*([1-3]-[1-2])/);
                    if (mMid) return `중등 ${mMid[1]}`;
                    const mMidCompact = src.match(/중(?:등)?\s*([1-3])([1-2])(?:[^0-9]|$)/);
                    if (mMidCompact) return `중등 ${mMidCompact[1]}-${mMidCompact[2]}`;
                    const mElem = src.match(/(?:초(?:등)?\s*)?([1-6]-[1-2])/);
                    if (mElem) return `초등 ${mElem[1]}`;
                    const mLevelCompact = src.match(/(?:^|[^0-9A-Za-z])(?:[UMATHumath]|초(?:등)?)\s*([1-6])([1-2])(?:[^0-9]|$)/);
                    if (mLevelCompact) return `초등 ${mLevelCompact[1]}-${mLevelCompact[2]}`;
                    return ex.major_grade || '공통 과정';
                  };
                  const targetGrade = deriveGradeFromExam(exam);
                  const diff = exam.avg_difficulty || '중';
                  
                  let scope = '전 범위';
                  const cleanStart = exam.scope_start && exam.scope_start !== '-' && exam.scope_start !== '분류 없음' && exam.scope_start !== '유형 분류 없음' ? exam.scope_start : '';
                  const cleanEnd = exam.scope_end && exam.scope_end !== '-' && exam.scope_end !== '분류 없음' && exam.scope_end !== '유형 분류 없음' ? exam.scope_end : '';
                  if (cleanStart && cleanEnd) scope = (cleanStart === cleanEnd) ? cleanStart : `${cleanStart} ~ ${cleanEnd}`;
                  else if (cleanStart) scope = cleanStart;

                  const assignCount = exam.exam_assignment ? exam.exam_assignment.length : 0;
                  const isDistributed = assignCount > 0;
                  
                  const createdTime = new Date(exam.created_at).getTime();
                  const isNew = !isNaN(createdTime) && ((Date.now() - createdTime) / (1000 * 3600 * 24)) <= 2;

                  const classified = classifyExamItem(exam);
                  const typeColorClass = classified.badgeColorClass;
                  const displayTypeStr = classified.badgeLabel;

                  return (
                    <tr key={exam.exam_id} className="hover:bg-slate-50 transition-colors border-b border-slate-100">
                      <td className="py-2 px-3 text-center"><span className="font-bold text-slate-600 text-xs">{targetGrade}</span></td>
                      <td className="py-2 px-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[11px] font-bold shadow-sm border ${typeColorClass}`}>{displayTypeStr}</span>
                      </td>
                      <td className="py-2 px-3.5">
                        <div className="flex items-center gap-1.5 mb-0.5 min-w-0">
                          <button 
                            onClick={() => openAnswerModal(exam.exam_id, exam.title)} 
                            className="bg-slate-100 hover:bg-slate-200 text-slate-500 border border-slate-200 px-1.5 py-0.5 rounded text-[11px] font-bold shadow-sm shrink-0 transition-colors" 
                            title="정답지만 모아보기 및 인쇄"
                          >
                            📑 정답
                          </button>

                          <button onClick={() => { clearSessionStorageForExam(); router.push(`/exam/viewer?exam_id=${exam.exam_id}`); }} className="font-bold text-slate-800 text-[13.5px] hover:underline hover:text-blue-600 transition-colors text-left truncate">{exam.title}</button>
                          
                          {exam.sub_title && exam.sub_title !== '-' && <span className="bg-indigo-50 text-indigo-600 border border-indigo-200 px-1.5 py-0.5 rounded text-[11px] font-bold shadow-sm shrink-0">{exam.sub_title}</span>}
                          {isNew && <span className="text-[10px] font-bold text-blue-500 tracking-tighter bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100 shrink-0">NEW</span>}
                        </div>
                        <div className="text-[11px] font-bold text-slate-400 tracking-tight flex items-center gap-1.5 pl-[46px]">
                          <span>{exam.total_questions || 0}문제</span><span className="text-slate-300">|</span><span>{diff}</span><span className="text-slate-300">|</span><span className="truncate max-w-[240px]" title={scope}>{scope}</span>
                        </div>
                      </td>
                      <td className="py-2 px-3 text-center text-slate-500 font-bold text-[11px]">{formatDateTime(exam.created_at)}</td>
                      <td className="py-2 px-3 text-center text-slate-600 font-bold text-[11px]">{creatorName}</td>
                      <td className="py-2 px-3.5">
                        <div className="flex items-center justify-end gap-1 whitespace-nowrap">
                          <button
                            onClick={() =>
                              window.open(
                                `/exam/clinic-preview?exam_id=${encodeURIComponent(exam.exam_id)}`,
                                "_blank",
                                "width=1680,height=980,top=40,left=60,resizable=yes,scrollbars=yes"
                              )
                            }
                            className="px-2.5 h-[27px] flex items-center justify-center shrink-0 bg-violet-50 hover:bg-violet-100 text-violet-700 border border-violet-200 rounded text-[11px] font-bold shadow-sm transition-colors cursor-pointer"
                            title="학생 포털 및 클리닉 관제탑 시뮬레이터를 새 창에서 엽니다"
                          >
                            클리닉 미리보기
                          </button>

                          <button onClick={() => setPublishModal({ isOpen: true, examId: exam.exam_id, title: exam.title })} className="w-[56px] h-[27px] flex items-center justify-center shrink-0 bg-brand hover:bg-blue-900 text-white rounded text-[11px] font-bold shadow-sm transition-colors">
                            출제하기
                          </button>
                          
                          <button onClick={() => {
                            try {
                              if (listScrollRef.current) {
                                sessionStorage.setItem(EXAM_LIST_SCROLL_STORAGE_KEY, String(listScrollRef.current.scrollTop));
                              }
                              sessionStorage.setItem(
                                EXAM_LIST_GRADING_MODAL_STORAGE_KEY,
                                JSON.stringify({ isOpen: true, examId: exam.exam_id, title: exam.title })
                              );
                              sessionStorage.setItem("logica_exam_list_from_grading_modal", "1");
                              window.history.replaceState(
                                null,
                                "",
                                `/exam-list?open_grading_exam_id=${encodeURIComponent(exam.exam_id)}&open_grading_title=${encodeURIComponent(exam.title || "")}`
                              );
                            } catch (e) {}
                            setGradingModal({ isOpen: true, examId: exam.exam_id, title: exam.title });
                          }} className="w-[74px] h-[27px] flex items-center justify-center shrink-0 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 rounded text-[11px] font-bold shadow-sm transition-colors">
                            출제현황({assignCount}명)
                          </button>
                          
                          {isDistributed ? (
                            isSuperAdmin ? (
                              <button onClick={() => handleForceEdit(exam.exam_id)} className="w-[66px] h-[27px] flex items-center justify-center shrink-0 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded text-[11px] font-bold shadow-sm transition-colors border border-rose-200 gap-0.5" title="최고관리자 전용 강제 수정">
                                🚨 강제수정
                              </button>
                            ) : (
                              <button disabled className="w-[66px] h-[27px] flex items-center justify-center shrink-0 bg-slate-50 text-slate-400 rounded text-[11px] font-bold cursor-not-allowed border border-slate-200 gap-0.5" title="이미 출제되어 수정할 수 없습니다">
                                🔒 수정불가
                              </button>
                            )
                          ) : (
                            <button onClick={() => editExam(exam.exam_id)} className="w-[58px] h-[27px] flex items-center justify-center shrink-0 bg-white hover:bg-slate-50 text-slate-600 rounded text-[11px] font-bold shadow-sm transition-colors border border-slate-300">
                              수정
                            </button>
                          )}

                          <button onClick={() => duplicateAndEditExam(exam.exam_id)} className="w-[66px] h-[27px] flex items-center justify-center shrink-0 bg-white hover:bg-indigo-50 text-indigo-600 rounded text-[11px] font-bold shadow-sm transition-colors border border-indigo-200">
                            복제후수정
                          </button>
                          
                          {canDeleteExam && (
                            <button onClick={() => deleteExam(exam.exam_id, classified.bucket === 'OVERDUE' ? '미완료과제' : exam.exam_type, assignCount)} className="w-[42px] h-[27px] flex items-center justify-center shrink-0 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded text-[11px] font-bold shadow-sm transition-colors border border-rose-200">
                              삭제
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* 🌟 하단 30개 단위 페이지네이션 바 */}
        {!isLoading && filteredExams.length > 0 && (
          <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between flex-wrap gap-3 shrink-0">
            <div className="text-xs font-bold text-slate-500">
              총 <span className="text-brand">{filteredExams.length}</span>개 문제지 중{" "}
              <span className="text-slate-700">
                {(safeCurrentPage - 1) * PAGE_SIZE + 1}~{Math.min(safeCurrentPage * PAGE_SIZE, filteredExams.length)}
              </span>
              번째 표시 (페이지당 {PAGE_SIZE}개)
            </div>

            {totalPages > 1 && (
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  disabled={safeCurrentPage <= 1}
                  onClick={() => handlePageChange(1)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="첫 페이지"
                >
                  «
                </button>
                <button
                  type="button"
                  disabled={safeCurrentPage <= 1}
                  onClick={() => handlePageChange(safeCurrentPage - 1)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  ‹ 이전
                </button>

                {(() => {
                  const maxVisible = 7;
                  let startP = Math.max(1, safeCurrentPage - Math.floor(maxVisible / 2));
                  let endP = Math.min(totalPages, startP + maxVisible - 1);
                  if (endP - startP + 1 < maxVisible) {
                    startP = Math.max(1, endP - maxVisible + 1);
                  }
                  const pages: number[] = [];
                  for (let p = startP; p <= endP; p++) pages.push(p);
                  return pages.map((p) => (
                    <button
                      key={p}
                      type="button"
                      onClick={() => handlePageChange(p)}
                      className={`min-w-[32px] h-[30px] px-2 rounded-lg text-xs font-bold border transition-all ${
                        p === safeCurrentPage
                          ? "bg-brand text-white border-brand shadow-sm"
                          : "bg-white text-slate-600 border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      {p}
                    </button>
                  ));
                })()}

                <button
                  type="button"
                  disabled={safeCurrentPage >= totalPages}
                  onClick={() => handlePageChange(safeCurrentPage + 1)}
                  className="px-3 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                >
                  다음 ›
                </button>
                <button
                  type="button"
                  disabled={safeCurrentPage >= totalPages}
                  onClick={() => handlePageChange(totalPages)}
                  className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-xs font-bold text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="마지막 페이지"
                >
                  »
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <PublishModal 
        isOpen={publishModal.isOpen} 
        examId={publishModal.examId} 
        title={publishModal.title} 
        onClose={() => setPublishModal({ isOpen: false, examId: "", title: "" })} 
        onSuccess={() => loadExams(true)} 
      />

      <GradingModal 
        isOpen={gradingModal.isOpen} 
        examId={gradingModal.examId} 
        title={gradingModal.title} 
        onClose={() => {
          try {
            sessionStorage.removeItem(EXAM_LIST_GRADING_MODAL_STORAGE_KEY);
            sessionStorage.removeItem("logica_exam_list_from_grading_modal");
            if (window.location.search.includes("open_grading_exam_id")) {
              window.history.replaceState(null, "", "/exam-list");
            }
          } catch (e) {}
          setGradingModal({ isOpen: false, examId: "", title: "" });
        }} 
        onUpdate={() => loadExams(true)} 
      />

      {/* 🌟 방어용 스크롤 및 오버플로우 방지가 적용된 정답지 모달 뷰어 */}
      {answerModal.isOpen && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-4xl max-h-[85vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
            <div className="bg-brand p-4 text-white flex justify-between items-center shrink-0">
              <h2 className="font-bold text-lg flex items-center gap-2"><span>📑</span> 정답지 조회: {answerModal.title}</h2>
              <button onClick={() => setAnswerModal({ isOpen: false, examId: '', title: '' })} className="text-white hover:text-rose-400 font-bold text-2xl leading-none">&times;</button>
            </div>
            
            <div className="p-6 overflow-y-auto custom-scroll flex-1 bg-slate-50" id="print-answer-area">
              {isLoadingAnswers ? (
                <div className="flex flex-col items-center justify-center h-full text-slate-400">
                  <div className="w-8 h-8 border-4 border-brand border-t-transparent rounded-full animate-spin mb-4"></div>
                  <div className="font-bold">정답을 불러오는 중입니다...</div>
                </div>
              ) : answerData.length === 0 ? (
                <div className="text-center py-10 text-slate-400 font-bold">등록된 정답이 없습니다.</div>
              ) : (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                  {answerData.map(item => {
                    const isMulti = item.subItems.length > 1;
                    return (
                      <div key={item.num} className="bg-white border border-slate-200 pt-4 pb-3 px-3 rounded-xl shadow-sm flex flex-col items-center justify-start text-center overflow-hidden">
                        <span className="text-xs font-bold text-brand bg-blue-50 px-2.5 py-0.5 rounded-full mb-2.5 shadow-sm shrink-0">
                          {item.num}번{isMulti ? ` (${item.subItems.length})` : ''}
                        </span>
                        {/* 🌟 서브문항별 정답 및 해답 이미지 링크 표시 */}
                        <div className="w-full overflow-x-auto custom-scroll pb-1 flex flex-col gap-2">
                          {item.subItems.map((sub) => {
                            const hasText = Boolean(sub.answer);
                            const hasImg = Boolean(sub.answerImg1 || sub.answerImg2);
                            return (
                              <div
                                key={sub.subIndex}
                                className={`w-full flex flex-col ${isMulti ? 'items-start text-left border-b border-dashed border-slate-100 last:border-b-0 pb-1.5 last:pb-0' : 'items-center text-center'}`}
                              >
                                <div className="flex items-start gap-1.5 w-full">
                                  {isMulti && (
                                    <span className="text-[12px] font-extrabold text-slate-500 shrink-0 mt-0.5">
                                      ({sub.subIndex})
                                    </span>
                                  )}
                                  {hasText ? (
                                    <div
                                      className="math-text text-[14px] font-bold text-slate-700 break-all whitespace-normal leading-relaxed px-0.5 flex-1"
                                      dangerouslySetInnerHTML={{ __html: `$${formatMathTextForWeb(sub.answer)}$` }}
                                    />
                                  ) : !hasImg ? (
                                    <span className="text-xs font-bold text-slate-400">정답 없음</span>
                                  ) : null}
                                </div>
                                {hasImg && (
                                  <div className={`flex flex-col gap-1.5 mt-1 w-full ${isMulti ? 'pl-5 items-start' : 'items-center'}`}>
                                    {sub.answerImg1 && (
                                      <a
                                        href={sub.answerImg1}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex flex-col items-center gap-1 px-2 py-1 rounded-md bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-[11px] font-extrabold transition-colors"
                                        title="클릭하여 원본 해답 이미지 새 창으로 열기"
                                      >
                                        <span>🖼️ {sub.answerImg2 ? '해답 이미지 1 보기 ↗' : '해답 이미지 보기 ↗'}</span>
                                        <img
                                          src={sub.answerImg1}
                                          alt="해답 이미지"
                                          className="max-h-20 max-w-full object-contain rounded bg-white border border-emerald-100 p-0.5"
                                        />
                                      </a>
                                    )}
                                    {sub.answerImg2 && (
                                      <a
                                        href={sub.answerImg2}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        className="inline-flex flex-col items-center gap-1 px-2 py-1 rounded-md bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-emerald-700 text-[11px] font-extrabold transition-colors"
                                        title="클릭하여 원본 해답 이미지 2 새 창으로 열기"
                                      >
                                        <span>🖼️ 해답 이미지 2 보기 ↗</span>
                                        <img
                                          src={sub.answerImg2}
                                          alt="해답 이미지 2"
                                          className="max-h-20 max-w-full object-contain rounded bg-white border border-emerald-100 p-0.5"
                                        />
                                      </a>
                                    )}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
            
            <div className="p-4 bg-white border-t border-slate-200 flex justify-end gap-3 shrink-0">
              <button 
                onClick={handlePrintAnswers} 
                disabled={isLoadingAnswers || answerData.length === 0}
                className="px-6 py-2.5 bg-blue-50 hover:bg-blue-100 border border-blue-200 text-blue-700 font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                <span>🖨️</span> 인쇄하기
              </button>
              <button 
                onClick={() => setAnswerModal({ isOpen: false, examId: '', title: '' })} 
                className="px-6 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg shadow-sm transition-colors"
              >
                닫기
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}