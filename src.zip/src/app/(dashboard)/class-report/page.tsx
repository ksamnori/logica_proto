// src/app/(dashboard)/class-report/page.tsx
"use client";

import React, { useEffect, useState, useMemo, useRef } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";

// 🌟 [추가 포인트] 분리한 모달 컴포넌트 임포트
import LessonLogModal from "@/components/dashboard/LessonLogModal";

type ReportTabType = 'LOG' | 'ALL' | 'EXAM' | 'HW' | 'OVERDUE' | 'PRINT' | 'SIMILAR';

interface ClassInfo {
  class_id: string;
  name: string;
  status?: string;
  instructor_id?: string;
  instructor?: any; 
}

interface AnalyzedItem {
  id: string;
  type: ReportTabType;
  sourceType: 'TEXTBOOK' | 'EXAM';
  title: string;
  date: string;
  totalQ: number;
  status: string;
  underlyingIds: string[]; 
}

interface MatrixCol {
  qId: string;
  displayNum: string;
  page: string;
  number: string;
  questionText: string;
  imageUrl: string;
  answer: string;
}

interface MatrixCell {
  code: string;
  isBlocked: boolean; 
}

interface MatrixRow {
  studentId: string;
  studentName: string;
  cells: Record<string, MatrixCell>; 
  totalCorrect: number;
  status: string; 
}

const safeParseIds = (raw: any): number[] => {
  if (!raw) return [];
  try {
    let val = raw;
    if (typeof val === 'string') {
      if (val === "null" || val.trim() === "") return [];
      val = JSON.parse(val);
    }
    if (Array.isArray(val)) return val.map(Number);
  } catch (err) {
    console.warn("데이터 파싱 경고:", err);
  }
  return [];
};

export default function ClassReportPage() {
  const router = useRouter(); 
  
  const [currentUser, setCurrentUser] = useState({ instId: "", name: "", isSuperLevel: false, isAdmin: false });

  const [classes, setClasses] = useState<ClassInfo[]>([]);
  const [selectedClassId, setSelectedClassId] = useState<string>("");
  const [activeTab, setActiveTab] = useState<ReportTabType>('ALL');
  
  const [assignments, setAssignments] = useState<AnalyzedItem[]>([]);
  const [selectedItem, setSelectedItem] = useState<AnalyzedItem | null>(null);

  const [lessonLogs, setLessonLogs] = useState<any[]>([]);
  const [selectedLog, setSelectedLog] = useState<any | null>(null);
  
  const [matrixCols, setMatrixCols] = useState<MatrixCol[]>([]);
  const [matrixRows, setMatrixRows] = useState<MatrixRow[]>([]);
  const [questionRates, setQuestionRates] = useState<Record<string, number>>({});
  
  const [isLoading, setIsLoading] = useState(true);
  const [isMatrixLoading, setIsMatrixLoading] = useState(false);

  const [modalQuestion, setModalQuestion] = useState<MatrixCol | null>(null);
  const mathJaxRef = useRef(false);

  // 🌟 [수정 포인트] 복잡한 폼 상태 제거하고, 모달 표시 여부와 편집할 데이터만 관리
  const [isLessonLogModalOpen, setIsLessonLogModalOpen] = useState(false);
  const [editingLogData, setEditingLogData] = useState<any | null>(null);

  const classListRef = useRef<HTMLDivElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [dragged, setDragged] = useState(false);
  const [startX, setStartX] = useState(0);
  const [scrollLeft, setScrollLeft] = useState(0);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (!classListRef.current) return;
    setIsDragging(true);
    setDragged(false);
    setStartX(e.pageX - classListRef.current.offsetLeft);
    setScrollLeft(classListRef.current.scrollLeft);
  };

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!isDragging || !classListRef.current) return;
      e.preventDefault(); 
      const x = e.pageX - classListRef.current.offsetLeft;
      const walk = (x - startX) * 1.5; 
      if (Math.abs(walk) > 5) setDragged(true); 
      classListRef.current.scrollLeft = scrollLeft - walk;
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      setTimeout(() => setDragged(false), 50); 
    };

    if (isDragging) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
    }

    return () => {
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };
  }, [isDragging, startX, scrollLeft]);

  const handleClassClick = (e: React.MouseEvent, classId: string) => {
    if (dragged) {
      e.preventDefault();
      return; 
    }
    setSelectedClassId(classId);
  };

  const loadMathJax = () => {
    if (!document.getElementById("MathJax-script") && !mathJaxRef.current) {
      mathJaxRef.current = true;
      (window as any).MathJax = {
        tex: { inlineMath: [["$", "$"], ["\\(", "\\)"]], displayMath: [["$$", "$$"], ["\\[", "\\]"]], processEscapes: true },
        chtml: { displayAlign: 'left', displayIndent: '0em' },
        svg: { fontCache: 'global' }
      };
      const script = document.createElement("script");
      script.id = "MathJax-script";
      script.src = "https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js";
      script.async = true;
      document.head.appendChild(script);
    }
  };

  useEffect(() => { loadMathJax(); }, []);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (typeof window !== "undefined" && (window as any).MathJax && (window as any).MathJax.typesetPromise) {
        (window as any).MathJax.typesetPromise().catch(() => {});
      }
    }, 100);
    return () => clearTimeout(timer);
  }, [modalQuestion]);

  const getCleanUrl = (url: string) => {
    if (!url || url === 'null') return '';
    let validUrl = url;
    if (typeof validUrl === 'string' && validUrl.trim().startsWith('[')) { try { validUrl = JSON.parse(validUrl)[0]; } catch(e) {} }
    if (validUrl && validUrl !== 'null' && !validUrl.startsWith('http') && !validUrl.startsWith('data:image')) {
      validUrl = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/question_images/${validUrl}`;
    }
    return validUrl;
  };

  const formatMathTextForWeb = (text: string) => {
    if (!text) return "";
    let t = String(text).replace(/<br\s*\/?>/gi, '__LOGICA_BR_PLACEHOLDER__');
    t = t.replace(/</g, ' &lt; ').replace(/>/g, ' &gt; ');
    t = t.replace(/__LOGICA_BR_PLACEHOLDER__/g, '<br>');
    return t;
  };

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const urlTab = searchParams.get('tab');
    if (urlTab && ['LOG', 'ALL', 'EXAM', 'HW', 'OVERDUE', 'PRINT', 'SIMILAR'].includes(urlTab)) {
      setActiveTab(urlTab as ReportTabType);
    }

    const fetchClasses = async () => {
      const instId = localStorage.getItem('logica_instructor_id') || "";
      const name = localStorage.getItem('logica_instructor_name') || "";
      const tenantId = localStorage.getItem('logica_tenant_id');
      const role = localStorage.getItem('logica_instructor_role');
      const pos = localStorage.getItem('logica_instructor_position') || '';
      
      const isSuperLevel = role === 'SUPER_ADMIN' || role === 'ADMIN' || pos.includes('최고관리자') || pos.includes('원장') || pos.includes('실장');
      const isAdmin = role === 'SUPER_ADMIN' || role === 'ADMIN' || pos.includes('원장') || pos.includes('최고관리자');

      setCurrentUser({ instId, name, isSuperLevel, isAdmin });

      let query = supabase.from('class').select('class_id, name, status, instructor_id, instructor(name)').order('name');
      if (tenantId && tenantId !== 'hq') query = query.eq('tenant_id', tenantId);
      if (!isAdmin && instId) query = query.eq('instructor_id', instId);

      const { data, error } = await query;
      if (error) console.error("클래스 데이터 로딩 실패:", error);

      if (data && data.length > 0) {
        const activeClasses = data.filter((c: any) => c.status !== "종료" && c.status !== "폐강");
        setClasses(activeClasses);

        const urlClassId = searchParams.get('class_id');
        if (urlClassId && activeClasses.some((c: any) => c.class_id === urlClassId)) {
          setSelectedClassId(urlClassId);
          
          setTimeout(() => {
             if (classListRef.current) {
               const activeBtn = classListRef.current.querySelector(`button[data-class-id="${urlClassId}"]`) as HTMLElement;
               if (activeBtn) {
                 const scrollPos = activeBtn.offsetLeft - classListRef.current.offsetLeft - 20;
                 classListRef.current.scrollTo({ left: scrollPos, behavior: 'smooth' });
               }
             }
          }, 100);

        } else if (activeClasses.length > 0) {
          setSelectedClassId(activeClasses[0].class_id);
        }
      }
      setIsLoading(false);
    };
    fetchClasses();
  }, []);

  const handleDeleteLog = async (e: React.MouseEvent, logId: number) => {
    e.stopPropagation(); 
    if (!confirm("정말 이 수업 일지를 삭제하시겠습니까?\n이 작업은 되돌릴 수 없습니다.")) return;

    try {
      const { error } = await supabase.from('daily_lesson_log').delete().eq('lesson_log_id', logId);
      if (error) throw error;
      alert("✅ 성공적으로 삭제되었습니다.");
      if (selectedLog && selectedLog.lesson_log_id === logId) setSelectedLog(null);
      fetchAssignmentsAndLogs(); 
    } catch (err: any) {
      console.error("삭제 에러:", err);
      alert("삭제 중 오류가 발생했습니다: " + err.message);
    }
  };

  const formatDateLabel = (dateStr: string) => {
    if (!dateStr) return '-';
    const d = new Date(dateStr);
    return `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, '0')}.${String(d.getDate()).padStart(2, '0')}`;
  };

  const fetchAssignmentsAndLogs = async () => {
    if (!selectedClassId) return;
    setIsLoading(true);
    try {
      const { data: logData } = await supabase
        .from('daily_lesson_log')
        .select(`
          lesson_log_id, 
          actual_date, 
          created_at,
          instructor_note, 
          homework_desc,
          lesson_log_student_comment(student_id, comment, student(name))
        `)
        .eq('class_id', selectedClassId)
        .order('actual_date', { ascending: false });
      
      setLessonLogs(logData || []);

      setSelectedLog((prev: any) => {
         if (!prev) return null;
         const updated = (logData || []).find((l: any) => l.lesson_log_id === prev.lesson_log_id);
         return updated || prev;
      });

      let list: AnalyzedItem[] = [];

      const { data: examData } = await supabase
        .from('exam_assignment')
        .select('exam_id, status, created_at, exam_master!inner(title, exam_type, total_questions)')
        .eq('class_id', selectedClassId);

      if (examData) {
        const groupedExams = new Map<string, any>();
        
        examData.forEach((a: any) => {
          const m = Array.isArray(a.exam_master) ? a.exam_master[0] : a.exam_master;
          const dateStr = formatDateLabel(a.created_at);
          const title = m?.title || '제목 없음';
          
          const key = `EXAM_${dateStr}_${title}`; 

          if (!groupedExams.has(key)) {
            let type: ReportTabType = 'EXAM';
            const eType = m?.exam_type;
            if (['과제', '과제프린트'].includes(eType)) type = 'HW';
            else if (['오답프린트', '오답'].includes(eType)) type = 'PRINT';
            else if (['오답유사', '과제오답유사'].includes(eType)) type = 'SIMILAR';
            else if (eType === '미완료과제') type = 'OVERDUE'; 

            groupedExams.set(key, {
              id: key, type, sourceType: 'EXAM', title, date: a.created_at,
              totalQ: m?.total_questions || 0,
              statuses: [], underlyingIds: new Set<string>()
            });
          }
          
          const g = groupedExams.get(key);
          g.underlyingIds.add(a.exam_id);
          g.statuses.push(a.status);
          g.totalQ = Math.max(g.totalQ, m?.total_questions || 0); 
        });

        groupedExams.forEach(g => {
          const isAllDone = g.statuses.length > 0 && g.statuses.every((s: string) => ['제출완료', '채점완료', '완료'].includes(s));
          list.push({ ...g, status: isAllDone ? '완료' : '진행중', underlyingIds: Array.from(g.underlyingIds) });
        });
      }

      const { data: hwData } = await supabase
        .from('homework_assignment')
        .select('homework_id, homework_title, created_at, target_questions, student_homework_result(status)')
        .eq('class_id', selectedClassId)
        .neq('homework_title', '[시스템] 수업 진도 완료 기록');

      if (hwData) {
        const groupedHws = new Map<string, any>();

        hwData.forEach((hw: any) => {
          const dateStr = formatDateLabel(hw.created_at);
          const title = hw.homework_title || '교재 과제';
          const key = `HW_${dateStr}_${title}`;

          if (!groupedHws.has(key)) {
            groupedHws.set(key, {
              id: key, type: 'HW', sourceType: 'TEXTBOOK', title, date: hw.created_at,
              totalQ: 0, tqSet: new Set<number>(), statuses: [], underlyingIds: new Set<string>()
            });
          }

          const g = groupedHws.get(key);
          g.underlyingIds.add(String(hw.homework_id));
          safeParseIds(hw.target_questions).forEach((id: number) => g.tqSet.add(id));
          if (hw.student_homework_result) {
            hw.student_homework_result.forEach((r: any) => g.statuses.push(r.status));
          }
        });

        groupedHws.forEach(g => {
          const isAllDone = g.statuses.length > 0 && g.statuses.every((s: string) => ['제출완료', '채점완료', '완료'].includes(s));
          list.push({ ...g, totalQ: g.tqSet.size, status: isAllDone ? '완료' : '진행중', underlyingIds: Array.from(g.underlyingIds) });
        });
      }

      list.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
      setAssignments(list);
      setSelectedItem(null); 
      setMatrixCols([]);
      setMatrixRows([]);
    } catch (err) {
      console.error("리스트 로딩 실패:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAssignmentsAndLogs();
  }, [selectedClassId]);

  useEffect(() => {
    if (!selectedItem || !selectedClassId || activeTab === 'LOG') return;

    const fetchMatrix = async () => {
      setIsMatrixLoading(true);
      try {
        let cols: MatrixCol[] = [];
        let rowsMap = new Map<string, MatrixRow>();

        const { data: enrolls } = await supabase
          .from('enrollment')
          .select('student_id, student(name, status)')
          .eq('class_id', selectedClassId);

        enrolls?.forEach((e: any) => {
          const s = Array.isArray(e.student) ? e.student[0] : e.student;
          if (s?.status === '재원') {
            rowsMap.set(e.student_id, {
              studentId: e.student_id,
              studentName: s.name,
              cells: {},
              totalCorrect: 0,
              status: '미응시' 
            });
          }
        });

        const uIds = selectedItem.underlyingIds;

        if (selectedItem.sourceType === 'TEXTBOOK') {
          const { data: hwData } = await supabase.from('homework_assignment')
            .select('homework_id, target_student_id, target_questions')
            .in('homework_id', uIds);

          const tqToHwMap = new Map<string, Set<number>>();
          let globalTqs: number[] = [];

          hwData?.forEach(hw => {
            const tqs = safeParseIds(hw.target_questions);
            if (hw.target_student_id) {
               if (!tqToHwMap.has(String(hw.target_student_id))) tqToHwMap.set(String(hw.target_student_id), new Set());
               tqs.forEach(id => tqToHwMap.get(String(hw.target_student_id))!.add(id));
            } else {
               rowsMap.forEach((_, sId) => {
                   if (!tqToHwMap.has(sId)) tqToHwMap.set(sId, new Set());
                   tqs.forEach(id => tqToHwMap.get(sId)!.add(id));
               });
            }
            globalTqs.push(...tqs);
          });

          const unionTqs = Array.from(new Set(globalTqs));
          
          let tqDetails: any[] = [];
          for (let i = 0; i < unionTqs.length; i += 150) {
            const chunk = unionTqs.slice(i, i + 150);
            const { data } = await supabase.from('textbook_question').select('*, question_db(*)').in('tq_id', chunk);
            if (data) tqDetails = [...tqDetails, ...data];
          }

          tqDetails.sort((a, b) => {
            const aPage = a.page_number || a.question_db?.page_number || 0;
            const bPage = b.page_number || b.question_db?.page_number || 0;
            if (aPage !== bPage) return aPage - bPage;
            return String(a.question_number || '').localeCompare(String(b.question_number || ''), undefined, { numeric: true });
          });

          const tqMap = new Map();
          tqDetails.forEach(tq => tqMap.set(String(tq.tq_id), tq));

          cols = tqDetails.map((tq, idx) => {
            const q = tq.question_db || {};
            return {
              qId: String(tq.tq_id),
              displayNum: `${idx + 1}`,
              page: tq.page_number || q.page_number || q.final_printed_page || q.detected_page_num || '',
              number: tq.question_number || q.question_number || '',
              questionText: tq.question || q.question || '',
              imageUrl: q.image_url || tq.image_url || '',
              answer: tq.answer || q.answer || ''
            };
          });

          rowsMap.forEach((row, sId) => {
            cols.forEach(col => {
               const isBlocked = !(tqToHwMap.get(sId)?.has(Number(col.qId)));
               row.cells[col.qId] = { code: 'B', isBlocked };
            });
          });

          const { data: answers } = await supabase.from('student_homework_answer').select('student_id, tq_id, grading_code').in('homework_id', uIds);
          answers?.forEach((a: any) => {
            const row = rowsMap.get(String(a.student_id));
            if (row && row.cells[String(a.tq_id)]) {
               row.cells[String(a.tq_id)].code = a.grading_code;
            }
          });

          const { data: hwResults } = await supabase.from('student_homework_result').select('student_id, status').in('homework_id', uIds);
          hwResults?.forEach((r: any) => {
             const row = rowsMap.get(String(r.student_id));
             if (row) row.status = r.status || '진행중';
          });

        } else {
          const { data: items } = await supabase.from('exam_item').select('exam_id, question_id, sort_order').in('exam_id', uIds);
          const examToQMap = new Map<string, Set<string>>();
          const qSortMap = new Map<string, number>();

          items?.forEach(i => {
             if (!examToQMap.has(i.exam_id)) examToQMap.set(i.exam_id, new Set());
             examToQMap.get(i.exam_id)!.add(String(i.question_id));
             
             const exist = qSortMap.get(String(i.question_id));
             if (!exist || i.sort_order < exist) qSortMap.set(String(i.question_id), i.sort_order);
          });

          const unionQids = Array.from(qSortMap.keys()).sort((a, b) => (qSortMap.get(a) || 0) - (qSortMap.get(b) || 0));

          let qDetails: any[] = [];
          for (let i = 0; i < unionQids.length; i += 150) {
            const chunk = unionQids.slice(i, i + 150);
            const { data } = await supabase.from('question_db').select('*').in('question_id', chunk);
            if (data) qDetails = [...qDetails, ...data];
          }

          const qMap = new Map();
          qDetails.forEach(q => qMap.set(String(q.question_id), q));

          cols = unionQids.map((qid, idx) => {
            const q = qMap.get(qid) || {};
            return {
              qId: qid,
              displayNum: `${idx + 1}`,
              page: q.page_number || q.final_printed_page || q.detected_page_num || '',
              number: q.question_number || '',
              questionText: q.question || '',
              imageUrl: q.image_url || '',
              answer: q.answer || ''
            };
          });

          const { data: assigns } = await supabase.from('exam_assignment').select('assignment_id, student_id, exam_id, status').in('exam_id', uIds).eq('class_id', selectedClassId);
          const stuToExamMap = new Map<string, Set<string>>();
          const assignMap = new Map<string, string>();
          
          assigns?.forEach((a: any) => {
            assignMap.set(a.assignment_id, String(a.student_id));
            if (!stuToExamMap.has(String(a.student_id))) stuToExamMap.set(String(a.student_id), new Set());
            stuToExamMap.get(String(a.student_id))!.add(a.exam_id);
            
            const row = rowsMap.get(String(a.student_id));
            if (row) row.status = a.status || '미응시';
          });

          rowsMap.forEach((row, sId) => {
            cols.forEach(col => {
               const examIds = stuToExamMap.get(sId);
               const isBlocked = !(Array.from(examIds || []).some(eid => examToQMap.get(eid)?.has(col.qId)));
               row.cells[col.qId] = { code: 'B', isBlocked };
            });
          });

          if (assigns && assigns.length > 0) {
            const assignIds = assigns.map((a: any) => a.assignment_id);
            const { data: answers } = await supabase.from('student_answer').select('exam_assignment_id, question_id, grading_code').in('exam_assignment_id', assignIds);

            answers?.forEach((a: any) => {
              const sId = assignMap.get(a.exam_assignment_id);
              if (sId) {
                const row = rowsMap.get(String(sId));
                if (row && row.cells[String(a.question_id)]) {
                   row.cells[String(a.question_id)].code = a.grading_code;
                }
              }
            });
          }
        }

        const rates: Record<string, number> = {};
        cols.forEach(col => {
          let correctCount = 0;
          let attemptCount = 0;
          rowsMap.forEach(row => {
            const cell = row.cells[col.qId];
            if (cell && !cell.isBlocked) {
              const code = cell.code;
              if (code && code !== 'B') {
                attemptCount++;
                if (['O', 'TO', 'RO'].includes(code)) correctCount++;
              }
            }
          });
          rates[col.qId] = attemptCount > 0 ? Math.round((correctCount / attemptCount) * 100) : 0;
        });

        const finalRows = Array.from(rowsMap.values())
          .filter(row => {
             return cols.some(col => row.cells[col.qId] && !row.cells[col.qId].isBlocked);
          })
          .map(row => {
            let cCount = 0;
            cols.forEach(col => { 
               const cell = row.cells[col.qId];
               if (cell && !cell.isBlocked && ['O', 'TO', 'RO'].includes(cell.code)) cCount++; 
            });
            return { ...row, totalCorrect: cCount };
          })
          .sort((a, b) => a.studentName.localeCompare(b.studentName));

        setMatrixCols(cols);
        setMatrixRows(finalRows);
        setQuestionRates(rates);

      } catch (err) {
        console.error("매트릭스 로딩 실패:", err);
      } finally {
        setIsMatrixLoading(false);
      }
    };

    fetchMatrix();
  }, [selectedItem, selectedClassId, activeTab]);

  const filteredAssignments = useMemo(() => {
    if (activeTab === 'ALL' || activeTab === 'LOG') return assignments;
    return assignments.filter(a => a.type === activeTab);
  }, [assignments, activeTab]);

  const getCellUI = (cell: MatrixCell) => {
    if (!cell || cell.isBlocked) {
      return (
        <div className="w-full h-full flex items-center justify-center opacity-30">
          <div className="w-[38px] h-[38px] bg-slate-100 rounded-[10px]" title="배부되지 않은 문항"></div>
        </div>
      );
    }
    
    const code = cell.code;
    let bgClass = "bg-slate-50 border border-slate-100 shadow-sm";
    let textClass = "text-slate-300";
    let displayText = "-";

    if (code) {
      displayText = code;
      if (code === 'O') { bgClass = "bg-emerald-100 border border-emerald-200 shadow-sm"; textClass = "text-emerald-600"; }
      else if (code === 'TO') { bgClass = "bg-teal-100 border border-teal-200 shadow-sm"; textClass = "text-teal-600"; }
      else if (code === 'RO') { bgClass = "bg-blue-100 border border-blue-200 shadow-sm"; textClass = "text-blue-600"; }
      else if (code === 'X') { bgClass = "bg-rose-100 border border-rose-200 shadow-sm"; textClass = "text-rose-500"; }
      else if (code === 'TX') { bgClass = "bg-orange-100 border border-orange-200 shadow-sm"; textClass = "text-orange-500"; }
      else if (code === '☆') { bgClass = "bg-amber-100 border border-amber-200 shadow-sm"; textClass = "text-amber-500"; }
      else if (code === 'B') { bgClass = "bg-slate-100 border border-slate-200 shadow-sm"; textClass = "text-slate-400"; }
    }

    return (
      <div className={`w-[38px] h-[38px] mx-auto rounded-[10px] flex items-center justify-center font-black text-[13px] transition-all ${bgClass} ${textClass}`}>
        {displayText}
      </div>
    );
  };

  const getTypeBadge = (type: ReportTabType) => {
    switch (type) {
      case 'EXAM': return <span className="bg-blue-100 text-blue-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-blue-200">시험</span>;
      case 'HW': return <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-amber-200">과제</span>;
      case 'OVERDUE': return <span className="bg-rose-100 text-rose-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-rose-200">미완료</span>;
      case 'PRINT': return <span className="bg-emerald-100 text-emerald-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-emerald-200">오답</span>;
      case 'SIMILAR': return <span className="bg-violet-100 text-violet-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-violet-200">유사</span>;
      default: return null;
    }
  };

  // 🌟 [추가 포인트] 모달을 열 때 초기 데이터 주입 함수
  const openLessonLogModal = () => {
    setEditingLogData(null);
    setIsLessonLogModalOpen(true);
  };

  const openEditLessonLogModal = (log: any) => {
    setEditingLogData(log);
    setIsLessonLogModalOpen(true);
  };

  const renderLogView = () => {
    if (!selectedLog) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
          <span className="text-5xl mb-4 text-indigo-200">📝</span>
          <p className="font-extrabold text-lg text-slate-500">좌측에서 조회할 수업 일지를 선택해주세요.</p>
        </div>
      );
    }

    const [y, m, d] = selectedLog.actual_date.split('T')[0].split('-');
    const dateObj = new Date(Number(y), Number(m) - 1, Number(d));
    const dayStr = ['일', '월', '화', '수', '목', '금', '토'][dateObj.getDay()];
    const fullDateWithDay = `${y}년 ${m}월 ${d}일 (${dayStr})`;

    return (
      <div className="flex-1 overflow-y-auto custom-scroll p-6 bg-slate-50/50 relative">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200 flex flex-col md:flex-row justify-between md:items-center gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <span className="text-sm font-black bg-indigo-100 text-indigo-600 px-3 py-1 rounded-lg shadow-sm border border-indigo-200 tracking-tight flex items-center gap-1.5">
                  <span className="text-lg">🗓️</span> {fullDateWithDay} 수업
                </span>
              </div>
              <h2 className="text-2xl font-black text-slate-800">수업 일지 기록</h2>
            </div>
            
            {currentUser.isAdmin && (
              <div className="flex gap-2 shrink-0">
                <button 
                  onClick={() => openEditLessonLogModal(selectedLog)}
                  className="px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 font-bold rounded-lg transition-colors border border-indigo-200 text-sm shadow-sm"
                >
                  ✏️ 내용 수정
                </button>
                <button 
                  onClick={(e) => handleDeleteLog(e, selectedLog.lesson_log_id)}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 font-bold rounded-lg transition-colors border border-rose-200 text-sm shadow-sm"
                >
                  🗑️ 삭제
                </button>
              </div>
            )}
          </div>

          <div className="bg-white p-6 md:p-8 rounded-2xl shadow-sm border border-slate-200">
            <h3 className="text-base font-black text-slate-800 border-b border-slate-100 pb-3 mb-5 flex items-center gap-2">
              <span className="text-xl">📚</span> 학부모 안내장 (진도 및 과제 내역)
            </h3>
            {selectedLog.homework_desc ? (
              <div className="text-[15px] font-medium text-slate-800 whitespace-pre-wrap leading-relaxed bg-slate-50/50 p-5 rounded-xl border border-slate-100">
                {selectedLog.homework_desc}
              </div>
            ) : (
              <div className="text-center py-8 opacity-60">
                <span className="text-sm font-bold text-slate-400">작성된 학부모 안내장이 없습니다.</span>
              </div>
            )}

            {selectedLog.lesson_log_student_comment && selectedLog.lesson_log_student_comment.length > 0 && (
              <div className="mt-5 pt-5 border-t border-slate-100">
                <h4 className="text-sm font-black text-slate-700 mb-3 flex items-center gap-1.5">
                  <span className="text-emerald-500">🧑‍🎓</span> 개별 과제 및 코멘트
                </h4>
                <div className="flex flex-col gap-2.5">
                  {selectedLog.lesson_log_student_comment.map((c: any, i: number) => (
                    <div key={i} className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
                      <span className="font-black text-xs text-indigo-700 bg-indigo-100 px-2.5 py-1 rounded border border-indigo-200 shrink-0">
                        {c.student?.name || '학생'}
                      </span>
                      <span className="text-[14px] font-medium text-slate-700 whitespace-pre-wrap leading-snug pt-0.5">
                        {c.comment}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="bg-yellow-50 p-6 md:p-8 rounded-2xl shadow-sm border border-yellow-200">
            <h3 className="text-base font-black text-yellow-800 border-b border-yellow-200/60 pb-3 mb-5 flex items-center gap-2">
              <span className="text-xl">🔒</span> 강사 특이사항 메모 <span className="text-xs font-bold text-yellow-600/70 ml-2 bg-yellow-100 px-2 py-1 rounded">(학부모 미노출)</span>
            </h3>
            {selectedLog.instructor_note ? (
              <p className="text-[15px] font-medium text-slate-700 whitespace-pre-wrap leading-loose">
                {selectedLog.instructor_note}
              </p>
            ) : (
              <div className="text-center py-8 opacity-60">
                <span className="text-sm font-bold text-yellow-700">작성된 특이사항 메모가 없습니다.</span>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  const renderMatrixView = () => {
    if (!selectedItem) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
          <span className="text-5xl mb-4">👈</span>
          <p className="font-extrabold text-lg">좌측에서 분석할 시험지나 과제를 선택해주세요.</p>
        </div>
      );
    }
    
    if (isMatrixLoading) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
          <div className="w-8 h-8 border-4 border-[#002864] border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="font-bold text-sm">학생별 정오답 데이터를 분석 중입니다...</p>
        </div>
      );
    }

    if (matrixCols.length === 0) {
      return (
        <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-slate-50/50">
          <p className="font-bold text-sm">해당 문제지에 문항 데이터가 없습니다.</p>
        </div>
      );
    }

    return (
      <>
        <div className="p-5 border-b border-slate-200 bg-slate-50 flex flex-wrap items-center justify-between shrink-0 gap-4">
          <div>
            <h3 className="text-lg font-black text-slate-800 flex items-center gap-2">
              {getTypeBadge(selectedItem.type)} {selectedItem.title.replace(/^\[시스템\]\s*/, '')}
            </h3>
            <div className="text-xs font-bold text-slate-500 mt-1 flex gap-3">
              <span>📅 출제일: {formatDateLabel(selectedItem.date)}</span>
              <span>📝 전체 합산 총 {matrixCols.length}문항</span>
              <span>👥 배부 인원 {matrixRows.length}명</span>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2.5 bg-white px-3 py-2 rounded-lg border border-slate-200 shadow-sm">
            <div className="flex items-center gap-1"><span className="text-[11px] font-black text-emerald-500">O</span><span className="text-[10px] font-bold text-slate-600">정답</span></div>
            <div className="flex items-center gap-1 ml-1"><span className="text-[11px] font-black text-teal-500">TO</span><span className="text-[10px] font-bold text-slate-600">힌트정답</span></div>
            <div className="flex items-center gap-1 ml-1"><span className="text-[11px] font-black text-blue-500">RO</span><span className="text-[10px] font-bold text-slate-600">재시도정답</span></div>
            <div className="flex items-center gap-1 ml-1 border-l border-slate-200 pl-2"><span className="text-[11px] font-black text-rose-500">X</span><span className="text-[10px] font-bold text-slate-600">오답</span></div>
            <div className="flex items-center gap-1 ml-1"><span className="text-[11px] font-black text-orange-500">TX</span><span className="text-[10px] font-bold text-slate-600">힌트오답</span></div>
            <div className="flex items-center gap-1 ml-1"><span className="text-[11px] font-black text-orange-500">☆</span><span className="text-[10px] font-bold text-slate-600">질문</span></div>
            <div className="flex items-center gap-1 ml-1 border-l border-slate-200 pl-2"><span className="text-[11px] font-black text-slate-400">B</span><span className="text-[10px] font-bold text-slate-600">빈칸</span></div>
          </div>
        </div>

        <div className="flex-1 overflow-auto custom-scroll relative bg-white">
          <table className="w-max border-collapse">
            <thead className="sticky top-0 z-20 shadow-sm">
              <tr>
                <th className="sticky left-0 z-30 bg-[#f8fafc] p-2 min-w-[150px] w-[150px] max-w-[150px] border-r border-b border-slate-200 text-center align-middle shadow-[2px_0_5px_rgba(0,0,0,0.03)] h-[48px]">
                  <span className="text-[13px] font-extrabold text-slate-700">학생명</span>
                </th>
                <th className="bg-[#f8fafc] p-2 min-w-[90px] w-[90px] max-w-[90px] border-r border-b border-slate-200 text-center align-middle shadow-sm h-[48px]">
                  <span className="text-[13px] font-extrabold text-slate-700">정답 수</span>
                </th>
                
                {matrixCols.map(col => (
                  <th key={col.qId} className="bg-[#f8fafc] p-0 min-w-[48px] w-[48px] max-w-[48px] border-r border-b border-slate-200 text-center align-middle h-[48px]">
                    <div className="flex flex-col items-center justify-center gap-0.5">
                      <div className="flex items-center gap-0.5">
                        <span className="text-[13px] font-black text-[#002864] leading-none">{col.displayNum}</span>
                        <button onClick={() => setModalQuestion(col)} className="text-[10px] text-blue-400 hover:text-blue-600 transition-colors leading-none" title="문제 상세 보기">🔍</button>
                      </div>
                      {(col.page || col.number) && (
                        <span className="text-[8px] font-bold text-blue-500 leading-none tracking-tighter truncate w-full px-0.5" title={`${col.page ? `p.${col.page}` : ''}${col.page && col.number ? '-' : ''}${col.number ? `${col.number}번` : ''}`}>
                          {col.page ? `p${col.page}` : ''}{col.page && col.number ? '-' : ''}{col.number}
                        </span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {matrixRows.map((row, idx) => {
                const isCompleted = ['완료', '채점완료', '제출완료'].includes(row.status);
                let assignedCount = 0;
                matrixCols.forEach(col => { if (row.cells[col.qId] && !row.cells[col.qId].isBlocked) assignedCount++; });

                return (
                  <tr key={row.studentId} className={`hover:bg-slate-50/60 transition-colors border-b border-slate-100`}>
                    
                    <td className="sticky left-0 z-10 bg-white p-0 border-r border-slate-200 shadow-[2px_0_5px_rgba(0,0,0,0.02)] align-middle text-center min-w-[150px] w-[150px] max-w-[150px] h-[48px]">
                      <div className="flex flex-col items-center justify-center w-full h-full gap-0.5">
                        <span 
                          onClick={() => router.push(`/student/${row.studentId}`)}
                          className="truncate w-full text-center cursor-pointer font-extrabold text-[13px] text-slate-800 hover:underline hover:text-blue-600 transition-colors leading-tight"
                          title="학생 상세 기록 보기"
                        >
                          {row.studentName}
                        </span>
                        <span className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full leading-none ${isCompleted ? 'text-slate-400 bg-slate-100 border border-slate-200/50' : 'text-rose-500 bg-rose-50 border border-rose-100/50'}`}>
                          {row.status || '미제출'}
                        </span>
                      </div>
                    </td>
                    
                    <td className="p-0 border-r border-slate-200 text-center align-middle min-w-[90px] w-[90px] max-w-[90px] h-[48px]">
                      <div className="bg-blue-50/50 text-[#002864] font-black text-[12px] px-1.5 py-1 rounded-lg border border-blue-100 shadow-sm inline-flex items-center justify-center gap-1 w-full max-w-[64px]">
                        <span>{row.totalCorrect}</span>
                        <span className="text-blue-200 text-[9px] font-bold">/</span>
                        <span className="text-slate-500 font-bold">{assignedCount}</span>
                      </div>
                    </td>

                    {matrixCols.map(col => (
                      <td key={col.qId} className={`p-0 border-r border-slate-200 text-center align-middle min-w-[48px] w-[48px] max-w-[48px] h-[48px]`}>
                        {getCellUI(row.cells[col.qId])}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
            <tfoot className="sticky bottom-0 z-20 shadow-[0_-2px_5px_rgba(0,0,0,0.05)]">
              <tr>
                <th colSpan={2} className="sticky left-0 z-30 bg-[#f8fafc] p-1 border-r border-t border-slate-200 text-center align-middle shadow-[2px_0_5px_rgba(0,0,0,0.03)] h-[36px]">
                  <span className="text-[11px] font-extrabold text-slate-700">문항별 정답률</span>
                </th>
                {matrixCols.map(col => {
                  const rate = questionRates[col.qId] || 0;
                  let rateColor = "text-slate-700";
                  if (rate < 50 && rate > 0) rateColor = "text-rose-500"; 
                  else if (rate >= 80) rateColor = "text-emerald-600"; 

                  return (
                    <th key={col.qId} className="bg-[#f8fafc] p-1 border-r border-t border-slate-200 text-center align-middle min-w-[48px] w-[48px] max-w-[48px] h-[36px]">
                      <span className={`text-[11px] font-black ${rateColor}`}>{rate}%</span>
                    </th>
                  );
                })}
              </tr>
            </tfoot>
          </table>
        </div>
      </>
    );
  };

  const [classStudents, setClassStudents] = useState<any[]>([]);
  useEffect(() => {
    if (selectedClassId) {
      supabase.from("enrollment").select("student(student_id, name)").eq("class_id", selectedClassId)
        .then(({ data }) => {
          if (data) {
             const stds = data.map((d: any) => Array.isArray(d.student) ? d.student[0] : d.student).filter(Boolean);
             setClassStudents(stds.sort((a,b) => a.name.localeCompare(b.name)));
          }
        });
    }
  }, [selectedClassId]);

  return (
    <div className="flex flex-col h-full bg-slate-50 p-4 sm:p-8 gap-4 overflow-hidden relative font-pretendard">
      
      <div className="flex flex-col gap-4 shrink-0">
        <div>
          <h2 className="text-2xl font-black text-[#002864] tracking-tight flex items-center gap-2">
            <span>📊</span> 반별 문항 분석 및 학습 결과
          </h2>
          <p className="text-sm font-bold text-slate-500 mt-1.5">
            반 전체 학생의 정오답 분석 결과와 수업 일지(진도/과제 이력)를 확인합니다.
          </p>
        </div>

        <div 
          ref={classListRef}
          onMouseDown={handleMouseDown}
          className={`flex gap-2.5 overflow-x-auto pb-2 pt-1 min-h-[70px] select-none [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none] ${isDragging ? 'cursor-grabbing' : 'cursor-grab'}`}
        >
          {classes.length === 0 ? <span className="text-sm font-bold text-slate-400 py-2">배정된 반이 없습니다.</span> :
            classes.map((c) => {
              const instName = Array.isArray(c.instructor) ? c.instructor[0]?.name : c.instructor?.name;
              const displayInstructor = instName ? `${instName} 선생님` : '담당 미정';
              const isActive = selectedClassId === c.class_id;
              return (
                <button 
                  key={c.class_id} 
                  data-class-id={c.class_id}
                  onClick={(e) => handleClassClick(e, c.class_id)}
                  className={`px-4 py-2 rounded-xl border-2 shadow-sm flex flex-col items-start transition-all text-left min-w-[120px] max-w-[160px] shrink-0 ${isActive ? "bg-[#002864] text-white border-[#002864] transform scale-[1.02]" : "bg-white text-slate-500 border-transparent hover:border-slate-300 hover:text-slate-700"}`}
                >
                  <span className="text-sm font-extrabold tracking-tight leading-tight truncate w-full">{c.name}</span>
                  <span className="text-[10px] mt-0.5 font-medium opacity-80 leading-none tracking-tight whitespace-nowrap truncate w-full">👤 {displayInstructor}</span>
                </button>
              );
            })
          }
        </div>
      </div>

      <div className="flex flex-1 gap-4 overflow-hidden">
        
        <div className="w-[320px] 2xl:w-[350px] flex flex-col bg-white border border-slate-200 rounded-2xl shadow-sm shrink-0 overflow-hidden">
          
          <div className="p-3 border-b border-slate-200 bg-slate-50 flex items-stretch gap-2 shrink-0">
            <button 
              onClick={() => setActiveTab('LOG')} 
              className={`relative flex-1 min-w-[80px] flex flex-col items-center justify-center rounded-xl transition-all border p-2 gap-1 group overflow-visible
                ${activeTab === 'LOG' 
                  ? 'bg-indigo-600 text-white border-indigo-700 shadow-inner' 
                  : 'bg-indigo-50 border-indigo-300 text-indigo-700 shadow-sm hover:bg-indigo-100 hover:border-indigo-400 hover:-translate-y-0.5'}`
              }
            >
              {activeTab !== 'LOG' && (
                <span className="absolute -top-1 -right-1 flex h-3 w-3">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-rose-500 border border-white"></span>
                </span>
              )}
              <span className="text-2xl leading-none transition-transform group-hover:scale-110">📝</span>
              <span className="text-xs font-black">수업 일지</span>
            </button>
            
            <div className="flex-[2] grid grid-cols-3 gap-1.5">
              <button onClick={() => setActiveTab('ALL')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'ALL' ? 'bg-slate-700 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>전체 분석</button>
              <button onClick={() => setActiveTab('EXAM')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'EXAM' ? 'bg-blue-600 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>💯 시험</button>
              <button onClick={() => setActiveTab('HW')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'HW' ? 'bg-amber-500 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>📝 과제</button>
              
              <button onClick={() => setActiveTab('OVERDUE')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'OVERDUE' ? 'bg-rose-500 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>⏰ 미완료</button>
              <button onClick={() => setActiveTab('PRINT')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'PRINT' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>❌ 오답</button>
              <button onClick={() => setActiveTab('SIMILAR')} className={`py-1.5 rounded-lg text-[10px] font-black transition-colors ${activeTab === 'SIMILAR' ? 'bg-violet-500 text-white shadow-sm' : 'bg-white text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>🔄 유사</button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto custom-scroll p-2 space-y-1.5 bg-slate-50/50">
            {activeTab === 'LOG' && (
              <button 
                onClick={openLessonLogModal}
                className="w-full bg-gradient-to-r from-indigo-500 to-indigo-600 text-white font-bold text-xs py-2.5 rounded-xl shadow-md hover:from-indigo-400 hover:to-indigo-500 transition-colors mb-2 flex items-center justify-center gap-1.5 group"
              >
                <span className="group-hover:scale-110 transition-transform">➕</span> 오늘 수업 일지 새로 작성하기
              </button>
            )}

            {isLoading ? (
              <div className="py-10 text-center text-sm font-bold text-slate-400">목록을 불러오는 중...</div>
            ) : activeTab === 'LOG' ? (
              lessonLogs.length === 0 ? (
                <div className="py-10 text-center text-sm font-bold text-slate-400">작성된 수업 일지가 없습니다.</div>
              ) : (
                lessonLogs.map((log) => {
                  const [y, m, d] = log.actual_date.split('T')[0].split('-');
                  const dateObj = new Date(Number(y), Number(m) - 1, Number(d));
                  const dayStr = ['일', '월', '화', '수', '목', '금', '토'][dateObj.getDay()];
                  const shortDateStr = `${Number(m)}.${Number(d)}(${dayStr})`;

                  return (
                    <div 
                      key={log.lesson_log_id} 
                      onClick={() => setSelectedLog(log)}
                      className={`p-3 rounded-xl border cursor-pointer transition-all ${selectedLog?.lesson_log_id === log.lesson_log_id ? 'bg-indigo-50 border-indigo-300 shadow-md transform scale-[1.02] ml-1' : 'bg-white border-slate-200 hover:border-slate-400 hover:bg-slate-50 shadow-sm'}`}
                    >
                      <div className="flex items-center gap-2 mb-1.5 justify-between">
                        <div className="flex items-center gap-2 min-w-0">
                          <span className="bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded text-[10px] font-black shrink-0 border border-indigo-200">일지</span>
                          <span className={`text-[10px] font-bold truncate ${selectedLog?.lesson_log_id === log.lesson_log_id ? 'text-indigo-400' : 'text-slate-400'}`}>
                            {formatDateLabel(log.created_at)} 작성
                          </span>
                        </div>
                        
                        {currentUser.isAdmin && (
                          <button 
                            onClick={(e) => handleDeleteLog(e, log.lesson_log_id)}
                            className="text-slate-300 hover:text-rose-500 transition-colors p-1 rounded-md hover:bg-rose-50"
                            title="이 일지 삭제하기"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                          </button>
                        )}
                      </div>
                      
                      <div className="flex justify-between items-center mt-0.5">
                        <div className={`font-extrabold text-[13px] leading-snug line-clamp-1 ${selectedLog?.lesson_log_id === log.lesson_log_id ? 'text-indigo-900' : 'text-slate-800'}`}>
                          수업 일지 기록
                        </div>
                        <div className={`text-[11px] font-black shrink-0 px-2 py-0.5 rounded border ${selectedLog?.lesson_log_id === log.lesson_log_id ? 'bg-indigo-100 text-indigo-700 border-indigo-200' : 'bg-slate-100 text-slate-500 border-slate-200'}`}>
                          {shortDateStr} 수업
                        </div>
                      </div>
                    </div>
                  );
                })
              )
            ) : filteredAssignments.length === 0 ? (
              <div className="py-10 text-center text-sm font-bold text-slate-400">출제된 항목이 없습니다.</div>
            ) : (
              filteredAssignments.map((item) => (
                <div 
                  key={item.id} 
                  onClick={() => setSelectedItem(item)}
                  className={`p-3 rounded-xl border cursor-pointer transition-all ${selectedItem?.id === item.id ? 'bg-[#002864] border-[#002864] shadow-md transform scale-[1.02] ml-1' : 'bg-white border-slate-200 hover:border-slate-400 hover:bg-slate-50 shadow-sm'}`}
                >
                  <div className="flex items-center gap-2 mb-1.5 justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      {getTypeBadge(item.type)}
                      <span className={`text-[10px] font-bold truncate ${selectedItem?.id === item.id ? 'text-blue-200' : 'text-slate-400'}`}>{formatDateLabel(item.date)}</span>
                    </div>
                    <span className={`text-[9px] font-black px-1.5 py-0.5 rounded shrink-0 ${item.status === '완료' ? 'bg-slate-100 text-slate-400' : 'bg-rose-500 text-white shadow-sm'}`}>
                      {item.status}
                    </span>
                  </div>
                  <div className={`font-extrabold text-[13px] leading-snug line-clamp-2 ${selectedItem?.id === item.id ? 'text-white' : 'text-slate-800'}`}>
                    {item.title.replace(/^\[시스템\]\s*/, '')}
                  </div>
                  <div className={`mt-2 text-[11px] font-bold ${selectedItem?.id === item.id ? 'text-blue-200' : 'text-slate-500'}`}>
                    배부된 전체 문항수: {item.totalQ}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* 우측 패널 */}
        <div className="flex-1 bg-white border border-slate-200 rounded-2xl shadow-sm flex flex-col overflow-hidden relative">
          {activeTab === 'LOG' ? renderLogView() : renderMatrixView()}
        </div>
      </div>

      {/* 문항 상세 보기 모달 */}
      {modalQuestion && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-[fadeIn_0.2s_ease-out]">
          <div className="bg-white w-full max-w-3xl max-h-[90vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden">
            <div className="bg-[#002864] p-4 text-white flex justify-between items-center shrink-0">
              <h2 className="font-bold text-lg flex items-center gap-2">
                <span>🔍</span> {modalQuestion.displayNum}번 문항 상세 
                {(modalQuestion.page || modalQuestion.number) && <span className="text-sm font-medium text-blue-200 ml-2">({modalQuestion.page ? `p.${modalQuestion.page} ` : ''}{modalQuestion.number ? `${modalQuestion.number}번` : ''})</span>}
              </h2>
              <button onClick={() => setModalQuestion(null)} className="text-white hover:text-rose-400 font-bold text-2xl leading-none">&times;</button>
            </div>
            <div className="p-6 overflow-y-auto custom-scroll flex-1 bg-slate-50 space-y-6">
              <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
                <h3 className="font-extrabold text-slate-800 border-b border-slate-100 pb-2 mb-3">질문 (Question)</h3>
                <div className="math-text text-slate-700 font-medium whitespace-pre-wrap leading-relaxed" dangerouslySetInnerHTML={{ __html: formatMathTextForWeb(modalQuestion.questionText || '-').replace(/\n/g, '<br>') }} />
                {getCleanUrl(modalQuestion.imageUrl) && <img src={getCleanUrl(modalQuestion.imageUrl)} className="max-w-full mt-4 rounded-lg border border-slate-200" alt="Question" />}
              </div>
              <div className="bg-blue-50 p-5 rounded-xl border border-blue-100 shadow-sm">
                <h3 className="font-extrabold text-blue-800 border-b border-blue-200 pb-2 mb-3">정답 (Answer)</h3>
                <div className="math-text text-blue-700 font-bold text-lg whitespace-pre-wrap" dangerouslySetInnerHTML={{ __html: `$ ${formatMathTextForWeb(modalQuestion.answer || '-')} $` }} />
              </div>
            </div>
            <div className="p-4 bg-white border-t border-slate-200 flex justify-end shrink-0">
              <button onClick={() => setModalQuestion(null)} className="px-6 py-2 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-lg shadow-sm">닫기</button>
            </div>
          </div>
        </div>
      )}

      {/* 🌟 분리된 모달 컴포넌트 렌더링 */}
      <LessonLogModal 
        isOpen={isLessonLogModalOpen} 
        onClose={() => setIsLessonLogModalOpen(false)} 
        onSuccess={fetchAssignmentsAndLogs} 
        classId={selectedClassId} 
        students={classStudents} 
        initialData={editingLogData} 
      />

    </div>
  );
}