// src/app/(dashboard)/permission/page.tsx
"use client";

import React, { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

const PERMISSION_GROUPS = [
  {
    category: "1. 학원 관리",
    desc: "홈 대시보드 및 학생/반 기본 관리 권한입니다.",
    items: [
      { id: "/home", label: "홈 메뉴 접근 (기본 제공)", isRequired: true },
      { id: "action_edit_home_attend", label: "↳ [권한] 홈 화면 출결 수동 설정 및 기록 삭제", isAction: true },
      { id: "/student", label: "학생 관리 (기본 정보/리포트)" },
      { id: "action_delete_student", label: "↳ [권한] 학생 데이터 영구 삭제", isAction: true },
      { id: "/class", label: "반 관리 (수강생/일정 배정)" },
      { id: "action_view_all_classes", label: "↳ [권한] 전체 수강반 열람 (미체크 시 본인 반만 노출)", isAction: true },
      { id: "action_delete_class", label: "↳ [권한] 반(클래스) 삭제", isAction: true },
    ]
  },
  {
    category: "2. 수업 관리",
    desc: "교재, 진도, 학습지, 결과 리포트 및 보강 일정 관리입니다.",
    items: [
      { id: "/lesson", label: "교재 관리 (마스터 교재/진도 배정)" },
      { id: "action_delete_book", label: "↳ [권한] 마스터 교재 삭제", isAction: true },
      { id: "/progress", label: "진도 관리 (교재 진도 체크)" },
      { id: "/learning", label: "학습 관리 (시험/과제/오답 현황)" },
      { id: "action_delete_learning_exam", label: "↳ [권한] 타임라인 학습지(시험/과제) 강제 삭제", isAction: true },
      { id: "/class-report", label: "학습 결과 (학생별 성취도 리포트)" }, 
      { id: "/makeup", label: "보강 관리 (1:1 개별 보강)" },
      { id: "action_edit_makeup", label: "↳ [권한] 개별 보강 일정 수정", isAction: true },
      { id: "action_delete_makeup", label: "↳ [권한] 개별 보강 일정 삭제", isAction: true },
    ]
  },
  {
    category: "3. 소통 및 업무 관리",
    desc: "AI 회의록, 업무 공유, 학부모 상담 등 소통 권한입니다.",
    items: [
      { id: "/minutes", label: "AI 회의록 (회의 안건/일정)" },
      { id: "action_create_voice_minutes", label: "↳ [권한] AI 실시간 음성 회의록 작성", isAction: true },
      { id: "action_create_manual_agenda", label: "↳ [권한] 새 안건 수동 작성", isAction: true },
      { id: "action_bind_meeting", label: "↳ [권한] 안건 병합하여 회의록 생성", isAction: true },
      { id: "action_edit_agenda_status", label: "↳ [권한] 안건 상태(대기/진행/완료) 변경", isAction: true },
      { id: "action_delete_own_agenda", label: "↳ [권한] 본인이 작성한 안건 삭제", isAction: true },
      { id: "action_delete_minutes", label: "↳ [권한] AI 회의록 전체 삭제 (관리자급)", isAction: true }, 
      
      { id: "/task", label: "업무 공유 보드 (공지/인계 사항)" },
      { id: "action_delete_task", label: "↳ [권한] 업무/공지 기록 삭제", isAction: true },
      { id: "action_delete_task_comment", label: "↳ [권한] 타인의 소통 노트(댓글) 삭제", isAction: true },
      { id: "action_submit_task_agenda", label: "↳ [권한] 회의 안건 상정", isAction: true },
      
      { id: "/supply", label: "비품 신청" },
      { id: "action_delete_supply", label: "↳ [권한] 비품 신청서 삭제", isAction: true },
      { id: "action_delete_supply_comment", label: "↳ [권한] 타인의 소통 노트(댓글) 삭제", isAction: true },
      { id: "action_submit_supply_agenda", label: "↳ [권한] 회의 안건 상정", isAction: true },

      { id: "/cs", label: "학부모 요청 및 CS 관리" },
      { id: "action_view_all_cs", label: "↳ [권한] 타인의 CS 요청 내역 전체 열람", isAction: true },
      { id: "action_delete_cs", label: "↳ [권한] 학부모 요청(CS) 기록 삭제", isAction: true },
      { id: "action_delete_cs_comment", label: "↳ [권한] 타인의 소통 노트(댓글) 삭제", isAction: true },
      { id: "action_submit_cs_agenda", label: "↳ [권한] 회의 안건 상정", isAction: true },
      
      { id: "/consultation", label: "정기 상담 관리 (대상자 확인 및 일지)" },
    ]
  },
  {
    category: "4. 출제 및 배포",
    items: [
      { id: "/exam-list", label: "문제지 보관함 (출제 및 채점)" },
      { id: "action_delete_exam", label: "↳ [권한] 출제된 문제지 삭제", isAction: true },
      { id: "action_generate_twins_exam", label: "↳ [권한] 문제 편집 시 AI 쌍둥이/유사 생성 및 교체", isAction: true },
      { id: "/admission", label: "진단평가 및 대기생 관리" },
      { id: "action_create_admission", label: "↳ [권한] 진단평가 새 일정 만들기", isAction: true },
      { id: "action_bulk_admission", label: "↳ [권한] 진단평가 일괄 관리 (상태/삭제)", isAction: true },
      { id: "action_manage_admission_report", label: "↳ [권한] 진단 리포트 생성 및 열람", isAction: true },
    ]
  },
  {
    category: "5. 데스크 전용 (수납 및 운영)",
    desc: "매출 통계 및 수납/행정 지표 권한입니다.",
    items: [
      { id: "/admin-dashboard", label: "운영 대시보드 (KPI/통계)" },
      { id: "/billing", label: "수납 및 청구서 발행" },
      { id: "/unpaid", label: "미납자 특별 관리" },
      { id: "/shop-admin", label: "포인트 상점 관리" },
      { id: "/print-center", label: "교육청 서류 출력 센터" }, 
    ]
  },
  {
    category: "6. 조교(TA) 전용",
    items: [
      { id: "/ta-tools", label: "조교 전용 페이지(클리닉 패드 등) 접근" },
    ]
  },
  {
    category: "7. LOGICA Factory (저작 도구)",
    desc: "문제은행 파싱, 교정, 매핑 등 팩토리 도구 권한입니다.",
    items: [
      { id: "/factory-dashboard", label: "DB 통계 대시보드" },
      { id: "/pdf-parser", label: "PDF 문항 추출기 (페이지 전체 접근)" },
      { id: "/taxonomy-editor", label: "문제 교정 및 쌍둥이/유사 생성" },
      { id: "action_add_question", label: "↳ [권한] 새 문항 추가", isAction: true },
      { id: "action_delete_question", label: "↳ [권한] 문항 완전 삭제", isAction: true },
      { id: "action_edit_question", label: "↳ [권한] 문항 & 해설 & 이미지 수정", isAction: true },
      { id: "action_generate_twins", label: "↳ [권한] 팩토리 전용 쌍둥이/유사 문제 생성", isAction: true },
      
      { id: "/twin-manager", label: "쌍둥이 문제 팩토리 (수동 배정)" },
      { id: "action_twin_generate", label: "↳ [권한] AI 쌍둥이/유사 자동 생성", isAction: true },
      { id: "action_twin_edit", label: "↳ [권한] 개별 문항 상세 편집", isAction: true },
      { id: "action_twin_delete", label: "↳ [권한] 문항 영구 삭제 (위험)", isAction: true },

      { id: "/mapper", label: "교재 수동 연결 도구" },
      { id: "/book-upload", label: "교재 구조 (textbook) 일괄 업로드" },
      { id: "/qdb-upload", label: "문제 DB (question_db) 수동 업로드" },
    ]
  },
  {
    category: "8. 원장·최고관리자 전용",
    desc: "기본적으로 원장급 이상만 쓰지만 예외 권한 부여가 가능합니다.",
    items: [
      { id: "/seat-layout-editor", label: "클리닉 좌석 배치 에디터" },
      { id: "/clinic-pad-registry", label: "키오스크 패드 등록" },
      { id: "/permission", label: "지점 권한 관리" },
      { id: "/instructor", label: "강사 관리" },
      { id: "/academy-info", label: "학원(지점) 기본 정보 설정" },
    ]
  },
  {
    category: "기타 세부 액션: 학생 상세 정보(탭)",
    items: [
      { id: "action_view_consult", label: "↳ [권한] 학생 상담 기록 열람", isAction: true },
      { id: "action_view_exam", label: "↳ [권한] 학생 시험 성적 열람", isAction: true },
      { id: "action_view_clinic", label: "↳ [권한] 학생 클리닉 분석 열람", isAction: true },
      { id: "action_edit_attend", label: "↳ [권한] 학생 출결 기록 수정", isAction: true },
    ]
  },
  {
    category: "기타 세부 액션: 플로팅 편의 기능",
    items: [
      { id: "action_use_chat", label: "↳ [권한] 메신저 (사내/학부모) 이용", isAction: true },
      { id: "action_use_memo", label: "↳ [권한] 퀵 메모 (포스트잇) 이용", isAction: true },
    ]
  }
];

const ROLES = [
  { id: "ADMIN", name: "원장", desc: "지점 내 최고 권한 (SUPER_ADMIN 제외)" },
  { id: "VICE_ADMIN", name: "부원장", desc: "원장에 준하는 총괄 관리 권한" },
  { id: "MANAGER", name: "실장", desc: "수납/상담 및 데스크 전반 관리" },
  { id: "TEACHER", name: "전임강사", desc: "클래스, 학생, 출제, 학습 관리" },
  { id: "PART_TEACHER", name: "파트강사", desc: "제한된 반 및 학생 관리" },
  { id: "TA", name: "조교", desc: "보조 채점, 클리닉 출결 지원" },
  { id: "GUEST", name: "체험/테스트", desc: "모든 메뉴 열람 전용 (조작 차단됨)" },
];

export default function PermissionPage() {
  const router = useRouter();
  
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);

  const [tenantId, setTenantId] = useState("");
  const [activeRole, setActiveRole] = useState(ROLES[0]);
  const [rolePermissions, setRolePermissions] = useState<Record<string, string[]>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // 🌟 핸들 5개 상태 (Pre-Course부터 Ultimate까지 조절)
  const [thresholdBounds, setThresholdBounds] = useState<number[]>([20, 40, 60, 80, 95]);
  const [isSavingThreshold, setIsSavingThreshold] = useState(false);
  const thresholdTrackRef = useRef<HTMLDivElement>(null);
  const draggingThresholdRef = useRef<number | null>(null);

  // 🌟 [추가됨] 마스터 채점 기준표 상태
  const [isGradingModalOpen, setIsGradingModalOpen] = useState(false);
  const [gradingCodes, setGradingCodes] = useState<any[]>([]);
  const [isSavingGrading, setIsSavingGrading] = useState(false);

  // 기차처럼 밀어내는(Push) 방식의 슬라이더 로직
  useEffect(() => {
    const handleMove = (e: MouseEvent | TouchEvent) => {
      if (draggingThresholdRef.current === null || !thresholdTrackRef.current) return;

      const rect = thresholdTrackRef.current.getBoundingClientRect();
      const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
      let pct = Math.round(((clientX - rect.left) / rect.width) * 100);
      
      pct = Math.max(0, Math.min(100, pct));
      const idx = draggingThresholdRef.current;
      
      setThresholdBounds((prev: number[]) => {
        const next = [...prev];
        next[idx] = pct;
        
        for (let i = idx - 1; i >= 0; i--) {
          if (next[i] > next[i + 1]) next[i] = next[i + 1];
        }
        for (let i = idx + 1; i <= 4; i++) {
          if (next[i] < next[i - 1]) next[i] = next[i - 1];
        }
        
        return next;
      });
    };

    const handleUp = () => { draggingThresholdRef.current = null; };

    document.addEventListener("mousemove", handleMove);
    document.addEventListener("touchmove", handleMove, { passive: true });
    document.addEventListener("mouseup", handleUp);
    document.addEventListener("touchend", handleUp);

    return () => {
      document.removeEventListener("mousemove", handleMove);
      document.removeEventListener("touchmove", handleMove);
      document.removeEventListener("mouseup", handleUp);
      document.removeEventListener("touchend", handleUp);
    };
  }, []);

  useEffect(() => {
    const role = localStorage.getItem("logica_instructor_role") || "";
    const pos = localStorage.getItem("logica_instructor_position") || "";
    const tId = localStorage.getItem("logica_tenant_id");

    const adminFlag = ["SUPER_ADMIN", "ADMIN", "GUEST"].includes(role.toUpperCase()) || 
                      ["최고관리자", "대장", "원장"].some(p => pos.includes(p));

    if (!tId) {
      alert("지점 정보가 없습니다.");
      router.replace("/home");
      return;
    }
                      
    if (!adminFlag) {
      alert("⛔ 권한 관리 페이지에 접근할 권한이 없습니다. (원장 및 최고관리자 전용)");
      router.replace("/home");
      return;
    }
    
    setIsAuthorized(true);
    setTenantId(tId);
    loadPermissions(tId);
    loadThresholds(tId);
  }, [router]);

  const loadPermissions = async (tId: string) => {
    setIsLoading(true);
    const { data, error } = await supabase
      .from('tenant_role_permissions')
      .select('role_name, allowed_menus')
      .eq('tenant_id', tId);

    if (!error && data) {
      const perms: Record<string, string[]> = {};
      data.forEach(row => {
        perms[row.role_name] = row.allowed_menus;
      });
      ROLES.forEach(r => {
        if (!perms[r.id]) perms[r.id] = ["/home"];
      });
      setRolePermissions(perms);
    }
    setIsLoading(false);
  };

  const loadThresholds = async (tId: string) => {
    const { data, error } = await supabase
      .from('class_thresholds')
      .select('horizon, titan, apex, master, ultimate') 
      .eq('tenant_id', tId)
      .maybeSingle();

    if (!error && data) {
      const h = data.horizon ?? 20;
      const t = Math.max(h, data.titan ?? 40);
      const a = Math.max(t, data.apex ?? 60);
      const m = Math.max(a, data.master ?? 80);
      const u = Math.max(m, data.ultimate ?? 95);
      
      setThresholdBounds([h, t, a, m, u]);
    }
  };

  // 🌟 [추가됨] 마스터 채점 코드 로드 함수
  const loadGradingCodes = async () => {
    const { data, error } = await supabase
      .from('master_grading_code')
      .select('*')
      .order('code');
      
    if (!error && data) {
      setGradingCodes(data);
      setIsGradingModalOpen(true);
    } else {
      alert("데이터베이스에서 채점 기준을 불러오지 못했습니다.");
    }
  };

  const currentPermissions = rolePermissions[activeRole.id] || ["/home"];

  const togglePermission = (menuId: string, isDisabled?: boolean) => {
    if (isDisabled) return;
    
    setRolePermissions(prev => {
      const current = prev[activeRole.id] || [];
      const updated = current.includes(menuId) 
        ? current.filter(id => id !== menuId) 
        : [...current, menuId];
      
      return { ...prev, [activeRole.id]: updated };
    });
  };

  const toggleGroupAll = (groupItems: any[]) => {
    const toggleableItems = groupItems.filter(i => !i.isRequired);
    if (toggleableItems.length === 0) return;

    setRolePermissions(prev => {
      const current = prev[activeRole.id] || [];
      const itemIds = toggleableItems.map(item => item.id);
      const isAllChecked = itemIds.every(id => current.includes(id));
      let updated = [...current];

      if (isAllChecked) {
        updated = updated.filter(id => !itemIds.includes(id));
      } else {
        itemIds.forEach(id => {
          if (!updated.includes(id)) updated.push(id);
        });
      }

      return { ...prev, [activeRole.id]: updated };
    });
  };

  const handleSave = async () => {
    if (!tenantId) return;
    setIsSaving(true);
    
    try {
      const finalPermissions = Array.from(new Set([...currentPermissions, "/home"]));
      const { error } = await supabase
        .from('tenant_role_permissions')
        .upsert({
          tenant_id: tenantId,
          role_name: activeRole.id,
          allowed_menus: finalPermissions,
          updated_at: new Date().toISOString()
        }, { onConflict: 'tenant_id, role_name' });

      if (error) throw error;
      alert(`✅ [${activeRole.name}]의 메뉴 접근 권한이 성공적으로 업데이트되었습니다!`);
    } catch (e: any) {
      alert("권한 저장 중 오류가 발생했습니다: " + e.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveThresholds = async () => {
    if (!tenantId) return;
    setIsSavingThreshold(true);
    
    try {
      const { data: existing } = await supabase
        .from('class_thresholds')
        .select('tenant_id')
        .eq('tenant_id', tenantId)
        .maybeSingle();

      let opError = null;

      if (existing) {
        const { error } = await supabase
          .from('class_thresholds')
          .update({
            horizon: thresholdBounds[0],
            titan: thresholdBounds[1],
            apex: thresholdBounds[2],
            master: thresholdBounds[3],
            ultimate: thresholdBounds[4], 
            updated_at: new Date().toISOString()
          })
          .eq('tenant_id', tenantId);
        opError = error;
      } else {
        const { error } = await supabase
          .from('class_thresholds')
          .insert({
            tenant_id: tenantId,
            horizon: thresholdBounds[0],
            titan: thresholdBounds[1],
            apex: thresholdBounds[2],
            master: thresholdBounds[3],
            ultimate: thresholdBounds[4]
          });
        opError = error;
      }

      if (opError) throw opError;
      alert("✅ 클래스 반 배정 기준값이 성공적으로 저장되었습니다!");
    } catch (e: any) {
      alert("기준값 저장 중 오류가 발생했습니다: " + e.message);
    } finally {
      setIsSavingThreshold(false);
    }
  };

  // 🌟 [추가됨] 마스터 채점 코드 저장 함수
  const handleSaveGradingCodes = async () => {
    setIsSavingGrading(true);
    try {
      // 배열 형태로 upsert (기본키인 code를 기준으로 업데이트 수행)
      const { error } = await supabase
        .from('master_grading_code')
        .upsert(gradingCodes);
        
      if (error) throw error;
      alert("✅ 학원 전체 마스터 채점 기준(가중치)이 성공적으로 반영되었습니다!");
      setIsGradingModalOpen(false);
    } catch (e: any) {
      alert("채점 기준 저장 중 오류가 발생했습니다: " + e.message);
    } finally {
      setIsSavingGrading(false);
    }
  };

  if (isAuthorized === null) return <div className="p-10 text-center font-bold text-slate-400">보안 권한 확인 중...</div>;
  if (isAuthorized === false) return null; 
  if (isLoading) return <div className="p-8 font-bold text-slate-500">권한 정보를 불러오는 중입니다...</div>;

  return (
    <div className="h-full flex flex-col font-pretendard bg-slate-50 p-4 sm:p-8 overflow-hidden">
      <div className="shrink-0 flex items-end justify-between mb-6">
        <div>
          <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
            🔐 지점 권한 관리
          </h1>
          <p className="text-slate-500 font-bold text-[12px] mt-1">
            우리 학원의 직급별로 접근 가능한 메뉴와 세부 권한을 제어합니다.
          </p>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row gap-6 overflow-hidden min-h-0">
        
        {/* === 좌측 패널 === */}
        <div className="w-full lg:w-72 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col shrink-0 overflow-hidden h-full">
          <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center shrink-0">
            <span className="font-black text-sm text-slate-700">관리 대상 직급</span>
          </div>
          
          <div className="flex-1 overflow-y-auto custom-scroll p-2">
            {ROLES.map(role => (
              <button 
                key={role.id}
                onClick={() => setActiveRole(role)}
                className={`w-full text-left p-3 mb-1 rounded-xl transition-colors border flex flex-col gap-1 ${activeRole.id === role.id ? 'bg-indigo-50 border-indigo-200 shadow-sm' : 'bg-transparent border-transparent hover:bg-slate-50'}`}
              >
                <div className="flex justify-between items-center">
                  <span className={`font-bold text-[13px] ${activeRole.id === role.id ? 'text-indigo-800' : 'text-slate-700'}`}>{role.name}</span>
                  <span className="text-[9px] font-black text-slate-400 border border-slate-200 bg-white px-1.5 py-0.5 rounded">{role.id}</span>
                </div>
                <div className={`text-[10px] truncate ${activeRole.id === role.id ? 'text-indigo-500' : 'text-slate-400'}`}>{role.desc}</div>
              </button>
            ))}
          </div>

          {/* === 클래스 배정 기준 설정 슬라이더 === */}
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex flex-col shrink-0">
            <div className="flex justify-between items-center mb-7">
              <span className="font-black text-[13px] text-slate-800 flex items-center gap-1.5">🎯 반 배정 기준 설정</span>
              <button 
                onClick={handleSaveThresholds}
                disabled={isSavingThreshold}
                className="text-[10px] bg-[#002864] text-white px-2.5 py-1.5 rounded-md font-bold hover:bg-blue-900 disabled:opacity-50 transition-colors shadow-sm"
              >
                {isSavingThreshold ? "저장 중..." : "저장"}
              </button>
            </div>
            
            <div className="relative w-full h-6 bg-slate-100 rounded-md flex select-none mb-6 shadow-inner" ref={thresholdTrackRef}>
              <div className="bg-slate-300 rounded-l-md transition-all duration-100" style={{ width: `${thresholdBounds[0]}%` }}></div>
              <div className="bg-emerald-300 transition-all duration-100" style={{ width: `${thresholdBounds[1]-thresholdBounds[0]}%` }}></div>
              <div className="bg-sky-300 transition-all duration-100" style={{ width: `${thresholdBounds[2]-thresholdBounds[1]}%` }}></div>
              <div className="bg-blue-500 transition-all duration-100" style={{ width: `${thresholdBounds[3]-thresholdBounds[2]}%` }}></div>
              <div className="bg-indigo-500 transition-all duration-100" style={{ width: `${thresholdBounds[4]-thresholdBounds[3]}%` }}></div>
              <div className="bg-rose-400 rounded-r-md transition-all duration-100" style={{ width: `${100-thresholdBounds[4]}%` }}></div>
              
              {[0, 1, 2, 3, 4].map((idx) => (
                <div key={idx} onMouseDown={() => { draggingThresholdRef.current = idx; }} onTouchStart={() => { draggingThresholdRef.current = idx; }} 
                     className="absolute top-1/2 -translate-y-1/2 -ml-[6px] w-[12px] h-[20px] bg-white border-2 border-[#002864] rounded cursor-ew-resize flex items-center justify-center gap-[1px] shadow-md hover:scale-110 hover:border-blue-500 transition-transform z-10 hover:z-20 active:z-20" 
                     style={{ left: `${thresholdBounds[idx]}%` }}>
                  <div className="absolute -top-7 text-[10px] font-bold bg-slate-700 text-white px-1.5 py-0.5 rounded shadow whitespace-nowrap">
                    {thresholdBounds[idx]}점
                  </div>
                  <div className="w-[1.5px] h-[8px] bg-slate-300"></div><div className="w-[1.5px] h-[8px] bg-slate-300"></div>
                </div>
              ))}
            </div>
            
            <div className="grid grid-cols-2 gap-y-2 gap-x-1 text-[10px] font-bold">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-slate-300 border border-slate-400 shadow-sm shrink-0"></span>
                <span className="text-slate-600 truncate">Pre-Course <span className="font-medium text-[9px]">(~{thresholdBounds[0]})</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-emerald-300 border border-emerald-400 shadow-sm shrink-0"></span>
                <span className="text-emerald-700 truncate">Horizon <span className="font-medium text-[9px]">({thresholdBounds[0]}~{thresholdBounds[1]})</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-sky-300 shadow-sm shrink-0"></span>
                <span className="text-sky-700 truncate">Titan <span className="font-medium text-[9px]">({thresholdBounds[1]}~{thresholdBounds[2]})</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-blue-500 shadow-sm shrink-0"></span>
                <span className="text-blue-700 truncate">Apex <span className="font-medium text-[9px]">({thresholdBounds[2]}~{thresholdBounds[3]})</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-indigo-500 shadow-sm shrink-0"></span>
                <span className="text-indigo-700 truncate">Master <span className="font-medium text-[9px]">({thresholdBounds[3]}~{thresholdBounds[4]})</span></span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-sm bg-rose-400 shadow-sm shrink-0"></span>
                <span className="text-rose-600 truncate">Ultimate <span className="font-medium text-[9px]">({thresholdBounds[4]}~)</span></span>
              </div>
            </div>
          </div>

          {/* 🌟 [추가됨] 마스터 채점 기준 관리 버튼 */}
          <div className="p-4 border-t border-slate-200 bg-white flex flex-col shrink-0">
            <div className="flex justify-between items-center mb-1.5">
              <span className="font-black text-[13px] text-slate-800 flex items-center gap-1.5">⚖️ 마스터 채점 기준</span>
            </div>
            <p className="text-[10px] text-slate-500 mb-3 font-medium">학원 전체의 공통 채점 가중치를 설정합니다.</p>
            <button 
              onClick={loadGradingCodes}
              className="w-full bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[12px] py-2.5 rounded-lg border border-slate-300 transition-colors shadow-sm flex justify-center items-center gap-2"
            >
              채점 기준표 수정하기
            </button>
          </div>

        </div>

        {/* === 우측 패널 (권한 설정 영역) === */}
        <div className="flex-1 bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col overflow-hidden h-full relative">
          <div className="p-5 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center shrink-0 z-10">
            <div>
              <h2 className="text-base font-black text-indigo-900 flex items-center gap-2">
                <span className="bg-indigo-100 text-indigo-600 px-2 py-0.5 rounded text-[11px] border border-indigo-200">{activeRole.id}</span> 
                {activeRole.name} 권한 설정
              </h2>
              <p className="text-[11px] text-slate-500 font-medium mt-1">체크박스를 선택하여 해당 직급의 선생님이 좌측 메뉴에 접근할 수 있도록 허용합니다.</p>
            </div>
            <button onClick={handleSave} disabled={isSaving} className="bg-[#002864] hover:bg-blue-900 disabled:opacity-50 text-white font-bold text-sm px-6 py-2.5 rounded-xl shadow-sm transition-all flex items-center gap-1.5">
              <span>💾</span> {isSaving ? "저장 중..." : "권한 설정 저장"}
            </button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scroll p-6 lg:p-8 bg-slate-50/30">
            <div className="max-w-4xl mx-auto flex flex-col gap-5 pb-10">
              {PERMISSION_GROUPS.map((group, gIdx) => {
                const toggleableItems = group.items.filter((i: any) => !i.isRequired);
                const hasToggleable = toggleableItems.length > 0;
                const isGroupAllChecked = hasToggleable && toggleableItems.every(item => currentPermissions.includes(item.id));
                const isGroupPartiallyChecked = !isGroupAllChecked && toggleableItems.some(item => currentPermissions.includes(item.id));

                return (
                  <div key={gIdx} className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
                    <div className="bg-slate-100/80 px-5 py-3 flex justify-between items-center border-b border-slate-200">
                      <div className="flex items-center gap-2">
                        <span className="text-[13px] font-black text-slate-700">{group.category}</span>
                        {group.desc && <span className="text-[10px] font-bold text-slate-400 bg-white px-2 py-0.5 rounded border border-slate-200">{group.desc}</span>}
                      </div>
                      <div className="flex items-center gap-2">
                        {hasToggleable && (
                          <>
                            <span className="text-[11px] font-bold text-slate-500 cursor-pointer" onClick={() => toggleGroupAll(group.items)}>전체 선택</span>
                            <input type="checkbox" checked={isGroupAllChecked} ref={input => { if (input) input.indeterminate = isGroupPartiallyChecked; }} onChange={() => toggleGroupAll(group.items)} className="w-5 h-5 rounded transition-transform active:scale-90 accent-indigo-600 cursor-pointer" />
                          </>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex flex-col divide-y divide-slate-100">
                      {group.items.map((item: any) => {
                        const isChecked = item.isRequired ? true : currentPermissions.includes(item.id);
                        const isDisabled = item.isRequired;
                        return (
                          <label key={item.id} className={`flex justify-between items-center py-2.5 transition-colors group ${isDisabled ? 'cursor-not-allowed bg-slate-50/50 px-5' : (item.isAction ? 'cursor-pointer hover:bg-rose-50/50 bg-slate-50/30 pl-10 pr-5' : 'cursor-pointer hover:bg-indigo-50/30 px-5')}`}>
                            <div className="flex flex-col">
                              <span className={`text-[12px] font-bold transition-colors ${isDisabled ? 'text-slate-400' : (item.isAction ? 'text-rose-600' : 'text-slate-700 group-hover:text-indigo-800')}`}>{item.label}</span>
                              {!item.isAction && <span className="text-[9px] text-slate-400 font-mono mt-0.5">{item.id}</span>}
                            </div>
                            <div className="flex items-center">
                              <input type="checkbox" checked={isChecked} onChange={() => togglePermission(item.id, isDisabled)} disabled={isDisabled} className={`w-4 h-4 rounded transition-transform active:scale-90 ${isDisabled ? 'accent-slate-300 cursor-not-allowed opacity-50' : (item.isAction ? 'accent-rose-500 cursor-pointer' : 'accent-[#002864] cursor-pointer')}`} />
                            </div>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* 🌟 [추가됨] 마스터 채점 기준표 수정 모달 */}
      {isGradingModalOpen && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden border border-slate-200">
            
            <div className="p-5 border-b border-slate-200 bg-slate-50 flex justify-between items-center shrink-0">
              <div>
                <h2 className="text-lg font-black text-[#002864]">⚖️ 마스터 채점 가중치 관리</h2>
                <p className="text-[11px] text-slate-500 font-bold mt-1">
                  이 수치를 변경하면 학원 내 모든 내신 성적 통계와 입학 진단평가 결과에 즉시 반영됩니다.
                </p>
              </div>
              <button 
                onClick={() => setIsGradingModalOpen(false)} 
                className="text-slate-400 hover:text-slate-700 bg-white border border-slate-200 rounded p-1.5 transition-colors"
              >
                ✕
              </button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-0 bg-white custom-scroll">
              <table className="w-full text-left border-collapse whitespace-nowrap text-sm">
                <thead className="bg-slate-100 sticky top-0 shadow-sm z-10 border-b border-slate-200">
                  <tr>
                    <th className="py-3 px-5 font-extrabold text-slate-600 text-[12px] w-16 text-center">기호</th>
                    <th className="py-3 px-5 font-extrabold text-slate-600 text-[12px]">상태 설명</th>
                    <th className="py-3 px-5 font-extrabold text-slate-600 text-[12px] text-center w-24">정답 유무</th>
                    <th className="py-3 px-5 font-extrabold text-slate-600 text-[12px] w-28 text-center">내신 가중치</th>
                    <th className="py-3 px-5 font-extrabold text-slate-600 text-[12px] w-28 text-center">입학 가중치</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {gradingCodes.map((code, idx) => (
                    <tr key={code.code} className="hover:bg-blue-50/40 transition-colors">
                      <td className="py-2.5 px-5 font-black text-[#002864] text-lg text-center bg-slate-50/50">{code.code}</td>
                      <td className="py-2.5 px-5 font-bold text-slate-700 text-[13px]">{code.description}</td>
                      <td className="py-2.5 px-5 text-center">
                        {code.is_correct ? 
                          <span className="bg-emerald-100 border border-emerald-300 text-emerald-700 px-2.5 py-0.5 rounded text-[11px] font-black shadow-sm">정답</span> : 
                          <span className="bg-rose-100 border border-rose-300 text-rose-700 px-2.5 py-0.5 rounded text-[11px] font-black shadow-sm">오답</span>}
                      </td>
                      <td className="py-2.5 px-5">
                        <input 
                          type="number" step="0.01" min="0" max="1"
                          value={code.score_ratio} 
                          onChange={(e) => {
                            const next = [...gradingCodes];
                            next[idx].score_ratio = e.target.value;
                            setGradingCodes(next);
                          }}
                          className="w-full border border-slate-300 rounded-md px-3 py-1.5 text-[13px] font-bold text-center text-slate-700 focus:outline-none focus:border-[#002864] focus:ring-1 focus:ring-[#002864] transition-all bg-white shadow-inner"
                        />
                      </td>
                      <td className="py-2.5 px-5">
                        <input 
                          type="number" step="0.01" min="0" max="1"
                          value={code.admission_ratio} 
                          onChange={(e) => {
                            const next = [...gradingCodes];
                            next[idx].admission_ratio = e.target.value;
                            setGradingCodes(next);
                          }}
                          className="w-full border border-slate-300 rounded-md px-3 py-1.5 text-[13px] font-bold text-center text-slate-700 focus:outline-none focus:border-[#002864] focus:ring-1 focus:ring-[#002864] transition-all bg-white shadow-inner"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <div className="p-4 border-t border-slate-200 bg-slate-50 flex justify-end gap-2 shrink-0 z-10">
              <button 
                onClick={() => setIsGradingModalOpen(false)} 
                className="px-5 py-2 bg-white border border-slate-300 rounded-lg text-slate-600 font-bold text-sm hover:bg-slate-100 transition-colors shadow-sm"
              >
                닫기
              </button>
              <button 
                onClick={handleSaveGradingCodes} 
                disabled={isSavingGrading} 
                className="px-6 py-2 bg-[#002864] text-white rounded-lg font-bold text-sm shadow-sm hover:bg-blue-900 disabled:opacity-50 transition-colors flex items-center gap-1.5"
              >
                {isSavingGrading ? "저장 중..." : "변경사항 저장"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}