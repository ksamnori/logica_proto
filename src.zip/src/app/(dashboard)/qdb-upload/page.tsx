// src/app/(dashboard)/qdb-upload/page.tsx
"use client";

import React, { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

export default function QuestionDBUploadPage() {
  const router = useRouter();
  const [isAuthorized, setIsAuthorized] = useState<boolean | null>(null);

  const [fileData, setFileData] = useState<any[] | null>(null);
  const [fileName, setFileName] = useState("");
  const [bookTitle, setBookTitle] = useState("");
  
  const [imageFiles, setImageFiles] = useState<File[]>([]);
  const [isImageDragOver, setIsImageDragOver] = useState(false);
  const [imageUploadProgress, setImageUploadProgress] = useState(0);

  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadLogs, setUploadLogs] = useState<string[]>([]);
  
  const [isDragOver, setIsDragOver] = useState(false);
  // 🌟 기존 ID 문항에 대해 분류/난이도 메타만 부분 업데이트할지 여부 (기본값: true로 켜두어 이미지/정답 증발 방지)
  const [onlyUpdateTaxonomyForExisting, setOnlyUpdateTaxonomyForExisting] = useState(true);

  useEffect(() => {
    const checkAccess = async () => {
      const role = localStorage.getItem("logica_instructor_role") || "";
      const tId = localStorage.getItem("logica_tenant_id") || "";
      
      if (!role || !tId) {
        alert("로그인 정보가 없습니다.");
        router.replace("/home");
        return;
      }

      if (role === 'SUPER_ADMIN') {
        setIsAuthorized(true);
        return;
      }

      const { data, error } = await supabase
        .from('tenant_role_permissions')
        .select('allowed_menus')
        .eq('tenant_id', tId)
        .eq('role_name', role)
        .single();

      if (!error && data && data.allowed_menus.includes("/qdb-upload")) {
        setIsAuthorized(true);
      } else {
        alert("⛔ 마스터 DB 업로드 툴 접근 권한이 없습니다. 권한 관리 페이지에서 허용해주세요.");
        router.replace("/home");
      }
    };
    checkAccess();
  }, [router]);

  const addLog = (msg: string) => {
    setUploadLogs(prev => [...prev, msg]);
  };

  const processFile = (file: File) => {
    setFileName(file.name);
    setUploadLogs([]);

    let cleanName = file.name.normalize("NFC").replace(/\.json$/i, ''); 
    cleanName = cleanName.split('_Problems')[0].normalize("NFC").trim(); 
    setBookTitle(cleanName); 

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (Array.isArray(json)) {
          setFileData(json);
          addLog(`✅ JSON 파싱 성공: 총 ${json.length}개의 문항 데이터 감지.`);
          addLog(`💡 추출된 기본 교재명: [${cleanName}]`);
        } else {
          alert("유효하지 않은 JSON 형식입니다. 배열 형태여야 합니다.");
        }
      } catch (err) {
        alert("JSON 파일 파싱 중 오류가 발생했습니다.");
      }
    };
    reader.readAsText(file);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) processFile(file);
  };

  const handleDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(true); };
  const handleDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsDragOver(false); };
  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    const file = e.dataTransfer.files?.[0];
    if (file && file.name.endsWith('.json')) {
      processFile(file);
    } else {
      alert("JSON 파일만 업로드 가능합니다.");
    }
  };

  const handleImageSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) setImageFiles(Array.from(e.target.files));
  };
  const handleImageDragOver = (e: React.DragEvent) => { e.preventDefault(); setIsImageDragOver(true); };
  const handleImageDragLeave = (e: React.DragEvent) => { e.preventDefault(); setIsImageDragOver(false); };
  const handleImageDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsImageDragOver(false);
    if (e.dataTransfer.files) {
      const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
      setImageFiles(files);
      if (files.length > 0) addLog(`✅ 대기 중인 이미지 파일 ${files.length}개 인식 완료.`);
    }
  };

  const mapDifficulty = (diff: string | null) => {
    if (!diff) return null;
    const cleanDiff = diff.trim();
    if (cleanDiff === '중상') return '상';
    if (cleanDiff === '중하') return '중';
    
    const allowed = ['최상', '상', '중', '하', '최하'];
    return allowed.includes(cleanDiff) ? cleanDiff : null;
  };

  const processUpload = async () => {
    if (!fileData || fileData.length === 0) return alert("업로드할 JSON 데이터가 없습니다.");
    
    const normalizeNfc = (v: any): string | null => {
      if (v === null || v === undefined) return null;
      const s = String(v).normalize("NFC").trim();
      return s ? s : null;
    };
    const finalBookName = bookTitle.normalize("NFC").trim();
    if (!finalBookName) return alert("교재 이름을 입력해주세요.");

    setIsUploading(true);
    setUploadProgress(0);
    setImageUploadProgress(0);

    try {
      if (imageFiles.length > 0) {
        addLog(`🚀 [1단계] 이미지 파일 ${imageFiles.length}개 업로드 시작...`);
        let imgSuccess = 0;
        
        for (let i = 0; i < imageFiles.length; i++) {
          const file = imageFiles[i];
          const { error: imgErr } = await supabase.storage
            .from('question_images') 
            .upload(file.name, file, { 
              upsert: true, 
              cacheControl: '3600' 
            });
          
          if (imgErr) {
            addLog(`❌ 이미지 업로드 실패 [${file.name}]: ${imgErr.message}`);
          } else {
            imgSuccess++;
          }
          setImageUploadProgress(Math.round(((i + 1) / imageFiles.length) * 100));
        }
        addLog(`✅ 이미지 업로드 완료 (성공: ${imgSuccess} / 전체: ${imageFiles.length})`);
      }

      addLog(`🚀 [2단계] 마스터 DB(question_db) 스마트 일괄 동기화 시작...`);
      const incomingIds = fileData.map(q => q.question_id).filter(Boolean);
      
      // 🌟 [수정 포인트] 조회를 150개씩 쪼개서(Chunk) 통신 에러 방지
      const existingIdSet = new Set<string>();
      const fetchChunkSize = 150;
      
      for (let i = 0; i < incomingIds.length; i += fetchChunkSize) {
        const chunkIds = incomingIds.slice(i, i + fetchChunkSize);
        const { data: existingQs, error: fetchErr } = await supabase
          .from('question_db')
          .select('question_id')
          .in('question_id', chunkIds);
          
        if (fetchErr) throw new Error(`기존 DB 조회 중 오류 발생 (Row ${i}): ${fetchErr.message}`);
        
        existingQs?.forEach(q => existingIdSet.add(q.question_id));
      }
      
      let updateCount = 0;
      let insertCount = 0;

      const safeJsonb = (val: any) => {
          if (!val) return null;
          if (typeof val === 'string') {
              try { return JSON.parse(val); } catch(e) { return null; }
          }
          return typeof val === 'object' ? val : null;
      };

      const safeBoolean = (val: any, defaultVal: boolean) => {
          if (val === true || val === 'true') return true;
          if (val === false || val === 'false') return false;
          return defaultVal;
      };

      const safeInteger = (val: any, defaultVal: number | null = null) => {
          const parsed = parseInt(val, 10);
          return isNaN(parsed) ? defaultVal : parsed;
      };

      const clampVarchar = (val: any, maxLen = 20, fallback: string | null = null): string | null => {
          if (val === null || val === undefined) return fallback;
          const s = String(val).trim();
          if (!s || ['NONE', 'NULL', 'UNDEFINED'].includes(s.toUpperCase())) return fallback;
          return s.slice(0, maxLen);
      };

      const sanitizeCurriculumId = (val: any): string | null => {
          if (val === null || val === undefined) return null;
          const s = String(val).trim();
          if (!s || ['NONE', 'NULL', '미분류', '-'].includes(s.toUpperCase())) return null;
          const m = s.match(/[EMH]\d{2,3}(?:-[0-9A-Za-z]+)+/i);
          if (m) return m[0].toUpperCase();
          const tok = s.split(/[\s:()\[\]]+/)[0]?.trim() || '';
          return tok ? tok.slice(0, 50) : null;
      };

      const sanitizeThinkingId = (val: any): string | null => {
          if (val === null || val === undefined) return null;
          const s = String(val).trim();
          if (!s || ['NONE', 'NULL', '미분류', '-'].includes(s.toUpperCase())) return null;
          const m = s.match(/THK-\d{2}(?:-\d{2}){0,2}/i);
          if (m) return m[0].toUpperCase().slice(0, 20);
          return null;
      };

      const sanitizeCognitiveLevel = (val: any): string | null => {
          if (val === null || val === undefined) return null;
          const s = String(val).trim();
          if (!s || s === '미지정' || ['NONE', 'NULL'].includes(s.toUpperCase())) return null;
          if (s.includes('추론') || s.includes('문제')) return '추론 및 문제 해결';
          if (s.includes('적용') || s.includes('응용')) return '적용 및 응용';
          if (s.includes('이해') || s.includes('연산')) return '이해 및 연산';
          return s.slice(0, 20);
      };

      const sanitizeProblemType = (val: any): string | null => {
          if (val === null || val === undefined) return null;
          const s = String(val).trim().toUpperCase();
          if (!s || ['NONE', 'NULL'].includes(s)) return null;
          if (s.includes('MULTIPLE_CHOICE') || s.includes('객관식')) return 'MULTIPLE_CHOICE';
          if (s.includes('DESCRIPTIVE') || s.includes('서술형')) return 'DESCRIPTIVE';
          if (s.includes('SUBJECTIVE') || s.includes('주관식') || s.includes('단답형')) return 'SUBJECTIVE';
          return String(val).trim().slice(0, 20);
      };


      // 🌟 [핵심] 이미 DB에 존재하는 question_id이고 분류 메타 전용 업데이트 모드가 켜져 있으면
      // 기존 이미지/정답/문제텍스트는 전혀 건드리지 않고 8개 분류·난이도 컬럼만 안전하게 UPDATE 합니다.
      const existingItemsToPatch: any[] = [];
      const newItemsToInsert: any[] = [];

      fileData.forEach((q) => {
        if (!q.question_id) return;
        if (existingIdSet.has(q.question_id)) {
          updateCount++;
          if (onlyUpdateTaxonomyForExisting) {
            existingItemsToPatch.push(q);
            return;
          }
        } else {
          insertCount++;
        }
        newItemsToInsert.push(q);
      });

      if (onlyUpdateTaxonomyForExisting && existingItemsToPatch.length > 0) {
        addLog(`🛠️ 기존 문항 ${existingItemsToPatch.length}건: 이미지·정답·본문은 보존하고 분류/난이도 10개 항목만 부분 업데이트 시작...`);
        let patchedCount = 0;
        const patchBatchSize = 25;

        for (let i = 0; i < existingItemsToPatch.length; i += patchBatchSize) {
          const batch = existingItemsToPatch.slice(i, i + patchBatchSize);
          await Promise.all(
            batch.map(async (q) => {
              const patchPayload: Record<string, any> = {
                taxonomy_id: sanitizeCurriculumId(q.taxonomy_id),
                taxonomy_name: q.taxonomy_name ?? null,
                sub_taxonomy_id: sanitizeCurriculumId(q.sub_taxonomy_id),
                sub_taxonomy_name: q.sub_taxonomy_name ?? null,
                thk_taxonomy_id: sanitizeThinkingId(q.thk_taxonomy_id),
                thk_taxonomy_name: q.thk_taxonomy_name ?? null,
                difficulty: mapDifficulty(q.difficulty),
                solving_probability: safeInteger(q.solving_probability),
                cognitive_level: sanitizeCognitiveLevel(q.cognitive_level),
                problem_type: sanitizeProblemType(q.problem_type),
                updated_at: new Date().toISOString(),
              };
              // 업로드된 JSON에 유효한 이미지/정답 정보가 포함된 경우에는 누락되지 않도록 함께 업데이트 (null이면 기존 DB 값 보존)
              if (q.image_url && String(q.image_url).trim() !== "" && String(q.image_url) !== "null") {
                patchPayload.image_url = q.image_url;
              }
              if (q.image_2_url && String(q.image_2_url).trim() !== "" && String(q.image_2_url) !== "null") {
                patchPayload.image_2_url = q.image_2_url;
              }
              if (q.question_2 !== undefined && q.question_2 !== null && String(q.question_2).trim() !== "" && String(q.question_2) !== "null") {
                patchPayload.question_2 = q.question_2;
                if (q.question !== undefined && q.question !== null) {
                  patchPayload.question = q.question;
                }
              }
              if (q.image_box) patchPayload.image_box = safeJsonb(q.image_box);
              if (q.image_2_box) patchPayload.image_2_box = typeof q.image_2_box === "string" ? q.image_2_box : JSON.stringify(q.image_2_box);
              if (q.answer_image_url && String(q.answer_image_url).trim() !== "" && String(q.answer_image_url) !== "null") {
                patchPayload.answer_image_url = q.answer_image_url;
              }
              if (q.answer_image_2_url && String(q.answer_image_2_url).trim() !== "" && String(q.answer_image_2_url) !== "null") {
                patchPayload.answer_image_2_url = q.answer_image_2_url;
              }
              if (q.answer_image_box) patchPayload.answer_image_box = safeJsonb(q.answer_image_box);

              let { error: patchErr } = await supabase
                .from('question_db')
                .update(patchPayload)
                .eq('question_id', q.question_id);

              if (patchErr && patchErr.code === '22001') {
                patchPayload.taxonomy_id = clampVarchar(patchPayload.taxonomy_id, 20, null);
                patchPayload.sub_taxonomy_id = clampVarchar(patchPayload.sub_taxonomy_id, 20, null);
                const retryPatch = await supabase
                  .from('question_db')
                  .update(patchPayload)
                  .eq('question_id', q.question_id);
                patchErr = retryPatch.error;
              }

              if (patchErr) {
                throw new Error(`문항 부분 업데이트 오류 (${q.question_id}): ${patchErr.message}`);
              }

              // textbook_question 에 동일 question_id 가 존재하는 경우에도 분류/난이도 정보 동기화
              const { error: tqSyncErr } = await supabase
                .from('textbook_question')
                .update({
                  taxonomy_id: q.taxonomy_id ?? null,
                  taxonomy_name: q.taxonomy_name ?? null,
                  sub_taxonomy_id: q.sub_taxonomy_id ?? null,
                  sub_taxonomy_name: q.sub_taxonomy_name ?? null,
                  thk_taxonomy_id: q.thk_taxonomy_id ?? null,
                  thk_taxonomy_name: q.thk_taxonomy_name ?? null,
                  difficulty: mapDifficulty(q.difficulty),
                  problem_type: q.problem_type ?? null,
                })
                .eq('question_id', q.question_id);

              if (tqSyncErr) {
                await supabase
                  .from('textbook_question')
                  .update({
                    taxonomy_id: q.taxonomy_id ?? null,
                    thk_taxonomy_id: q.thk_taxonomy_id ?? null,
                    difficulty: mapDifficulty(q.difficulty),
                    problem_type: q.problem_type ?? null,
                  })
                  .eq('question_id', q.question_id);
              }
            })
          );
          patchedCount += batch.length;
          const totalWork = existingItemsToPatch.length + newItemsToInsert.length;
          setUploadProgress(Math.round((patchedCount / (totalWork || 1)) * 100));
          addLog(`⏳ 기존 문항 분류 메타 업데이트: ${patchedCount} / ${existingItemsToPatch.length} 완료...`);
        }
      }

      const questionsToUpsert = newItemsToInsert.map((q) => {



        return {
          question_id: q.question_id,
          item_id: q.item_id || null,
          parent_question_id: q.parent_question_id || null,
          pdf_source: normalizeNfc(q.pdf_source),
          detected_page_num: safeInteger(q.detected_page_num),
          final_printed_page: clampVarchar(q.final_printed_page, 20, null),
          question_number: clampVarchar(q.question_number, 20, null),
          sub_num: safeInteger(q.sub_num, 0),
          sub_sub_num: safeInteger(q.sub_sub_num, 0),
          problem_type: sanitizeProblemType(q.problem_type),
          difficulty: mapDifficulty(q.difficulty), 
          solving_probability: safeInteger(q.solving_probability),
          question: q.question || "",
          question_2: q.question_2 || null,
          options: safeJsonb(q.options),
          answer: q.answer || null,
          step_1_concept: q.step_1_concept || null,
          step_2_approach: q.step_2_approach || null,
          step_3_process: q.step_3_process || null,
          step_4_conclusion: q.step_4_conclusion || null,
          image_box: safeJsonb(q.image_box),
          image_url: q.image_url || null,
          image_type: clampVarchar(q.image_type, 20, null),
          is_new_trend: safeBoolean(q.is_new_trend, false),
          ai_status: clampVarchar(q.ai_status, 20, '대기'),
          exposure_tier: clampVarchar(q.exposure_tier, 20, 'PUBLIC'),
          curriculum_type: clampVarchar(q.curriculum_type, 20, 'COMMON'),
          related_question_ids: safeJsonb(q.related_question_ids),
          classification_status: clampVarchar(q.classification_status, 20, 'PENDING'),
          engine_ver: clampVarchar(q.engine_ver, 20, null),
          derivation_type: clampVarchar(q.derivation_type, 20, null),
          group_id: clampVarchar(q.group_id, 50, null),
          taxonomy_id: sanitizeCurriculumId(q.taxonomy_id),
          taxonomy_name: q.taxonomy_name || null,
          sub_taxonomy_id: sanitizeCurriculumId(q.sub_taxonomy_id),
          sub_taxonomy_name: q.sub_taxonomy_name || null,
          cognitive_level: sanitizeCognitiveLevel(q.cognitive_level),
          verification_status: clampVarchar(q.verification_status, 20, 'PENDING'),
          is_human_verified: safeBoolean(q.human_verified, false) || safeBoolean(q.is_human_verified, false),
          answer_image_box: safeJsonb(q.answer_image_box),
          answer_image_url: q.answer_image_url || null,
          answer_image_type: clampVarchar(q.answer_image_type, 20, null),
          thk_taxonomy_id: sanitizeThinkingId(q.thk_taxonomy_id),
          thk_taxonomy_name: q.thk_taxonomy_name || null,
          is_hidden: safeBoolean(q.is_hidden, false),
          parent_relations: safeJsonb(q.parent_relations),
          raw_source_tags: safeJsonb(q.raw_source_tags) || safeJsonb(q.source_tag),
          explanation: q.explanation || null,
          solution: q.solution || null,
          image_2_box: typeof q.image_2_box === 'string' ? q.image_2_box : (q.image_2_box ? JSON.stringify(q.image_2_box) : null),
          image_2_url: q.image_2_url || null,
          image_2_type: clampVarchar(q.image_2_type, 20, null),
          answer_image_2_url: q.answer_image_2_url || null,
          ai_gradable: safeBoolean(q.ai_gradable, true),
          
          book_name: finalBookName || normalizeNfc(q.book_name),
          source_book_name: finalBookName || normalizeNfc(q.source_book_name) || normalizeNfc(q.book_name),
          
          updated_at: new Date().toISOString()
        };
      });

      addLog(`📊 DB 분석 결과: 기존 덮어쓰기(Update) ${updateCount}건 | 신규 이어붙이기(Insert) ${insertCount}건`);

      const chunkSize = 100;
      let processedCount = 0;

      for (let i = 0; i < questionsToUpsert.length; i += chunkSize) {
        const chunk = questionsToUpsert.slice(i, i + chunkSize);
        
        let { error: upsertErr } = await supabase
          .from('question_db')
          .upsert(chunk, { onConflict: 'question_id' });

        if (upsertErr && upsertErr.code === '22001') {
          const safeChunk = chunk.map((row: any) => ({
            ...row,
            taxonomy_id: clampVarchar(row.taxonomy_id, 20, null),
            sub_taxonomy_id: clampVarchar(row.sub_taxonomy_id, 20, null),
          }));
          const retryUpsert = await supabase
            .from('question_db')
            .upsert(safeChunk, { onConflict: 'question_id' });
          upsertErr = retryUpsert.error;
        }

        if (upsertErr) {
          throw new Error(`청크 DB 업로드 오류 (Row ${i}): ${upsertErr.message}`);
        }
        
        processedCount += chunk.length;
        setUploadProgress(Math.round((processedCount / questionsToUpsert.length) * 100));
        addLog(`⏳ DB ${processedCount} / ${questionsToUpsert.length} 문항 안전하게 Upsert 처리 완료...`);
      }

      try {
        const prevPending = JSON.parse(sessionStorage.getItem("logica_pending_new_workbooks") || "[]");
        const nextPending = Array.from(new Set([...(Array.isArray(prevPending) ? prevPending : []), finalBookName]));
        sessionStorage.setItem("logica_pending_new_workbooks", JSON.stringify(nextPending));
        sessionStorage.removeItem("logica_factory_stats_cache_v1");
      } catch {}

      const totalProcessed = (onlyUpdateTaxonomyForExisting ? existingItemsToPatch.length : 0) + processedCount;
      addLog(`🎉 모든 동기화 작업 최종 완료!`);
      alert(`✅ 문제은행 처리 및 이미지 업로드가 완료되었습니다!\n\n[처리 문항]\n총 ${totalProcessed}개 (신규 ${insertCount} / 업데이트 ${updateCount}${onlyUpdateTaxonomyForExisting && updateCount > 0 ? ' - 분류·난이도 10개 항목만 부분 업데이트' : ''})\n\n[이미지]\n총 ${imageFiles.length}개 안전하게 덮어쓰기 완료\n\n적용된 교재명: ${finalBookName}`);

      setFileData(null);
      setFileName("");
      setImageFiles([]);
      const jsonInput = document.getElementById('jsonFileInput') as HTMLInputElement;
      if (jsonInput) jsonInput.value = '';
      const imgInput = document.getElementById('imageFileInput') as HTMLInputElement;
      if (imgInput) imgInput.value = '';

    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : "알 수 없는 오류가 발생했습니다.";
      addLog(`❌ 업로드 실패: ${errorMessage}`);
      alert(`업로드 실패:\n${errorMessage}`);
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      setImageUploadProgress(0);
    }
  };

  if (isAuthorized === null) return <div className="p-10 text-center font-bold text-slate-400">권한 확인 중...</div>;
  if (isAuthorized === false) return null;

  return (
    <div className="flex flex-col h-full bg-slate-50 font-pretendard p-6 overflow-hidden items-center">
      <div className="w-full max-w-4xl bg-white rounded-2xl border border-slate-200 shadow-sm flex flex-col mt-4 overflow-hidden h-[calc(100vh-6rem)]">
        
        <div className="bg-brand p-6 text-white shrink-0">
          <h1 className="text-2xl font-bold flex items-center gap-2">
            <span>🗄️</span> 마스터 문제은행 스마트 업로드
          </h1>
          <p className="text-blue-200 text-sm mt-2 font-medium">
            JSON 문제 데이터와 다중 이미지 파일을 한 번에 처리합니다. (기존 데이터/이미지는 자동으로 덮어씁니다.)
          </p>
        </div>

        <div className="p-8 space-y-6 flex-1 overflow-y-auto custom-scroll">
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
            <h3 className="text-blue-800 font-bold text-sm mb-1">💡 스마트 이어붙이기(Upsert) 안내</h3>
            <ul className="text-xs text-blue-700 list-disc list-inside ml-4 space-y-1">
              <li>JSON 파일의 <code>question_id</code>가 이미 존재하면 <b>내용만 업데이트</b> 됩니다.</li>
              <li>마찬가지로 첨부된 이미지도 동일한 이름이 있으면 <b>안전하게 최신 파일로 덮어쓰기</b> 됩니다.</li>
            </ul>
            <label className="mt-3 pt-3 border-t border-blue-200 flex items-start gap-2.5 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={onlyUpdateTaxonomyForExisting}
                onChange={(e) => setOnlyUpdateTaxonomyForExisting(e.target.checked)}
                className="mt-0.5 w-4 h-4 accent-indigo-600 rounded cursor-pointer"
              />
              <span className="text-xs text-slate-800 font-bold leading-relaxed">
                🔒 이미 존재하는 <code className="text-indigo-700">question_id</code>는 기존 이미지·정답·문제 텍스트를 유지하고 <span className="text-indigo-700 underline">분류/난이도 10개 항목(taxonomy_id, taxonomy_name, sub_taxonomy_id, sub_taxonomy_name, thk_taxonomy_id, thk_taxonomy_name, difficulty, solving_probability, cognitive_level, problem_type)만 업데이트</span>하기
              </span>
            </label>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">1. JSON 데이터 파일</label>
              <div 
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={handleDrop}
                onClick={() => document.getElementById('jsonFileInput')?.click()}
                className={`flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-xl transition-all cursor-pointer h-40 ${
                  isDragOver ? 'border-indigo-500 bg-indigo-50 scale-[1.02]' : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400'
                }`}
              >
                <input id="jsonFileInput" type="file" accept=".json" onChange={handleFileSelect} className="hidden" />
                <div className="text-3xl mb-2">{isDragOver ? '📂' : '📄'}</div>
                <p className="text-slate-600 font-bold text-xs mb-1">JSON 파일 드래그 & 클릭</p>
                <div className="text-xs text-slate-500 font-medium h-4 mt-1">
                  {fileName ? <span className="text-indigo-600 font-bold bg-indigo-100 px-2 py-0.5 rounded">{fileName}</span> : "필수 업로드"}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-bold text-slate-700 mb-2">2. 문제/정답 이미지 파일 (선택)</label>
              <div 
                onDragOver={handleImageDragOver}
                onDragLeave={handleImageDragLeave}
                onDrop={handleImageDrop}
                onClick={() => document.getElementById('imageFileInput')?.click()}
                className={`flex flex-col items-center justify-center p-6 border-2 border-dashed rounded-xl transition-all cursor-pointer h-40 ${
                  isImageDragOver ? 'border-emerald-500 bg-emerald-50 scale-[1.02]' : 'border-slate-300 bg-slate-50 hover:bg-slate-100 hover:border-slate-400'
                }`}
              >
                <input id="imageFileInput" type="file" multiple accept="image/*" onChange={handleImageSelect} className="hidden" />
                <div className="text-3xl mb-2">{isImageDragOver ? '🖼️' : '📸'}</div>
                <p className="text-slate-600 font-bold text-xs mb-1">이미지 다중 선택 & 드래그</p>
                <div className="text-xs text-slate-500 font-medium h-4 mt-1">
                  {imageFiles.length > 0 ? <span className="text-emerald-600 font-bold bg-emerald-100 px-2 py-0.5 rounded">총 {imageFiles.length}개 파일 대기 중</span> : "선택 안 함"}
                </div>
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-slate-100">
            <label className="block text-sm font-bold text-slate-700 mb-2">3. 강제 지정할 교재 이름 (book_name) <span className="text-xs bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded ml-1 font-bold">전국 공용 설정</span></label>
            <input 
              type="text" 
              value={bookTitle} 
              onChange={(e) => setBookTitle(e.target.value)} 
              placeholder="JSON 파일을 올리면 자동으로 추출됩니다."
              className="w-full px-4 py-3 rounded-xl border border-slate-300 font-bold text-slate-800 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 shadow-sm transition-all" 
            />
          </div>

          <div className="bg-slate-900 rounded-xl p-4 h-40 overflow-y-auto custom-scroll font-mono text-xs text-emerald-400 shadow-inner">
            {uploadLogs.length === 0 ? (
              <span className="text-slate-600">대기 중... 작업할 파일을 드래그 앤 드롭 하세요.</span>
            ) : (
              uploadLogs.map((log, i) => (
                <div key={i} className="mb-1">{`> ${log}`}</div>
              ))
            )}
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-200 shrink-0">
          {isUploading && (
            <div className="mb-4 space-y-2">
              {imageFiles.length > 0 && (
                <div>
                  <div className="flex justify-between text-xs font-bold text-emerald-700 mb-1">
                    <span>🖼️ 이미지 덮어쓰기 진행률</span>
                    <span>{imageUploadProgress}%</span>
                  </div>
                  <div className="w-full bg-emerald-100 rounded-full h-1.5 overflow-hidden shadow-inner">
                    <div className="bg-emerald-500 h-1.5 rounded-full transition-all duration-300" style={{ width: `${imageUploadProgress}%` }}></div>
                  </div>
                </div>
              )}
              <div>
                <div className="flex justify-between text-xs font-bold text-indigo-700 mb-1">
                  <span>🗄️ JSON DB 동기화 진행률</span>
                  <span>{uploadProgress}%</span>
                </div>
                <div className="w-full bg-indigo-100 rounded-full h-1.5 overflow-hidden shadow-inner">
                  <div className="bg-indigo-600 h-1.5 rounded-full transition-all duration-300" style={{ width: `${uploadProgress}%` }}></div>
                </div>
              </div>
            </div>
          )}
          
          <button 
            onClick={processUpload} 
            disabled={(!fileData && imageFiles.length === 0) || isUploading}
            className={`w-full py-4 rounded-xl font-bold text-lg transition-all shadow-md flex items-center justify-center gap-2
              ${(!fileData && imageFiles.length === 0) ? 'bg-slate-200 text-slate-400 cursor-not-allowed' : 
                isUploading ? 'bg-indigo-400 text-white cursor-wait' : 'bg-brand hover:bg-blue-900 text-white active:scale-[0.98]'}`}
          >
            {isUploading ? "데이터 동기화 진행 중..." : "🚀 파일 및 데이터 스마트 동기화 시작"}
          </button>
        </div>

      </div>
    </div>
  );
}