// src/app/actions/admission.ts
"use server";

import { createClient } from "@supabase/supabase-js";
import { revalidatePath } from "next/cache"; // 🌟 [추가] Next.js 캐시 초기화를 위한 함수 임포트
import { resolveServerTenantId } from "@/lib/serverTenant";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

// 🌟 쿠키(`logica_tenant_id`) 우선 조회 + 만료 시 로그인 세션으로 DB 복구
async function getTenantId() {
  return resolveServerTenantId();
}

function buildStandardCandidateList(standardName: string): string[] {
  const raw = String(standardName || "").trim();
  const list: string[] = [];
  const pushUnique = (v: string) => {
    const t = String(v || "").trim();
    if (t && !list.includes(t)) list.push(t);
  };

  const midMatch =
    raw.match(/중(?:등|학교)?\s*([1-3])\s*[-_]\s*([1-2])/) ||
    raw.match(/\bM\s*([1-3])\s*[-_]\s*([1-2])/i);
  if (midMatch) {
    const mapped = `${parseInt(midMatch[1], 10) + 6}-${midMatch[2]}`;
    pushUnique(mapped);
    pushUnique(`${midMatch[1]}-${midMatch[2]}`);
    pushUnique(raw);
  }

  const matchTag = raw.match(/\d+-\d+/);
  const coreTag = matchTag ? matchTag[0] : raw;
  pushUnique(raw);
  pushUnique(coreTag);

  if (coreTag === "1-1") {
    pushUnique("7-1");
    pushUnique("중1-1");
    pushUnique("중등 1-1");
    pushUnique("2-2");
  } else if (coreTag === "7-1") {
    pushUnique("1-1");
    pushUnique("중1-1");
    pushUnique("중등 1-1");
  } else if (coreTag === "1-2") {
    pushUnique("7-2");
    pushUnique("7-1");
    pushUnique("2-2");
  } else if (coreTag === "2-1") {
    pushUnique("8-1");
    pushUnique("2-2");
  }

  return list;
}

function matchesStandardName(row: any, targetStd: string, coreTag: string): boolean {
  if (!row) return false;
  const candidates = [
    row.standard_name,
    row.standard,
    row.grade,
    row.level,
    row.name,
    row.title,
    row.exam_name,
  ]
    .filter((v) => v !== undefined && v !== null)
    .map((v) => String(v).trim());

  for (const val of candidates) {
    if (!val) continue;
    if (val === targetStd || val === coreTag) return true;
    const tagMatch = val.match(/\d+-\d+/);
    if (tagMatch && coreTag && tagMatch[0] === coreTag) return true;
    if (coreTag && val.includes(coreTag)) return true;
  }
  return false;
}

export async function fetchAdmissionStandardDataAction(standardName: string) {
  try {
    const rawStd = String(standardName || "").trim();
    const candidates = buildStandardCandidateList(rawStd);

    let metaRows: any[] = [];
    let baselineRow: any = null;
    let legacyMetaRows: any[] = [];
    let legacyBaselineRow: any = null;

    // 1. admission_standard_meta_2610 및 구 입학테스트용 admission_standard_meta 병렬 조회
    const [{ data: meta2610, error: meta2610Err }, { data: metaLegacy }] = await Promise.all([
      supabaseAdmin.from("admission_standard_meta_2610").select("*"),
      supabaseAdmin.from("admission_standard_meta").select("*"),
    ]);

    if (!meta2610Err && Array.isArray(meta2610) && meta2610.length > 0) {
      for (const cand of candidates) {
        const exact = meta2610.filter(
          (r: any) => String(r.standard_name ?? r.standard ?? "").trim() === cand
        );
        if (exact.length > 0) {
          metaRows = exact;
          break;
        }
      }
      if (metaRows.length === 0) {
        for (const cand of candidates) {
          const matched = meta2610.filter((r: any) => matchesStandardName(r, cand, cand));
          if (matched.length > 0) {
            metaRows = matched;
            break;
          }
        }
      }
    }

    if (Array.isArray(metaLegacy) && metaLegacy.length > 0) {
      for (const cand of candidates) {
        const exact = metaLegacy.filter(
          (r: any) => String(r.standard_name ?? r.standard ?? "").trim() === cand
        );
        if (exact.length > 0) {
          legacyMetaRows = exact;
          break;
        }
      }
      if (legacyMetaRows.length === 0) {
        for (const cand of candidates) {
          const matched = metaLegacy.filter((r: any) => matchesStandardName(r, cand, cand));
          if (matched.length > 0) {
            legacyMetaRows = matched;
            break;
          }
        }
      }
    }

    if (!metaRows || metaRows.length === 0) {
      metaRows = legacyMetaRows;
    }

    // 2. admission_standard_baseline_2610 및 구 입학테스트용 admission_standard_baseline 병렬 조회
    const [{ data: base2610, error: base2610Err }, { data: baseLegacy }] = await Promise.all([
      supabaseAdmin.from("admission_standard_baseline_2610").select("*"),
      supabaseAdmin.from("admission_standard_baseline").select("*"),
    ]);

    if (!base2610Err && Array.isArray(base2610) && base2610.length > 0) {
      for (const cand of candidates) {
        const found = base2610.find(
          (r: any) => String(r.standard_name ?? r.standard ?? "").trim() === cand
        );
        if (found) {
          baselineRow = found;
          break;
        }
      }
    }

    if (Array.isArray(baseLegacy) && baseLegacy.length > 0) {
      for (const cand of candidates) {
        const found = baseLegacy.find(
          (r: any) => String(r.standard_name ?? r.standard ?? "").trim() === cand
        );
        if (found) {
          legacyBaselineRow = found;
          break;
        }
      }
    }

    if (!baselineRow) {
      baselineRow = legacyBaselineRow;
    }

    return {
      success: true,
      metaRows: metaRows || [],
      baselineRow: baselineRow || null,
      legacyMetaRows: legacyMetaRows || [],
      legacyBaselineRow: legacyBaselineRow || null,
    };
  } catch (error: any) {
    return {
      success: false,
      metaRows: [],
      baselineRow: null,
      legacyMetaRows: [],
      legacyBaselineRow: null,
      message: error?.message || "기준표 로드 실패",
    };
  }
}

// 🌟 프론트엔드에서 명시적으로 tenantId를 넘겨줄 수 있도록 파라미터(clientTenantId) 추가
export async function assignStudents(sessionId: string, examId: string | null, studentIds: string[], clientTenantId?: string) {
  const tenantId = clientTenantId || await getTenantId();
  if (!tenantId) return { success: false, message: "소속 지점 정보(쿠키)가 없습니다. 다시 로그인해주세요." };

  try {
    const { data: sessionData } = await supabaseAdmin
      .from('admission_session')
      .select('tenant_id')
      .eq('admission_session_id', sessionId)
      .single();

    if (!sessionData || sessionData.tenant_id !== tenantId) {
      throw new Error("접근 권한이 없는 일정이거나 잘못된 요청입니다.");
    }

    const appData = studentIds.map(id => ({ admission_session_id: sessionId, student_id: id, status: '예약완료' }));
    const { error: appError } = await supabaseAdmin.from('admission_application').insert(appData);
    if (appError) throw new Error(`[입학 배정 에러] ${appError.message}`);

    if (examId && examId !== 'null' && examId !== '') {
      // 💡 [중요] exam_assignment에 tenant_id 값을 필수로 포함하여 Insert
      const shadowData = studentIds.map(id => ({ 
        student_id: id, 
        admission_session_id: sessionId, 
        exam_id: examId, 
        status: '미응시',
        tenant_id: tenantId 
      }));
      const { error: shadowError } = await supabaseAdmin.from('exam_assignment').insert(shadowData);
      if (shadowError) throw new Error(`[시험지 연결 에러] ${shadowError.message}`);
    }
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

export async function unassignStudentAction(studentId: string, sessionId: string) {
  const tenantId = await getTenantId();
  if (!tenantId) return { success: false, message: "인증이 만료되었습니다. 다시 로그인해주세요." };

  try {
    const { data: sessionData } = await supabaseAdmin.from('admission_session').select('tenant_id').eq('admission_session_id', sessionId).single();
    if (!sessionData || sessionData.tenant_id !== tenantId) throw new Error("권한이 없습니다.");

    const { data: assignments, error: fetchErr } = await supabaseAdmin.from('exam_assignment').select('assignment_id').eq('student_id', studentId).eq('admission_session_id', sessionId);
    if (fetchErr) throw new Error(fetchErr.message);
    
    if (assignments && assignments.length > 0) {
      for (let a of assignments) {
        await supabaseAdmin.from('student_answer').delete().eq('exam_assignment_id', a.assignment_id);
        await supabaseAdmin.from('student_exam_result').delete().eq('assignment_id', a.assignment_id);
        const { error: delAssignErr } = await supabaseAdmin.from('exam_assignment').delete().eq('assignment_id', a.assignment_id);
        if (delAssignErr) throw new Error(delAssignErr.message);
      }
    }
    const { error: delAppErr } = await supabaseAdmin.from('admission_application').delete().eq('admission_session_id', sessionId).eq('student_id', studentId);
    if (delAppErr) throw new Error(delAppErr.message);

    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 🌟 상담 결과 업데이트 로직 (검증 로직 추가 및 자동 승급 조건 변경)
export async function updateCounselingResult(appId: string, studentId: string, result: string, memo: string) {
  const tenantId = await getTenantId();
  if (!tenantId) return { success: false, message: "권한이 없습니다. 다시 로그인해주세요." };

  try {
    // 💡 .select()를 추가하여 실제 업데이트가 성공적으로 발생했는지 확인합니다.
    const { data: updatedData, error: upAppErr } = await supabaseAdmin
      .from('admission_application')
      .update({ test_result: result, counseling_memo: memo })
      .eq('application_id', appId)
      .select();
      
    if (upAppErr) throw new Error(upAppErr.message);

    // 💡 업데이트된 행이 없다면 appId가 잘못되었거나 매칭되는 데이터가 없는 것입니다.
    if (!updatedData || updatedData.length === 0) {
      throw new Error("업데이트할 대상을 찾지 못했습니다. 올바른 데이터를 선택했는지 확인해주세요.");
    }

    // 💡 '합격' -> '수강 등록'으로 프론트엔드 파이프라인과 일치시켰습니다.
    if (result === '수강 등록') {
      const { data: stuData } = await supabaseAdmin.from('student').select('tenant_id').eq('student_id', studentId).single();
      if (stuData && stuData.tenant_id === tenantId) {
        const { error: upStErr } = await supabaseAdmin.from('student').update({ status: '재원' }).eq('student_id', studentId);
        if (upStErr) throw new Error(upStErr.message);
      }
    }
    
    // 🌟 [핵심 해결책] DB 업데이트가 성공한 직후, 라우터 캐시를 날려버립니다.
    // 이렇게 하면 프론트엔드가 아까 받아둔 과거 데이터를 버리고 최신 상태('결과 통보', '수강 등록' 등)를 서버에서 다시 그려옵니다.
    revalidatePath('/', 'layout');

    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

// 🌟 프론트엔드에서 넘겨준 파라미터(clientTenantId)를 처리
export async function forceAssignExamAction(studentId: string, sessionId: string, examId: string, clientTenantId?: string) {
  const tenantId = clientTenantId || await getTenantId();
  if (!tenantId) return { success: false, message: "권한이 없습니다. 다시 로그인해주세요." };

  try {
    const { data: sessionData } = await supabaseAdmin.from('admission_session').select('tenant_id').eq('admission_session_id', sessionId).single();
    if (!sessionData || sessionData.tenant_id !== tenantId) throw new Error("권한이 없습니다.");

    const { data: existing, error: fetchErr } = await supabaseAdmin.from('exam_assignment').select('assignment_id').eq('student_id', studentId).eq('exam_id', examId);
    if (fetchErr) throw new Error(fetchErr.message);

    if (existing && existing.length > 0) {
      const { error: upErr } = await supabaseAdmin.from('exam_assignment').update({ admission_session_id: sessionId }).eq('assignment_id', existing[0].assignment_id);
      if (upErr) throw new Error(upErr.message);
    } else {
      // 💡 [중요] 새로 시험지를 매핑(Insert)할 때 tenant_id 필수 추가
      const { error: insErr } = await supabaseAdmin.from('exam_assignment').insert([{ 
        student_id: studentId, 
        admission_session_id: sessionId, 
        exam_id: examId, 
        status: '미응시',
        tenant_id: tenantId 
      }]);
      if (insErr) throw new Error(insErr.message);
    }
    return { success: true };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}