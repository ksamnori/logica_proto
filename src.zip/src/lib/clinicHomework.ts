// src/lib/clinicHomework.ts

export type PendingHwQuestion = {
  tq_id: any; // 🌟 숫자형(교재) 또는 UUID 문자열(부교재) 모두 허용
  question_id: string | number | null;
  answer: string | null;
  image_url: string | null;
  raw_metadata: any;
  book_id: number | null;
  homeworkId: number | null;
  homeworkTitle: string | null;
  bookType: string | null;
  bookTitle: string | null;
  [key: string]: any; 
};

export type BookSummary = {
  bookId: number | null;
  bookType: string | null;
  bookTitle: string | null;
  count: number;
};

export const BOOK_TYPE_COLORS: Record<string, { pill: string; dot: string }> = {
  주교재: { pill: 'bg-blue-100 text-blue-700 border-blue-200', dot: 'bg-blue-500' },
  부교재: { pill: 'bg-emerald-100 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  연산교재: { pill: 'bg-purple-100 text-purple-700 border-purple-200', dot: 'bg-purple-500' },
  워크북: { pill: 'bg-amber-100 text-amber-700 border-amber-200', dot: 'bg-amber-500' },
  기타: { pill: 'bg-slate-200 text-slate-700 border-slate-300', dot: 'bg-slate-500' },
  오답: { pill: 'bg-rose-100 text-rose-700 border-rose-200', dot: 'bg-rose-500' },
};

export async function resolvePendingHomeworkQuestions(
  supabaseClient: any,
  studentId: string,
  hwIds: number[]
): Promise<{ rows: PendingHwQuestion[]; booksSummary: BookSummary[] }> {
  if (!hwIds || hwIds.length === 0) return { rows: [], booksSummary: [] };

  const { data: assignments } = await supabaseClient
    .from('homework_assignment')
    .select('homework_id, homework_title, target_questions, student_homework_result(student_id, status, completed_tq_ids)')
    .in('homework_id', hwIds);
    
  if (!assignments || assignments.length === 0) return { rows: [], booksSummary: [] };

  const COMPLETED_STATUSES = new Set(['채점완료', '제출완료', '완료', '최종완료']);
  let allTqIds: any[] = [];
  const metaMap: Record<string, { homework_id: number; homework_title: string }> = {};
  
  assignments.forEach((hw: any) => {
    let tqIds: any = hw.target_questions;
    if (typeof tqIds === 'string') {
      try { tqIds = JSON.parse(tqIds); } catch { tqIds = []; }
    }
    const results = Array.isArray(hw.student_homework_result) ? hw.student_homework_result : [];
    const res = results.find((r: any) => String(r.student_id) === String(studentId)) || {};
    if (res.status && COMPLETED_STATUSES.has(String(res.status))) return;

    let compIds: any = res.completed_tq_ids;
    if (typeof compIds === 'string') {
      try { compIds = JSON.parse(compIds); } catch { compIds = []; }
    }
    
    if (!Array.isArray(tqIds)) tqIds = [];
    if (!Array.isArray(compIds)) compIds = [];
    const compSet = new Set(compIds.map((v: any) => String(v)));

    tqIds.forEach((idVal: any) => {
      const key = String(idVal);
      if (!compSet.has(key)) {
        allTqIds.push(idVal);
        metaMap[key] = { homework_id: hw.homework_id, homework_title: hw.homework_title };
      }
    });
  });

  const uniqueIds = [...new Set(allTqIds)];

  // 🌟 [핵심 방어 로직] 숫자형(tq_id)과 문자열(UUID) 철저히 분리
  const numIds = uniqueIds
    .filter(id => id !== null && id !== undefined && (typeof id === 'number' || (typeof id === 'string' && !id.includes('-') && !isNaN(Number(id)))))
    .map(Number);

  const uuidIds = uniqueIds
    .filter(id => id && typeof id === 'string' && id.includes('-'));

  if (numIds.length === 0 && uuidIds.length === 0) return { rows: [], booksSummary: [] };

  // 🌟 분리된 ID들을 각각의 테이블에 맞게 쿼리 실행
  const [tqRes, qDbRes] = await Promise.all([
    numIds.length > 0 ? supabaseClient.from('textbook_question').select('*, textbook(book_type, title)').in('tq_id', numIds) : Promise.resolve({ data: [] }),
    uuidIds.length > 0 ? supabaseClient.from('question_db').select('*').in('question_id', uuidIds) : Promise.resolve({ data: [] })
  ]);

  const rows: PendingHwQuestion[] = [];

  // 1. 순수 교재 문항 (textbook_question) 병합
  (tqRes.data || []).forEach((q: any) => {
    rows.push({
      ...q,
      homeworkId: metaMap[String(q.tq_id)]?.homework_id ?? null,
      homeworkTitle: metaMap[String(q.tq_id)]?.homework_title ?? null,
      bookType: q.textbook?.book_type ?? null,
      bookTitle: q.textbook?.title ?? null,
    });
  });

  // 2. 부교재/프린트 문항 (question_db) 병합
  (qDbRes.data || []).forEach((q: any) => {
    rows.push({
      ...q,
      tq_id: null, // 🌟 핵심 픽스: UUID를 tq_id에 강제로 쑤셔넣어 발생하던 Postgres 에러 원천 차단!
      question_id: q.question_id, 
      homeworkId: metaMap[String(q.question_id)]?.homework_id ?? null,
      homeworkTitle: metaMap[String(q.question_id)]?.homework_title ?? null,
      bookType: '기타',
      bookTitle: q.source_book_name ?? '추가 문항',
    });
  });

  const summaryMap = new Map<string, BookSummary>();
  rows.forEach(r => {
    const key = String(r.book_id || r.bookTitle); // book_id가 없으면 교재명으로 묶음
    const existing = summaryMap.get(key);
    if (existing) existing.count++;
    else summaryMap.set(key, { bookId: r.book_id || null, bookType: r.bookType, bookTitle: r.bookTitle, count: 1 });
  });

  return { rows, booksSummary: [...summaryMap.values()] };
}